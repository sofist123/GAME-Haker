package gameExample_6_____reliz__3;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by sofis on 30.05.2019.
 */
public class GameTime {
    /*
    ключевые точки времени в анимации заставки

    class Honeycomb
    private boolean showONanimationHoneycomb2 = false;    //156 строка  - разрешение на анимацию анимации сот(2-я часть)

    class Honeycomb2
    long startTimeShowAnimationBigHoneycomb = startTime + 70 * 1000;  // 71 строка - задержка анимации bigHoneycomb

    class Honeycomb2
    private long startTimeShowForMessageAnimation = startTimeForMessageAnimation + 78 * 1000;   //79 строка - (ключевая точка времени)время задержки начала анимации сообщений на BigHoneycomb                           // 60 seconds * 1000 ms/sec;   //время окончания воспроизведения анимации


    class GameBackgroundScreenSaver
    long endTimeShowAnimationHieroglyph = startTime + 15 * 1000;   //93 строка - длительность анимации иероглифов

    class TrackСleaning
    long startTimeShowAnimationTrackErasing = startTime + 290 * 1000;  //(290 - должно стоять в релизе)ключевая точка времени (изначально = ) //время задержки начала анимации стирания дорожек                           // 60 seconds * 1000 ms/sec;   //время окончания воспроизведения анимации


     class GamePanelScreenSaver
     //    backgroundScreenSaver.update();   //135 строка (разкоментировать в релизе)
     //    honeycomb.update();               //139 строка (разкоментировать в релизе)
     //    honeycomb2.update();               //140 строка (разкоментировать в релизе)

     //    backgroundScreenSaver.draw(g);    //151 строка (разкоментировать в релизе)
     //    honeycomb.draw(g);                //155 строка (разкоментировать в релизе)
     //    honeycomb2.draw(g);                //156 строка (разкоментировать в релизе)


     */

    //fields
    Date date = new Date();                       //обьявление переменной "date"
    Calendar calendar = Calendar.getInstance();  // получение переменной "calendar"

    private DateFormat formatterTime;                //переменная "formatterTime" часы,минуты,секунды
    private DateFormat formatterTime2;     //переменная "formatterTime2" часы,минуты,секунды,милисекунды
    private DateFormat formatterData;         // переменная "formatterData" день,месяц,год

    String dateShow = new String();        //переменная для даты
    String currentTimeShow = new String();       //переменная для времени
    String currentTime2Show = new String();     //переменная для времени с милисекундами

    String timeStartShow = new String();    //времяначала запуска программы

    long startTime = System.currentTimeMillis();                        //переменная текущего времени (для фиксации времени начала анимации)
    long startShowTimeAndData = startTime + 367 * 1000;  //((367) - должно стоять в релизе)ключевая точка времени (изначально = ) //время задержки начала анимации бекграунда Server         // 60 seconds * 1000 ms/sec;   //время окончания воспроизведения анимации
    long finishShowTimeAndData = startTime + 590 * 1000;  //((590) - должно стоять в релизе)ключевая точка времени (изначально = ) //время задержки начала анимации бекграунда Server         // 60 seconds * 1000 ms/sec;   //время окончания воспроизведения анимации

    private int starterForStartShowBackgroundTimeAndData = -1;   //пускатель

    private boolean showBackgroundTimeAndData = false;    //разрешение на  анимацию
    private boolean showTimeAndData = false;    //разрешение на  анимацию

    private Image backgroundTime;       //бекграунд для времени
    private int backgroundTime_x = 0;      //координата "x" для backgroundTime
    private int backgroundTime_y = -100;      //координата "y" для backgroundTime
    private int backgroundTime_y_f = -21;      //финишная координата "y" для backgroundTime

    private Image backgroundData;       //бекграунд для даты
    private int backgroundData_x = 0;      //координата "x" для backgroundData
    private int backgroundData_y = -100;      //координата "y" для backgroundData
    private int backgroundData_y_f = -21;      //финишная координата "y" для backgroundData


    //constructor
    public GameTime() throws IOException {
        date = new Date();
        calendar.setTime(date);
        calendar.add(Calendar.YEAR, 20);        //добавление к сегодней дате 20 лет


        formatterData = new SimpleDateFormat("dd'.'MM'.'yyyy");             // переменная "formatterData" день,месяц,год

        formatterTime = new SimpleDateFormat("HH:mm:ss");                //переменная "formatterTime" часы,минуты,секунды
        formatterTime2 = new SimpleDateFormat("HH':'mm':'ss'.'SSSS");     //переменная "formatterTime2" часы,минуты,секунды,милисекунды

//        calendar.add(Calendar.HOUR, 2);    //добавление к сегодней дате 2 часа
//        calendar.add(Calendar.MINUTE, 5);  //добавление к сегодней дате 5 минут
//        calendar.add(Calendar.SECOND, 9);   //добавление к сегодней дате 9 секунд

        timeStartShow = formatterTime.format(Calendar.getInstance().getTime());   //присвоение переменной значения старта программы


        backgroundTime = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/time/time.png"));
        backgroundData = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/time/data.png"));
    }


    //functions

    public void update() {

        comparison_time();

        currentTimeShow = formatterTime.format(Calendar.getInstance().getTime());    //постоянное обновление времени
        currentTime2Show = formatterTime2.format(Calendar.getInstance().getTime());    //постоянное обновление времени (+ милисекунді)

        dateShow = formatterData.format(calendar.getTime());    //постоянное обновление даты

    }

    //определение времени запуска анимации
    public void comparison_time() {

        if (System.currentTimeMillis() > startShowTimeAndData) {               //проверка,если время,startTime = System.currentTimeMillis(); больше startTimeShowElectricalImpulse,то поменять false  на true (т.е. разрешить анимацию электроимпульсов)
//            currentTimeShow = formatterTime.format(Calendar.getInstance().getTime());    //постоянное обновление времени
//            currentTime2Show = formatterTime2.format(Calendar.getInstance().getTime());    //постоянное обновление времени (+ милисекунді)
//
//            dateShow = formatterData.format(calendar.getTime());    //постоянное обновление даты


            starterForStartShowBackgroundTimeAndData++;
            if (starterForStartShowBackgroundTimeAndData == 0) {
                showBackgroundTimeAndData = true;
            }
        }

        if (System.currentTimeMillis() > finishShowTimeAndData) {               //проверка,если время,startTime = System.currentTimeMillis(); больше startTimeShowElectricalImpulse,то поменять false  на true (т.е. разрешить анимацию электроимпульсов)
            showBackgroundTimeAndData = false;
        }
    }

    //установка координат для бекграундов времени и даты
    public void definitionCoordinatesForTimeAndData() {

        if (backgroundTime_y < backgroundTime_y_f) {
            backgroundTime_y++;
        }
        if (backgroundData_y < backgroundData_y_f) {
            backgroundData_y++;
        }

        if (backgroundTime_y == backgroundTime_y_f) {
            showTimeAndData = true;
        }


    }


    public void draw(Graphics2D g) {
        //   super.paintComponent(g);

        if (showBackgroundTimeAndData == true) {


            definitionCoordinatesForTimeAndData();
            g.drawImage(new ImageIcon(backgroundTime).getImage(), backgroundTime_x, backgroundTime_y, null);
            g.drawImage(new ImageIcon(backgroundData).getImage(), backgroundData_x, backgroundData_y, null);

            if (showTimeAndData == true) {
                Color color1 = new Color(0, 150, 255);                   //создание цвета
                g.setColor(color1);                                               //присоединение выбраного цвета к кисти

                Font myFont = new Font(null, Font.BOLD, 30);           //установка шрифта и размера шрифта для анимации времени
                g.setFont(myFont);

                g.drawString(dateShow, 336, 40);
        //        g.drawString(currentTimeShow, 900, 30);
                g.drawString(currentTime2Show, 1357, 40);

        //        g.drawString(timeStartShow, 900, 70);

            }
        }
//        Color color1 = new Color(0, 150, 255);                   //создание цвета
//        g.setColor(color1);                                               //присоединение выбраного цвета к кисти
//
//        Font myFont = new Font(null, Font.BOLD, 30);           //установка шрифта и размера шрифта для анимации времени
//        g.setFont(myFont);
//
//    //    g.drawString(dateShow, 100, 30);
    //    g.drawString(currentTimeShow, 900, 30);
//        g.drawString(currentTime2Show, 1550, 30);
//
    //    g.drawString(timeStartShow, 900, 70);




        //    g.drawString(currentTimeShow, 900, 30);
        //    g.drawString(timeStartShow, 900, 70);
    }

}
