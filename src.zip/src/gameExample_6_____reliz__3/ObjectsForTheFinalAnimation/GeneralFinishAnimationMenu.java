package gameExample_6_____reliz__3.ObjectsForTheFinalAnimation;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.geom.AffineTransform;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Created by sofis on 24.08.2020.
 */
public class GeneralFinishAnimationMenu {
    long a1 = System.currentTimeMillis();
    long a2 = a1 + 798 * 1000;
    long a3 = a1 + 805 * 1000;
    private boolean a4 = false;
    private Image a5;
    private ArrayList<String> a7 = new ArrayList<>();
    private String a8;
    private boolean a9 = false;
    private int a10 = 0;
    private int a11 = 0;
    private Image a12;
    private int[][] a13 = new int[][]{
            {1, 151, 0, 0, 0, 1093, 274, 2, 1,},
            {2, -151, 0, 0, 0, 1093, 405, 3, 2,},
            {3, 151, 0, 0, 0, 1093, 526, 4, 3,},
            {4, -151, 0, 0, 0, 1093, 652, 5, 4,},
            {5, 151, 0, 0, 0, 1093, 782, 6, 5,},
    };
    private int a14 = 0;
    private double[] a16 = new double[]{0, 0, 0, 0, 0};
    private boolean a17 = false;
    private boolean a18 = false;
    private int A19 = -1;
    private ArrayList<String> A20 = new ArrayList<>();
    private String A21;
    private boolean A22 = false;
    private int A23 = 0;
    private boolean A24 = false;
    private ArrayList<StringBuilder> A25 = new ArrayList<>();
    private StringBuilder A26 = new StringBuilder();
    private String[] A27 = new String[6];
    private char[] A29;
    private char A30;
    private int A31 = 0;
    private int A32 = 0;
    private int S33 = -1;
    private int A34 = -1;
    private boolean A35 = true;
    private ArrayList<ArrayList<int[]>> A36 = new ArrayList<ArrayList<int[]>>();
    private String A37;
    private int A38;
    private int[] A39 = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,};
    private ArrayList<int[]> A40 = new ArrayList<int[]>();
    private int[] A41 = {
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    };
    private int A42 = 3;
    ArrayList<String> A43 = new ArrayList<>();
    private String A44;
    private int[] A45 = {0, 0, 0,};
    private ArrayList<int[]> A46 = new ArrayList<int[]>();
    private ArrayList<ArrayList<int[]>> A47 = new ArrayList<ArrayList<int[]>>();
    private int A48;
    private int A49 = 263;
    private int A50 = 290;
    private int A52 = 748;
    private int A54 = 788;
    private int A55 = 9;
    private boolean A56 = false;
    private boolean A57 = false;
    private int A58 = 506;
    private ArrayList<int[][]> A59 = new ArrayList<int[][]>();
    private int[][] A60 = new int[225][5];
    private int[][] A61 = new int[248][5];
    private int[][] A62 = new int[267][5];
    private int[][] A63 = new int[187][5];
    private int[][] A64 = new int[69][5];
    private ArrayList<int[][]> A70 = new ArrayList<int[][]>();
    private int[][] A65 = new int[225][5];
    private int[][] A66 = new int[248][5];
    private int[][] A67 = new int[267][5];
    private int[][] A68 = new int[187][5];
    private int[][] A69 = new int[69][5];
    private ArrayList<int[][]> a71 = new ArrayList<int[][]>();
    private int[][] a72 = new int[1920][5];
    private int[][] a73 = new int[420][5];
    private int[][] a74 = new int[420][5];
    private int[][] a76 = new int[420][5];
    private int[][] a77 = new int[420][5];
    private int[][] a78 = new int[420][5];
    private int[][] a79 = new int[420][5];
    private int[][] a80 = new int[420][5];
    private ArrayList<int[][]> a81 = new ArrayList<int[][]>();
    private Image a82;
    private Image a83;
    private Image a85;
    private Image a88;
    private Image a89;
    private Image a90;
    private Image a91;
    private Image a92;
    private boolean a93 = false;
    private int a96 = 0;
    private int a99 = 49;
    private int a100 = 0;
    private int q1 = 55;
    private int q2 = 0;
    private int q3 = 65;
    private ArrayList<String> q4 = new ArrayList<>();
    private String q5;
    private boolean q7 = false;
    private int q8 = 0;
    private int q10 = 0;
    private int q11 = 0;

    public GeneralFinishAnimationMenu() throws IOException {
        a5 = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/backgroundForGeneralFinishAnimation/2backgroundForGeneralFinishAnimationMenu.png"));
        a12 = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/backgroundForGeneralFinishAnimation/2auxiliaryBackgroundForIconMenu.png"));
        for (int i = 1; i <= 27; i++) {
            a7.add("gameResourse2/resourseImages/ImagesForScreenSaver/largeLogoTransparencyMenu/" + i + ".png");
        }
        for (int i = 1; i <= 5; i++) {
            A20.add("gameResourse2/resourseImages/ImagesForScreenSaver/iconMenu/" + i + ".png");
        }
        A27[0] = "Registration";
        A27[1] = "Authorization";
        A27[2] = "Customization";
        A27[3] = "Questions";
        A27[4] = "Exit";
        A27[5] = "";
        for (int i = 1; i <= 23; i++) {
            A43.add("gameResourse/resourseImages/ImagesForScreenSaver/pixelsTransparency/" + i + ".png");
        }
        a82 = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/iconMenu/2equalizer/2blackPixel.png"));
        a83 = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/iconMenu/2equalizer/2whitePixel.png"));
        a88 = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/iconMenu/2equalizer/2bluePixel.png"));
        a92 = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/iconMenu/2equalizer/2grayPixel3.png"));
        for (int i = 0; i < 225; i++) {
            A60[i][0] = i;
            A60[i][1] = 1253 + i;
            A60[i][2] = 296;
            A60[i][3] = 1;
            A60[i][4] = 1;
        }
        for (int i = 0; i < 248; i++) {
            A61[i][0] = i;
            A61[i][1] = 1250 + i;
            A61[i][2] = 422;
            A61[i][3] = 0;
            A61[i][4] = 0;
        }
        for (int i = 0; i < 267; i++) {
            A62[i][0] = i;
            A62[i][1] = 1252 + i;
            A62[i][2] = 550;
            A62[i][3] = 0;
            A62[i][4] = 0;
        }
        for (int i = 0; i < 187; i++) {
            A63[i][0] = i;
            A63[i][1] = 1252 + i;
            A63[i][2] = 676;
            A63[i][3] = 1;
            A63[i][4] = 1;
        }
        for (int i = 0; i < 69; i++) {
            A64[i][0] = i;
            A64[i][1] = 1253 + i;
            A64[i][2] = 804;
            A64[i][3] = 1;
            A64[i][4] = 1;
        }
        A59.add(A60);
        A59.add(A61);
        A59.add(A62);
        A59.add(A63);
        A59.add(A64);
        for (int i = 0; i < 225; i++) {
            A65[i][0] = i;
            A65[i][1] = 1253 + i;
            A65[i][2] = 296;
            A65[i][3] = 1;
            A65[i][4] = 1;
        }
        for (int i = 0; i < 248; i++) {
            A66[i][0] = i;
            A66[i][1] = 1250 + i;
            A66[i][2] = 422;
            A66[i][3] = 0;
            A66[i][4] = 0;
        }
        for (int i = 0; i < 267; i++) {
            A67[i][0] = i;
            A67[i][1] = 1252 + i;
            A67[i][2] = 550;
            A67[i][3] = 0;
            A67[i][4] = 0;
        }
        for (int i = 0; i < 187; i++) {
            A68[i][0] = i;
            A68[i][1] = 1252 + i;
            A68[i][2] = 676;
            A68[i][3] = 1;
            A68[i][4] = 1;
        }
        for (int i = 0; i < 69; i++) {
            A69[i][0] = i;
            A69[i][1] = 1253 + i;
            A69[i][2] = 804;
            A69[i][3] = 1;
            A69[i][4] = 1;
        }
        A70.add(A65);
        A70.add(A66);
        A70.add(A67);
        A70.add(A68);
        A70.add(A69);
        for (int i = 0; i < 1919; i++) {
            a72[i][0] = i;
            a72[i][1] = 0 + i;
            a72[i][2] = 23;
            a72[i][3] = 1;
            a72[i][4] = 1;
        }
        a71.add(a72);
        for (int i = 1; i <= 21; i++) {
            q4.add("gameResourse2/resourseImages/ImagesForScreenSaver/backgroundForGeneralFinishAnimation/2collectionTransparensyBackgroundFinish/" + i + ".png");
        }
    }

    public void update() {
        q134();
    }

    public void q134() {
        if (System.currentTimeMillis() > a3) {
            a4 = true;
            a9 = true;
        }
        if (System.currentTimeMillis() > a2) {
            A56 = true;
            A57 = true;
        }
    }

    public void q35(int i) {
        A23++;
        if (A23 == 1) {
            A23 = 0;
            a16[i] = a16[i] + 0.0174533 * a13[i][8];
            if (a16[i] >= 12.566375999999847) {
                a16[i] = 0.0;
                q11++;
                if (q11 == 5) {
                    q7 = true;
                }
            }
        }
    }

    public void q36() {
        if (a10 == a7.size() - 1) {
            a10 = 20;
            A19++;
            if (A19 == 0) {
                a18 = true;
            }
        }
        a11++;
        if (a11 == 5) {
            a10++;
            a11 = 0;
        }
    }

    public void q37(int i) {
        if (a13[i][1] > a13[i][3]) {
            a13[i][1]--;
        }
        if (a13[i][1] < a13[i][3]) {
            a13[i][1]++;
        }
        if (a13[i][1] == a13[i][3]) {
            A22 = true;
            a18 = false;
            return;
        }
    }

    public void q38(int i) {
        a14++;
        if (a14 == 6) {
            a14 = 0;
            a13[i][7]--;
            if (a13[4][7] == -5) {
                A24 = true;
                a17 = true;
                A22 = false;
            }
        }
    }

    public void q39() {
        if (A32 == 5) {
            A35 = false;
            a93 = true;
        }
        if (A35 == true) {
            if (A31 == 0) {
                A26 = new StringBuilder();
                A34++;
                A25.add(A26);
                A29 = A27[A32].toCharArray();
            }
            A30 = A29[A31];
            A31++;
            if (A31 == A29.length) {
                A32++;
                if (A32 >= A27.length) {
                    A32 = 0;
                }
                A31 = 0;
            }
            A25.get(A34).append(A30);
        }
    }


    public void q40() {
        if (A47.size() == 0) {
            for (int i = 0; i <= 81; i++) {
                A46 = new ArrayList<int[]>();
                A46.add(new int[]{A49 + (i * 3), A50, 22});
                A47.add(A46);
            }
        }
        for (int i = 0; i < A47.size(); i++) {
            for (int j = 0; j < A47.get(i).size(); j++) {
                A47.get(i).get(j)[1] = A47.get(i).get(j)[1] + A55;
                if (A47.get(i).get(j)[1] > A54) {
                    A47.get(i).remove(j);
                }
                if (A47.get(i).get(A47.get(i).size() - 1)[1] >= A50) {
                    q41(i);
                }
            }
        }
    }

    public void q41(int i) {
        int q43;
        q43 = (int) (1 + (Math.random() * 6));
        if (q43 <= 5) {
            q45(i);
        }
        if (q43 == 6) {
            q48(i);
        }
    }

    public void q48(int i) {
        int q50 = 0;
        A40 = new ArrayList<>();
        int q51 = (int) (1 + (Math.random() * 7));
        if (q51 == 1) {
            q50 = 21;
            A48 = 1;
        }
        if (q51 == 2) {
            q50 = 11;
            A48 = 2;
        }
        if (q51 == 3) {
            q50 = 7;
            A48 = 3;
        }
        if (q51 == 4) {
            q50 = 6;
            A48 = 4;
        }
        if (q51 == 5) {
            q50 = 5;
            A48 = 5;
        }
        if (q51 == 6) {
            q50 = 4;
            A48 = 6;
        }
        if (q51 == 7) {
            q50 = 3;
            A48 = 7;
        }
        for (int j = 0; j < q50; j++) {
            A45 = new int[3];

            A45[0] = A49 + (i * 3);
            A45[1] = A50 - (j * A48);
            A45[2] = j * A48 + 1;
            A47.get(i).add(A45);
        }
    }

    public void q45(int i) {
        int q56 = 0;

        A40 = new ArrayList<>();
        int q57 = (int) (1 + (Math.random() * 5));
        if (q57 == 1) {
            q56 = 21;
            A48 = 1;
        }
        if (q57 == 2) {
            q56 = 11;
            A48 = 2;
        }
        if (q57 == 3) {
            q56 = 7;
            A48 = 3;
        }
        if (q57 == 4) {
            q56 = 6;
            A48 = 4;
        }
        if (q57 == 5) {
            q56 = 5;
            A48 = 5;
        }
        if (q57 == 6) {
            q56 = 4;
            A48 = 6;
        }
        if (q57 == 7) {
            q56 = 3;
            A48 = 7;
        }
        for (int j = 0; j < q56; j++) {
            A45 = new int[3];
            A45[0] = A49 + (i * 3);
            A45[1] = A50 - (j * A48);
            A45[2] = 22;
            A47.get(i).add(A45);
        }
    }

    public void q71(int i, int j) {
        A36.get(i).get(j)[2] = A36.get(i).get(j)[2] - A36.get(i).get(j)[8];
        if (A36.get(i).get(j)[2] <= 0) {
            int q72 = A36.get(i).get(j)[3];
            int q73 = A36.get(i).get(j)[4];
            int q75 = A36.get(i).get(j)[6];
            int q76 = A36.get(i).get(j)[1];
            A36.get(i).remove(j);
            A41 = new int[10];
            A41[0] = 1;
            A41[1] = q76;
            A41[2] = 21;

            A41[3] = q72;
            A41[4] = q73 + (A41[1] * A42) + A42;
            A41[5] = q72;
            A41[6] = q75;
            A41[7] = A36.get(i).get(0)[7];
            A41[8] = A36.get(i).get(0)[8];
            A41[9] = 0;
            A36.get(i).add(A41);
        }
        A38 = 0;
        if (A38 == 0) {
            A37 = A43.get(A36.get(i).get(j)[2]);
        }
    }

    public void q79() {
        for (int i = 0; i < A39.length; i++) {
            if (A39[i] <= 0) {
                q80(i);
            }
        }
    }

    public void q80(int i) {
        int q81;
        q81 = (int) (1 + (Math.random() * 2));

        if (q81 == 1) {
            int q82;
            q82 = (int) (1 + (Math.random() * 4));
            A39[i] = q82;
        }
        if (q81 == 2) {
            q83(i);
        }
    }

    public void q83(int i) {
        int q86 = 0;
        A40 = new ArrayList<>();
        int q88 = (int) (1 + (Math.random() * 7));
        if (q88 == 1) {
            q86 = 21;
            A48 = 1;
        }
        if (q88 == 2) {
            q86 = 11;
            A48 = 2;
        }
        if (q88 == 3) {
            q86 = 7;
            A48 = 3;
        }
        if (q88 == 4) {
            q86 = 6;
            A48 = 4;
        }
        if (q88 == 5) {
            q86 = 5;
            A48 = 5;
        }
        if (q88 == 6) {
            q86 = 4;
            A48 = 6;
        }
        if (q88 == 7) {
            q86 = 3;
            A48 = 7;
        }
        A39[i] = q86;
        A40 = new ArrayList<>();
        for (int j = 0; j < q86; j++) {
            A41 = new int[10];
            A41[0] = 1;
            A41[1] = q86;
            A41[2] = j * A48 + 1;
            A41[3] = A58 + (i * 3);
            A41[4] = A50 + (j * A42);
            A41[5] = A52 + (i * 3);
            A41[6] = A54;
            A41[7] = A42;
            A41[8] = A48;
            A41[9] = 0;
            A40.add(A41);
        }
        A36.add(A40);
    }

    public void q90(int i, int j) {
        if (j == 0) {
            A59.get(i)[j][4] = (int) (0 + (Math.random() * 37));
        }
        if (j == 3) {
            A59.get(i)[j][4] = (int) (0 + (Math.random() * 27));
        }
        A59.get(i)[j][4] = (int) (0 + (Math.random() * 25));
    }


    public void q91(int i, int j) {
        if (j == 0) {
            A70.get(i)[j][4] = (int) (30 + (Math.random() * 17));
        }
        if (j == 3) {
            A70.get(i)[j][4] = (int) (30 + (Math.random() * 17));
        }
        A70.get(i)[j][4] = (int) (30 + (Math.random() * 17));
    }


    public void q92(int i, int j) {
        a71.get(i)[j][4] = (int) (152 + (Math.random() * 50));
    }

    public void q93() {
        if (q8 >= q4.size() - 1) {
            return;
        }
        q10++;
        if (q10 == 2) {
            q8++;
            q10 = 0;
        }
    }


    public void draw(Graphics2D g) {
        if (a4 == true) {
            g.drawImage(a5, 0, 0, null);
            if (a9 == true) {
                q36();
                a8 = a7.get(a10);
                g.drawImage(new ImageIcon(a8).getImage(), 0, 0, null);
            }
            if (a18 == true) {
                for (int i = 0; i <= A20.size() - 1; i++) {
                    q37(i);
                    A21 = A20.get(i);
                    g.drawImage(new ImageIcon(A21).getImage(), a13[i][1], a13[i][2], null);
                }
                g.drawImage(a12, 0, 0, null);
            }
            if (A22 == true) {
                for (int i = 0; i <= A20.size() - 1; i++) {
                    q38(i);
                    if (a13[i][7] != 1) {
                        A21 = A20.get(i);
                        g.drawImage(new ImageIcon(A21).getImage(), a13[i][1], a13[i][2], null);
                    }
                }
            }
            if (a17 == true) {
                for (int i = 0; i < a13.length; i++) {
                    AffineTransform affineTransform;
                    affineTransform = g.getTransform();
                    AffineTransform newAffineTransform = (AffineTransform) (affineTransform.clone());
                    q35(i);
                    newAffineTransform.rotate(a16[i], a13[i][5], a13[i][6]);
                    g.setTransform(newAffineTransform);
                    A21 = A20.get(i);
                    g.drawImage(new ImageIcon(A21).getImage(), 0, 0, null);
                    g.setTransform(affineTransform);
                }
            }
            if (a93 == true) {
                for (int i = 0; i < A70.size(); i++) {
                    for (int j = 0; j < A70.get(i).length; j++) {
                        if (A70.get(i)[j][3] == A70.get(i)[j][4]) {
                            q91(i, j);
                        }
                        for (int k = 0; k < A70.get(i)[j][3]; k++) {
                            g.drawImage(new ImageIcon(a92).getImage(), A70.get(i)[j][1], A70.get(i)[j][2] - (k * 1), null);
                        }
                        if (A70.get(i)[j][3] < A70.get(i)[j][4]) {
                            A70.get(i)[j][3]++;
                        }
                        if (A70.get(i)[j][3] > A70.get(i)[j][4]) {
                            A70.get(i)[j][3]--;
                        }
                    }
                }
            }

            if (A24 == true) {
                q39();
                for (int i = 0; i < A25.size(); i++) {
                    Color color1 = new Color(80, 182, 252);
                    g.setColor(color1);
                    Font myFont = new Font(null, Font.BOLD, 40);
                    g.setFont(myFont);
                    g.drawString(String.valueOf(A25.get(i)), 1250, 289 + (i * 127));
                }
            }
            if (a93 == true) {
                for (int i = 0; i < A59.size(); i++) {
                    for (int j = 0; j < A59.get(i).length; j++) {
                        if (A59.get(i)[j][3] == A59.get(i)[j][4]) {
                            q90(i, j);
                        }
                        for (int k = 0; k < A59.get(i)[j][3]; k++) {
                            if (A59.get(i)[j][3] + 1 == A59.get(i)[j][4]) {
                                g.drawImage(new ImageIcon(a88).getImage(), A59.get(i)[j][1], A59.get(i)[j][2] - (k + 2 * 1), null);
                            }
                            if (A59.get(i)[j][3] - 1 == A59.get(i)[j][4]) {
                                g.drawImage(new ImageIcon(a88).getImage(), A59.get(i)[j][1], A59.get(i)[j][2] - (k + 2 * 1), null);
                            }
                            if (A59.get(i)[j][3] + 1 == A59.get(i)[j][4]) {
                                g.drawImage(new ImageIcon(a83).getImage(), A59.get(i)[j][1], A59.get(i)[j][2] - (k + 1 * 1), null);
                            }
                            if (A59.get(i)[j][3] - 1 == A59.get(i)[j][4]) {
                                g.drawImage(new ImageIcon(a83).getImage(), A59.get(i)[j][1], A59.get(i)[j][2] - (k + 1 * 1), null);
                            }
                            g.drawImage(new ImageIcon(a82).getImage(), A59.get(i)[j][1], A59.get(i)[j][2] - (k * 1), null);
                        }
                        if (A59.get(i)[j][3] < A59.get(i)[j][4]) {
                            A59.get(i)[j][3]++;
                        }
                        if (A59.get(i)[j][3] > A59.get(i)[j][4]) {
                            A59.get(i)[j][3]--;
                        }
                    }
                }
            }
        }
        if (A56 == true) {
            q40();
            for (int i = 0; i < A47.size(); i++) {
                for (int j = 0; j < A47.get(i).size(); j++) {
                    A44 = A43.get(A47.get(i).get(j)[2]);
                    g.drawImage(new ImageIcon(A44).getImage(), A47.get(i).get(j)[0], A47.get(i).get(j)[1], null);
                }
            }
        }
        if (A57 == true) {
            for (int i = 0; i < A36.size(); i++) {
                for (int j = 0; j < A36.get(i).size() - 1; j++) {
                    if (A36.get(i).get(j)[4] >= A50 || A36.get(i).get(j)[4] <= A54 || A36.get(i).get(j)[3] > A58 || A36.get(i).get(j)[3] < A52) {
                        q71(i, j);
                        g.drawImage(new ImageIcon(A37).getImage(), A36.get(i).get(j)[3], A36.get(i).get(j)[4], null);
                        if (A36.get(i).get(j)[4] >= A54 || A36.get(i).get(j)[3] < A58 || A36.get(i).get(j)[3] > A52) {
                            A36.get(i).remove(j);
                        }
                    }
                }
            }
            for (int i = 0; i < A39.length; i++) {
                A39[i]--;
            }
            q79();
        }
        if (q7 == true) {
            q93();
            q5 = q4.get(q8);
            g.drawImage(new ImageIcon(q5).getImage(), 0, 0, null);
        }
    }
}
