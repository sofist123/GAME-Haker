package gameExample_6_____reliz__3.ObjectsForTheFinalAnimation;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Created by sofis on 23.06.2020.
 */
public class Server {
    long a1 = System.currentTimeMillis();
    long a2 = a1 + 424 * 1000;
    private boolean a3 = false;
    private boolean a4 = false;
    private int a5 = 0;
    private Image a6;
    private int a8 = 0;
    private int a9 = -850;
    private int a10 = 0;
    private int a11 = 50;
    private boolean a12 = false;
    private int a13 = 0;
    private int a14 = 195;
    private int a15 = 1;
    ArrayList<String> a16 = new ArrayList<>();
    private String a17;
    private int a18 = 0;
    private boolean a19 = false;
    private Image backgroundForAnimationAnderServer;
    private boolean a21 = false;
    private Image a22;
    private int a23 = 0;
    private int a24 = 621;
    private int a25 = 0;
    private int a26 = 0;
    private boolean a27 = false;
    private Image a28;
    private int a29 = 158;
    private int a30 = 0;
    private int a31 = 0;
    private int a32 = 0;
    private boolean a33 = false;
    private Image a35;
    private int a36 = -158;
    private int a38 = 0;
    private int a39 = 0;
    private int a40 = 0;
    private boolean a41 = false;
    private Image a43;
    private Image a44;
    private int a45 = 0;
    private int a47 = 0;
    long a49 = a1 + 590 * 1000;
    private boolean a50 = false;

    public Server() throws IOException {
        a6 = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/server/2backgroundServer.png"));
        for (int i = 1; i <= 13; i++) {
            a16.add("gameResourse2/resourseImages/ImagesForScreenSaver/eraser/" + i + ".png");
        }
        backgroundForAnimationAnderServer = ImageIO.read(new File("gameResourse/resourseImages/ImagesForScreenSaver/server/backgroundForAnimationAnderServer.png"));
        a22 = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/server/2centr.png"));
        a28 = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/server/2left.png"));
        a35 = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/server/2right.png"));
        a43 = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/server/2serverComplexBacklightBackground.png"));
        a44 = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/server/2serverComplexBackground.png"));
    }

    Timer a70 = new Timer(a11, new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            switch (a10) {
                case 0:
                    a9 = a9 + 10;
                    if (a9 >= 0) {
                        a10++;
                    }
                case 1:
                    a70.stop();
                    break;
                default:
                    System.out.println("!");
            }
        }
    });

    public void update() {
        a71();
        if (a10 == 1) {
            a12 = true;
        }
    }

    public void a71() {
        if (System.currentTimeMillis() > a2) {
            a5++;
            if (a5 == 1) {
                a4 = true;
            }
            a70.start();
        }
        if (System.currentTimeMillis() > a49) {
            a50 = true;
        }
    }

    public void a75() {
        if (a13 >= a14) {
            a13 = a14;
            return;
        }
        a13 = a13 + a15;
        a19 = true;
    }

    public void a77() {
        a18++;
        if (a18 >= 13) {
            a18 = 0;
        }
        if (a13 == a14) {
            a19 = false;
            a21 = true;
            a27 = true;
        }
    }

    public void a80(int a) {
        if (a == 1) {
            a24 = a24 - 1;
            if (a24 <= a26) {
                a24 = a26;
                a33 = true;
                a41 = true;
                a21 = false;
            }
        }
        if (a == 2) {
            a29 = a29 - 1;
            if (a29 <= a31) {
                a29 = a31;
                a33 = false;
                a3 = true;
            }
        }
        if (a == 3) {
            a36 = a36 + 1;
            if (a36 >= a39) {
                a36 = a39;
                a41 = false;
            }
        }
    }

    public void a81() {
        a45++;
        if (a45 % 2 == 0) {
        }
    }

    public void draw(Graphics2D g) {
        if (a50 == false) {
            if (a3 == false) {
                if (a4 == true) {
                    g.drawImage(new ImageIcon(a6).getImage(), a8, a9, null);
                }
            }
            if (a33 == true) {
                a80(2);
                g.drawImage(new ImageIcon(a28).getImage(), a29, a30, null);
            }
            if (a41 == true) {
                a80(3);
                g.drawImage(new ImageIcon(a35).getImage(), a36, a38, null);
            }
            if (a27 == true) {
                a80(1);
                g.drawImage(new ImageIcon(a22).getImage(), a23, a24, null);
            }
            if (a21 == true) {
                g.drawImage(new ImageIcon(backgroundForAnimationAnderServer).getImage(), 0, 0, null);
            }
            if (a12 == true) {
                Color colorGap = new Color(106, 10, 22);
                g.setColor(colorGap);
                a75();
                g.fillRect(1396, 796, (a13), 3);
                if (a19 == true) {
                    a77();
                    a17 = a16.get(a18);
                    g.drawImage(new ImageIcon(a17).getImage(), 1385 + a13, 785, null);
                }
            }
            if (a3 == true) {
                if (a45 <= 10) {
                    a47++;
                    if (a47 == 3) {
                        a45++;
                        a47 = 0;
                    }
                    if (a45 % 2 == 0) {
                        g.drawImage(new ImageIcon(a44).getImage(), 0, 0, null);
                    }
                    if (a45 % 2 != 0) {
                        g.drawImage(new ImageIcon(a43).getImage(), 0, 0, null);
                    }
                }
                if (a45 >= 11) {
                    g.drawImage(new ImageIcon(a43).getImage(), 0, 0, null);
                }
            }
        }
    }
}
