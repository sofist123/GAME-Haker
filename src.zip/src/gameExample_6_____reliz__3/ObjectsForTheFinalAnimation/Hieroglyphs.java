package gameExample_6_____reliz__3.ObjectsForTheFinalAnimation;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Created by sofis on 02.06.2020.
 */
public class Hieroglyphs {
    long a1 = System.currentTimeMillis();
    long a2 = a1 + 426 * 1000;
    long a3 = a1 + 567 * 1000;
    long a4 = a1 + 590 * 1000;
    private boolean a5 = false;
    private boolean a6 = false;
    ArrayList<String> a7 = new ArrayList<>();
    private int a8 = 0;
    private int a9 = 0;
    private String a10;
    private int a11;
    private ArrayList<int[]> a12 = new ArrayList<int[]>();
    private int a13;
    private ArrayList<ArrayList<int[]>> a15 = new ArrayList<ArrayList<int[]>>();
    ArrayList<String> a16 = new ArrayList<>();
    ArrayList<String> a17 = new ArrayList<>();
    private int a18 = 10;
    private int a19 = 731;
    private int a20 = 170;
    private int a21 = 1043;
    private int a22 = 620;
    private int[] a23 = {
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    };
    private int[] a24 = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,};
    private int a25 = 50;
    private Image a26;
    private long a27 = a1 + 590 * 1000;
    private boolean a28 = false;


    public Hieroglyphs() throws IOException {
        for (int i = 1; i <= 22; i++) {
            a16.add("gameResourse2/resourseImages/ImagesForScreenSaver/hieroglyphTransparent2/s0/" + i + ".png");
        }
        for (int i = 1; i <= 22; i++) {
            a17.add("gameResourse2/resourseImages/ImagesForScreenSaver/hieroglyphTransparent2/s1/" + i + ".png");
        }
        for (int i = 1; i <= 23; i++) {
            a7.add("gameResourse2/resourseImages/ImagesForScreenSaver/backgroundMatrix/2frameWindow/" + i + ".png");
        }
        a26 = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/backgroundMatrix/2bottomBlue.png"));
    }

    Timer a29 = new Timer(a25, new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            for (int i = 0; i < a15.size(); i++) {
                for (int j = 0; j < a15.get(i).size(); j++) {
                    switch (a15.get(i).get(j)[9]) {
                        case 0:
                            if (a15.get(i).get(j)[4] < a15.get(i).get(j)[6]) {
                                a15.get(i).get(j)[4] = a15.get(i).get(j)[4] + a18;
                            }
                            if (a15.get(i).get(j)[4] >= a15.get(i).get(j)[6]) {
                                a15.get(i).get(j)[9]++;
                            }
                            break;
                        case 1:
                            break;
                        default:
                            System.out.println("что-то пошло не так2!!!");
                    }
                }
            }
        }
    });

    public void update() {
        a30();
        a29.start();
        a31();
        a32();
        a33();

    }

    public void a30() {
        if (System.currentTimeMillis() > a2) {
            a5 = true;
        }
    }

    public void a31() {
        if (System.currentTimeMillis() > a3) {
            a6 = true;
        }
    }

    public void a32() {
        if (System.currentTimeMillis() > a4) {
            a6 = false;
        }
    }


    public void a33() {
        if (System.currentTimeMillis() > a27) {
            a28 = true;
        }
    }

    public void a34(int i) {
        int a35 = 0;
        a12 = new ArrayList<>();
        int a36 = (int) (1 + (Math.random() * 7));
        if (a36 == 1) {
            a35 = 21;
            a13 = 1;
        }
        if (a36 == 2) {
            a35 = 11;
            a13 = 2;
        }
        if (a36 == 3) {
            a35 = 7;
            a13 = 3;
        }
        if (a36 == 4) {
            a35 = 6;
            a13 = 4;
        }
        if (a36 == 5) {
            a35 = 5;
            a13 = 5;
        }
        if (a36 == 6) {
            a35 = 4;
            a13 = 6;
        }
        if (a36 == 7) {
            a35 = 3;
            a13 = 7;
        }
        a24[i] = a35;
        a12 = new ArrayList<>();
        for (int j = 0; j < a35; j++) {
            a23 = new int[10];
            a23[0] = 1;
            a23[1] = a35;
            a23[2] = j * a13 + 1;
            a23[3] = a19 + (i * 8);
            a23[4] = a20 + (j * 13);
            a23[5] = a21 + (i * 8);
            a23[6] = a22;
            a23[7] = a18;
            a23[8] = a13;
            a23[9] = 0;
            a12.add(a23);
        }
        a15.add(a12);

    }

    public void a38() {
        for (int i = 0; i < a24.length; i++) {
            if (a24[i] <= 0) {
                a39(i);
            }
        }
    }

    public void a39(int i) {
        int a41;
        if (a6 == true) {
            a24[i] = 100;
            return;
        }
        a41 = (int) (1 + (Math.random() * 2));
        if (a41 == 1) {
            int a42;
            a42 = (int) (1 + (Math.random() * 4));
            a24[i] = a42;
        }
        if (a41 == 2) {
            a34(i);
        }
    }

    public void a43(int i, int j) {
        a15.get(i).get(j)[2] = a15.get(i).get(j)[2] - a15.get(i).get(j)[8];
        if (a15.get(i).get(j)[2] <= 0) {
            int a50 = a15.get(i).get(j)[3];
            int a51 = a15.get(i).get(j)[4];
            int a52 = a15.get(i).get(j)[6];
            int a53 = a15.get(i).get(j)[1];
            a15.get(i).remove(j);
            a23 = new int[10];
            a23[0] = 1;
            a23[1] = a53;
            a23[2] = 21;
            a23[3] = a50;
            a23[4] = a51 + (a23[1] * 13) + 13;
            a23[5] = a50;
            a23[6] = a52;
            a23[7] = a15.get(i).get(0)[7];
            a23[8] = a15.get(i).get(0)[8];
            a23[9] = 0;
            a15.get(i).add(a23);
        }
        a11 = (int) (0 + (Math.random() * 2));
        if (a11 == 0) {
            a10 = a16.get(a15.get(i).get(j)[2]);
        }
        if (a11 == 1) {
            a10 = a17.get(a15.get(i).get(j)[2]);
        }
    }

    public void a55() {
        if (a8 == a7.size() - 1) {
            a8 = 0;
        }
        a9++;
        if (a9 == 5) {
            a8++;
            a9 = 0;
        }
    }


    public void draw(Graphics2D g) {
        if (a28 == false) {
            if (a5 == true) {
                g.drawImage(new ImageIcon(a26).getImage(), -550, 12, null);
                for (int i = 0; i < a15.size(); i++) {
                    for (int j = 0; j < a15.get(i).size() - 1; j++) {
                        if (a15.get(i).get(j)[4] >= a20 || a15.get(i).get(j)[4] <= a22 || a15.get(i).get(j)[3] > a19 || a15.get(i).get(j)[3] < a21) {
                            a43(i, j);
                            g.drawImage(new ImageIcon(a10).getImage(), a15.get(i).get(j)[3], a15.get(i).get(j)[4], null);
                            if (a15.get(i).get(j)[4] >= a22 || a15.get(i).get(j)[3] < a19 || a15.get(i).get(j)[3] > a21) {
                                a15.get(i).remove(j);
                            }
                        }
                    }
                }
                for (int i = 0; i < a24.length; i++) {
                    a24[i]--;
                }
                a38();
            }
        }
    }
}


