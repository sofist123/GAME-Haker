package gameExample_6_____reliz__3;

import javax.swing.*;
import java.awt.*;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.IOException;

/**
 * Created by sofis on 28.05.2019.
 */
public class GameStartScreenSaver {

    public static void main(String[] args) throws InterruptedException, UnsupportedFlavorException, IOException {

        SplashScreen splashScreen = SplashScreen.getSplashScreen();
//        Rectangle bounds = splashScreen.getBounds();
//        Graphics2D g2 = splashScreen.createGraphics();
//        Color colorProgressBar = new Color(47, 91, 242);
//        g2.setColor(colorProgressBar);
//        for (int i = 0; i <= 100; i++) {
//            g2.fillRect(0, 0, bounds.width * i / 100, 10);
//            splashScreen.update();
//            Thread.sleep(100);
//        }
        GamePanelScreenSaver panel = new GamePanelScreenSaver();
        JFrame startFrame = new JFrame("Territory of cyber dangers");
        startFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        startFrame.setContentPane(panel);
        startFrame.setLocation(-7, 0);
        startFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        startFrame.pack();
        panel.start();
        startFrame.setVisible(true);


















    }
}
