package gameExample_6_____reliz__3.ObjectsForTheFinalAnimation;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.AffineTransform;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;


/**
 * Created by sofis on 09.07.2020.
 */
public class GeneralFinishAnimation {
    long s1 = System.currentTimeMillis();
    long s2 = s1 + 572 * 1000;
    private boolean s3 = false;
    private Image backgroundForGeneralFinishAnimation;
    private Image s5;
    private int s6 = 106;
    private int s7 = 90;
    private int s8 = 0;
    private int s9 = 0;
    private int s10 = 959;
    private int s11 = 539;
    private double s12 = 0;
    private int s13 = 0;
    private int s14 = 0;
    private double s15 = 0.0174533 * 1;
    private ArrayList<String> s16 = new ArrayList<>();
    private String s17;
    private double[][] s18 = {
            {0, 2, 0.0, 6.2831879999999645,},
            {1, 2, 0.7853985000000001, 7.06858649999995},
            {2, 2, 1.5707969999999967, 7.853984999999935},
            {3, 2, 2.3561954999999966, 8.639383499999921},
            {4, 2, 3.1415940000000018, 9.424781999999906},
            {5, 2, 3.926992500000007, 10.210180499999892},
            {6, 2, 4.712390999999994, 10.995578999999877},
            {7, 2, 5.497789499999979, 11.780977499999862},};
    private int[][] s19 = {
            {140, 0, 0, 0, -1210, 0,},
            {1, 0, 0, 1210, -1210, 0,},
            {20, 0, 0, 1210, 0, 0,},
            {40, 0, 0, 1210, 1210, 0,},
            {60, 0, 0, 0, 1210, 0,},
            {80, 0, 0, -1210, 1210, 0,},
            {100, 0, 0, -1210, 0, 0,},
            {120, 0, 0, -1210, -1210, 0,},
    };
    private ArrayList<String> s20 = new ArrayList<>();
    private String s21;
    private boolean s22 = false;
    private int s23 = 0;
    private int s24 = 0;
    private int s25 = -1;
    private Image s26;
    private Image s27;
    private Image s28;
    private Image s29;
    private int s30 = 0;
    private int s31 = 0;
    private int s32 = -260;
    private int[][] s33 = {
            {1, 650, -650, 0, 0, 1, 0,},
            {2, -650, -650, 0, 0, 1, 0,},
            {3, 0, 2600, 0, 0, 1, 0,},};
    private int s34 = 50;
    private int s35 = 2;
    private boolean s36 = false;
    private boolean s37 = false;
    long s38 = s1 + 577 * 1000;
    private boolean s39 = false;
    private ArrayList<ArrayList<int[]>> s40 = new ArrayList<ArrayList<int[]>>();
    private int s41 = 50;
    private String s42;
    private int s43;
    private int[] s44 = {
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    };
    ArrayList<String> s45 = new ArrayList<>();
    ArrayList<String> s46 = new ArrayList<>();
    ArrayList<String> s47 = new ArrayList<>();
    ArrayList<String> s48 = new ArrayList<>();
    ArrayList<String> s49 = new ArrayList<>();
    ArrayList<String> s50 = new ArrayList<>();
    ArrayList<String> s51 = new ArrayList<>();
    ArrayList<String> s52 = new ArrayList<>();
    ArrayList<String> s53 = new ArrayList<>();
    ArrayList<String> s54 = new ArrayList<>();
    ArrayList<String> s55 = new ArrayList<>();
    ArrayList<String> s56 = new ArrayList<>();
    ArrayList<String> s57 = new ArrayList<>();
    ArrayList<String> s59 = new ArrayList<>();
    ArrayList<String> s60 = new ArrayList<>();
    ArrayList<String> s61 = new ArrayList<>();
    ArrayList<String> s63 = new ArrayList<>();
    private int s65 = -8;
    private int s66 = -20;
    private int s67 = 1920;
    private int s69 = 1080;
    private int[] s70 = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,};
    private int s71 = 10;
    private ArrayList<int[]> s72 = new ArrayList<int[]>();
    private int aas234;
    ArrayList<String> s73 = new ArrayList<>();
    private String s74;
    private boolean s75 = false;
    private int s76 = -1;
    private int s77 = 0;
    private int s78 = -240;
    private long s80 = s1 + 635 * 1000;
    private boolean s81 = true;
    private ArrayList<StringBuilder> s82 = new ArrayList<>();
    private StringBuilder s83 = new StringBuilder();
    private String[] s84 = new String[16];
    private char[] s85;
    private char s86;
    private int s87 = 0;
    private int s88 = 0;
    private int s89 = -1;
    private boolean s90 = false;
    private int s91 = -1;
    private int[][] s92 = new int[16][54];
    private int[][] s94 = new int[16][54];
    private int[][] s95 = new int[16][54];
    private int[][] s97 = new int[16][54];
    private ArrayList<char[]> s99 = new ArrayList<>();
    private char[] s100;
    private ArrayList<char[]> s101 = new ArrayList<>();
    private Image ss1;
    private boolean a1 = false;
    private boolean a2 = false;
    private int a3 = 50;
    private int a4 = 3;
    ArrayList<String> a5 = new ArrayList<>();
    private String a6;
    private int a7 = 0;
    private ArrayList<String> a8 = new ArrayList<>();
    private String a9;
    private boolean a10 = false;
    private int a11 = 0;
    private int a12 = 0;
    private ArrayList<String> a13 = new ArrayList<>();
    private String a14;
    private boolean a15 = false;
    private int a16 = 0;
    private int a17 = 0;

    public GeneralFinishAnimation() throws IOException {
        backgroundForGeneralFinishAnimation = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/backgroundForGeneralFinishAnimation/2backgroundForGeneralFinishAnimation.png"));
        for (int i = 1; i <= 21; i++) {
            s73.add("gameResourse2/resourseImages/ImagesForScreenSaver/transparencyRoundBackground/" + i + ".png");
        }
        s5 = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/backgroundForGeneralFinishAnimation/2triangl.png"));
        for (int i = 0; i <= 7; i++) {
            s16.add("gameResourse2/resourseImages/ImagesForScreenSaver/backgroundForGeneralFinishAnimation/2collectionTriangls/" + i + ".png");
        }
        for (int i = 1; i <= 16; i++) {
            s20.add("gameResourse2/resourseImages/ImagesForScreenSaver/backgroundForGeneralFinishAnimation/2collectionTransparensyBackground/" + i + ".png");
        }
        s26 = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/backgroundForGeneralFinishAnimation/2collectionForTriangleAssembly/right.png"));
        s27 = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/backgroundForGeneralFinishAnimation/2collectionForTriangleAssembly/left.png"));
        s28 = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/backgroundForGeneralFinishAnimation/2collectionForTriangleAssembly/down.png"));
        s29 = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/backgroundForGeneralFinishAnimation/2collectionForTriangleAssembly/general.png"));
        for (int i = 1; i <= 22; i++) {
            s45.add("gameResourse2/resourseImages/ImagesForScreenSaver/hieroglyphTransparent2/0/" + i + ".png");   //заполнение коллекции hieroglyph картинками иероглифов
        }
        for (int i = 1; i <= 22; i++) {
            s46.add("gameResourse2/resourseImages/ImagesForScreenSaver/hieroglyphTransparent2/1/" + i + ".png");   //заполнение коллекции hieroglyph картинками иероглифов
        }
        for (int i = 1; i <= 22; i++) {
            s47.add("gameResourse2/resourseImages/ImagesForScreenSaver/hieroglyphTransparent2/2/" + i + ".png");   //заполнение коллекции hieroglyph картинками иероглифов
        }
        for (int i = 1; i <= 22; i++) {
            s48.add("gameResourse2/resourseImages/ImagesForScreenSaver/hieroglyphTransparent2/3/" + i + ".png");   //заполнение коллекции hieroglyph картинками иероглифов
        }
        for (int i = 1; i <= 22; i++) {
            s49.add("gameResourse2/resourseImages/ImagesForScreenSaver/hieroglyphTransparent2/4/" + i + ".png");   //заполнение коллекции hieroglyph картинками иероглифов
        }
        for (int i = 1; i <= 22; i++) {
            s50.add("gameResourse2/resourseImages/ImagesForScreenSaver/hieroglyphTransparent2/5/" + i + ".png");   //заполнение коллекции hieroglyph картинками иероглифов
        }
        for (int i = 1; i <= 22; i++) {
            s51.add("gameResourse2/resourseImages/ImagesForScreenSaver/hieroglyphTransparent2/6/" + i + ".png");   //заполнение коллекции hieroglyph картинками иероглифов
        }
        for (int i = 1; i <= 22; i++) {
            s52.add("gameResourse2/resourseImages/ImagesForScreenSaver/hieroglyphTransparent2/7/" + i + ".png");   //заполнение коллекции hieroglyph картинками иероглифов
        }
        for (int i = 1; i <= 22; i++) {
            s53.add("gameResourse2/resourseImages/ImagesForScreenSaver/hieroglyphTransparent2/8/" + i + ".png");   //заполнение коллекции hieroglyph картинками иероглифов
        }
        for (int i = 1; i <= 22; i++) {
            s54.add("gameResourse2/resourseImages/ImagesForScreenSaver/hieroglyphTransparent2/9/" + i + ".png");   //заполнение коллекции hieroglyph картинками иероглифов
        }
        for (int i = 1; i <= 22; i++) {
            s55.add("gameResourse2/resourseImages/ImagesForScreenSaver/hieroglyphTransparent2/10/" + i + ".png");   //заполнение коллекции hieroglyph картинками иероглифов
        }
        for (int i = 1; i <= 22; i++) {
            s56.add("gameResourse2/resourseImages/ImagesForScreenSaver/hieroglyphTransparent2/11/" + i + ".png");   //заполнение коллекции hieroglyph картинками иероглифов
        }
        for (int i = 1; i <= 22; i++) {
            s57.add("gameResourse2/resourseImages/ImagesForScreenSaver/hieroglyphTransparent2/12/" + i + ".png");   //заполнение коллекции hieroglyph картинками иероглифов
        }
        for (int i = 1; i <= 22; i++) {
            s59.add("gameResourse2/resourseImages/ImagesForScreenSaver/hieroglyphTransparent2/13/" + i + ".png");   //заполнение коллекции hieroglyph картинками иероглифов
        }
        for (int i = 1; i <= 22; i++) {
            s60.add("gameResourse2/resourseImages/ImagesForScreenSaver/hieroglyphTransparent2/14/" + i + ".png");   //заполнение коллекции hieroglyph картинками иероглифов
        }
        for (int i = 1; i <= 22; i++) {
            s61.add("gameResourse2/resourseImages/ImagesForScreenSaver/hieroglyphTransparent2/15/" + i + ".png");   //заполнение коллекции hieroglyph картинками иероглифов
        }
        for (int i = 1; i <= 22; i++) {
            s63.add("gameResourse2/resourseImages/ImagesForScreenSaver/hieroglyphTransparent2/16/" + i + ".png");   //заполнение коллекции hieroglyph картинками иероглифов
        }
        s84[0] = "*Territory of cyber dangers*";
        s84[1] = "Промо ролик написан на языке Java.";
        s84[2] = "По вопросам приобретения идеи для игры ";
        s84[3] = "*Территория кибер опасностей* (рабочее название)";
        s84[4] = "или совместной разработки даного проекта обращаться по";
        s84[5] = "e-mail: ";
        s84[6] = "gamer.developer.new@gmail.com";
        s84[7] = "Жанр игры по Кутлалиеву (wikipedia): ";
        s84[8] = "- RPG,";
        s84[9] = "- Simulation (Freelance simulator),";
        s84[10] = "- Action (Quick time),";
        s84[11] = "- Strategy (Elements of Economic strategy),";
        s84[12] = "- Puzzle.";
        s84[13] = "Характер игр по Югай (wikipedia): ";
        s84[14] = "- Экшн, Квест, Ролевая игра.";
        s84[15] = " /// ";
        for (int i = 0; i < s84.length; i++) {

            s100 = s84[i].toCharArray();
            s99.add(s100);
        }
        for (int i = 0; i < s84.length; i++) {

            s100 = s84[i].toCharArray();
            s101.add(s100);
        }
        for (int i = 0; i < s97.length; i++) {
            for (int j = 0; j < s97[i].length; j++) {
                s97[i][j] = 0;
            }
        }
        for (int i = 0; i < s99.size(); i++) {
            for (int j = 0; j < s99.get(i).length; j++) {
                s95[i][j] = 1;
                s92[i][j] = (int) (0 + (Math.random() * 10));
                s94[i][j] = 255;
            }
        }
        ss1 = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/backgroundForGeneralFinishAnimation/2collectionTriangls/2circleOfTrianglesAssembled.png"));
        for (int i = 0; i <= 8; i++) {
            a5.add("gameResourse2/resourseImages/ImagesForScreenSaver/backgroundForGeneralFinishAnimation/2circleCollectionOfTriangles/" + i + ".png");
        }
        for (int i = 1; i <= 201; i++) {
            a8.add("gameResourse2/resourseImages/ImagesForScreenSaver/roundWithTextDecreases/" + i + ".png");
        }
        for (int i = 1; i <= 104; i++) {
            a13.add("gameResourse2/resourseImages/ImagesForScreenSaver/finishingAnimationOfTheSkull/" + i + ".png");
        }
    }

    Timer a112 = new Timer(s34, new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            for (int i = 0; i < s33.length; i++) {
                if (s33[i][5] == 1) {
                    switch (s33[i][6]) {
                        case 0:
                            if (s33[i][1] > s33[i][3] && s33[i][2] < s33[i][4]) {
                                s33[i][1] = s33[i][1] - s35;
                                s33[i][2] = s33[i][2] + s35;
                                if (s33[i][1] <= s33[i][3] && s33[i][2] >= s33[i][4]) {
                                    s33[i][1] = s33[i][2];
                                    s33[i][3] = s33[i][4];
                                    s33[i][5] = 2;
                                    s33[i][6]++;
                                }
                            }
                            if (s33[i][1] <= s33[i][3] && s33[i][2] <= s33[i][4]) {
                                s33[i][1] = s33[i][1] + s35;
                                s33[i][2] = s33[i][2] + s35;
                                if (s33[i][1] >= s33[i][3] && s33[i][2] >= s33[i][4]) {
                                    s33[i][1] = s33[i][2];
                                    s33[i][3] = s33[i][4];
                                    s33[i][5] = 2;
                                    s33[i][6]++;
                                }
                            }
                            if (s33[i][1] == s33[i][3] && s33[i][2] > s33[i][4]) {
                                s33[i][2] = s33[i][2] - s35 * 4;
                                if (s33[i][1] == s33[i][3] && s33[i][2] <= s33[i][4]) {
                                    s33[i][2] = s33[i][4];
                                    s33[i][5] = 2;
                                    s33[i][6]++;
                                    s36 = true;
                                }
                            }
                            break;
                        case 1:
                            s36 = true;
                            a112.stop();
                            break;
                        default:
                            System.out.println("!");
                            break;
                    }
                }
            }
        }
    });
    Timer a113 = new Timer(a3, new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            for (int i = 0; i < s19.length; i++) {
                if (s19[i][0] <= 0) {
                    switch (s19[i][5]) {
                        case 0:
                            if (s19[i][1] < s19[i][3] && s19[i][2] > s19[i][4]) {
                                s19[i][1] = s19[i][1] + a4;
                                s19[i][2] = s19[i][2] - a4;
                                if (s19[i][1] >= s19[i][3] && s19[i][2] <= s19[i][4]) {
                                    s19[i][1] = s19[i][3];
                                    s19[i][2] = s19[i][4];
                                    s19[i][5]++;
                                }
                            }
                            if (s19[i][1] < s19[i][3] && s19[i][2] == s19[i][4]) {
                                s19[i][1] = s19[i][1] + a4;
                                if (s19[i][1] >= s19[i][3] && s19[i][2] == s19[i][4]) {
                                    s19[i][1] = s19[i][3];
                                    s19[i][2] = s19[i][4];
                                    s19[i][5]++;
                                }
                            }
                            if (s19[i][1] < s19[i][3] && s19[i][2] < s19[i][4]) {
                                s19[i][1] = s19[i][1] + a4;
                                s19[i][2] = s19[i][2] + a4;
                                if (s19[i][1] >= s19[i][3] && s19[i][2] >= s19[i][4]) {
                                    s19[i][1] = s19[i][3];
                                    s19[i][2] = s19[i][4];
                                    s19[i][5]++;
                                }
                            }
                            if (s19[i][1] == s19[i][3] && s19[i][2] < s19[i][4]) {
                                s19[i][2] = s19[i][2] + a4;
                                if (s19[i][1] == s19[i][3] && s19[i][2] >= s19[i][4]) {
                                    s19[i][1] = s19[i][3];
                                    s19[i][2] = s19[i][4];
                                    s19[i][5]++;
                                }
                            }
                            if (s19[i][1] > s19[i][3] && s19[i][2] < s19[i][4]) {
                                s19[i][1] = s19[i][1] - a4;
                                s19[i][2] = s19[i][2] + a4;
                                if (s19[i][1] <= s19[i][3] && s19[i][2] >= s19[i][4]) {
                                    s19[i][1] = s19[i][3];
                                    s19[i][2] = s19[i][4];
                                    s19[i][5]++;
                                }
                            }
                            if (s19[i][1] > s19[i][3] && s19[i][2] == s19[i][4]) {
                                s19[i][1] = s19[i][1] - a4;
                                if (s19[i][1] <= s19[i][3] && s19[i][2] == s19[i][4]) {
                                    s19[i][1] = s19[i][3];
                                    s19[i][2] = s19[i][4];
                                    s19[i][5]++;
                                }
                            }
                            if (s19[i][1] > s19[i][3] && s19[i][2] > s19[i][4]) {
                                s19[i][1] = s19[i][1] - a4;
                                s19[i][2] = s19[i][2] - a4;
                                if (s19[i][1] <= s19[i][3] && s19[i][2] <= s19[i][4]) {
                                    s19[i][1] = s19[i][3];
                                    s19[i][2] = s19[i][4];
                                    s19[i][5]++;
                                }
                            }
                            if (s19[i][1] == s19[i][3] && s19[i][2] > s19[i][4]) {
                                s19[i][2] = s19[i][2] - a4;
                                a10 = true;
                                s90 = false;
                                s75 = false;
                                if (s19[i][1] <= s19[i][3] && s19[i][2] <= s19[i][4]) {
                                    s19[i][1] = s19[i][3];
                                    s19[i][2] = s19[i][4];
                                    s19[i][5]++;
                                }
                            }
                            break;
                        case 1:
                            a113.stop();
                            break;
                        default:
                            System.out.println("!");
                            break;
                    }
                }
            }
        }
    });

    public void update() {
        as12();
        as13();
        as14();
    }

    public void as12() {
        if (System.currentTimeMillis() > s2) {
            s25++;
            if (s25 == 0) {
                s22 = true;
                a112.start();
            }
        }
    }

    public void as13() {
        if (System.currentTimeMillis() > s38) {
            s39 = true;
        }
    }

    public void as15(int i, int j) {
        s40.get(i).get(j)[2] = s40.get(i).get(j)[2] - s40.get(i).get(j)[8];
        if (s40.get(i).get(j)[2] <= 0) {
            int backup_x = s40.get(i).get(j)[3];
            int backup_y = s40.get(i).get(j)[4];
            int backup_finish_y = s40.get(i).get(j)[6];
            int numberHierogliphsInThisGroup = s40.get(i).get(j)[1];
            s40.get(i).remove(j);
            s44 = new int[10];
            s44[0] = 1;
            s44[1] = numberHierogliphsInThisGroup;
            s44[2] = 21;
            s44[3] = backup_x;
            s44[4] = backup_y + (s44[1] * 16) + 16;
            s44[5] = backup_x;
            s44[6] = backup_finish_y;
            s44[7] = s40.get(i).get(0)[7];
            s44[8] = s40.get(i).get(0)[8];
            s44[9] = 0;
            s40.get(i).add(s44);
        }

        s43 = (int) (0 + (Math.random() * 17));
        if (s43 == 0) {
            s42 = s45.get(s40.get(i).get(j)[2]);
        }
        if (s43 == 1) {
            s42 = s46.get(s40.get(i).get(j)[2]);
        }
        if (s43 == 2) {
            s42 = s47.get(s40.get(i).get(j)[2]);
        }
        if (s43 == 3) {
            s42 = s48.get(s40.get(i).get(j)[2]);
        }
        if (s43 == 4) {
            s42 = s49.get(s40.get(i).get(j)[2]);
        }
        if (s43 == 5) {
            s42 = s50.get(s40.get(i).get(j)[2]);
        }
        if (s43 == 6) {
            s42 = s51.get(s40.get(i).get(j)[2]);
        }
        if (s43 == 7) {
            s42 = s52.get(s40.get(i).get(j)[2]);
        }
        if (s43 == 8) {
            s42 = s53.get(s40.get(i).get(j)[2]);
        }
        if (s43 == 9) {
            s42 = s54.get(s40.get(i).get(j)[2]);
        }
        if (s43 == 10) {
            s42 = s55.get(s40.get(i).get(j)[2]);
        }
        if (s43 == 11) {
            s42 = s56.get(s40.get(i).get(j)[2]);
        }
        if (s43 == 12) {
            s42 = s57.get(s40.get(i).get(j)[2]);
        }
        if (s43 == 13) {
            s42 = s59.get(s40.get(i).get(j)[2]);
        }
        if (s43 == 14) {
            s42 = s60.get(s40.get(i).get(j)[2]);
        }
        if (s43 == 15) {
            s42 = s61.get(s40.get(i).get(j)[2]);
        }
        if (s43 == 16) {
            s42 = s63.get(s40.get(i).get(j)[2]);
        }
    }

    public void a30() {
        s13++;
        if (s13 == 2) {
            s13 = 0;
            s12 = s12 + 0.0174533 * 1;
            //    System.out.println("s12 = " + s12);
            if (s14 == 0) {
                if (s12 >= 12.566375999999847) {
                    s12 = 0.0;
                    s14++;
                }
            }
            if (s14 == 1) {
                if (s12 >= 5.497789499999979) {
                    s12 = 0.0;
                    a1 = true;
                    s37 = false;
                    s14++;
                }
            }
            if (s14 == 2) {
                if (s12 >= 5.497789499999979) {
                    s12 = 0.0;
                    a1 = false;
                    s14++;
                    a2 = true;
                    a113.start();
                }
            }
        }
    }

    public void a31(int i) {
        if (s12 >= s18[i][2]) {
            s18[i][1] = 1;
        }
        if (s12 >= s18[i][3]) {
            s18[i][1] = 2;
        }
    }

    public void a32() {
        if (s23 >= s20.size() - 1) {
            s3 = true;
            s22 = false;
            return;
        }
        s24++;
        if (s24 == 2) {
            s23++;
            s24 = 0;
        }
    }

    public void sa34() {
        if (s32 == s31) {
            s37 = true;
            s36 = false;

            s76++;
            if (s76 == 0) {
                s75 = true;
            }
            return;
        }
        if (s32 <= s31) {
            s31 = s31 - 4;
        }
    }

    public void a123() {
        for (int i = 0; i < s70.length; i++) {
            if (s70[i] <= 0) {
                a1234(i);
            }
        }
    }

    public void a1234(int i) {
        int emptyOrNotEmpty;
        if (a15 == true) {
            s70[i] = 100;
            return;
        }
        emptyOrNotEmpty = (int) (1 + (Math.random() * 2));
        if (emptyOrNotEmpty == 1) {
            int quantityHieroglyphsInCollection;
            quantityHieroglyphsInCollection = (int) (1 + (Math.random() * 4));
            s70[i] = quantityHieroglyphsInCollection;
        }
        if (emptyOrNotEmpty == 2) {
            a234(i);
        }
    }

    public void a234(int i) {
        int as231 = 0;
        s72 = new ArrayList<>();
        int asa12 = (int) (1 + (Math.random() * 7));
        if (asa12 == 1) {
            as231 = 21;
            aas234 = 1;
        }
        if (asa12 == 2) {
            as231 = 11;
            aas234 = 2;
        }
        if (asa12 == 3) {
            as231 = 7;
            aas234 = 3;
        }
        if (asa12 == 4) {
            as231 = 6;
            aas234 = 4;
        }
        if (asa12 == 5) {
            as231 = 5;
            aas234 = 5;
        }
        if (asa12 == 6) {
            as231 = 4;
            aas234 = 6;
        }
        if (asa12 == 7) {
            as231 = 3;
            aas234 = 7;
        }
        s70[i] = as231;
        s72 = new ArrayList<>();
        for (int j = 0; j < as231; j++) {
            s44 = new int[10];
            s44[0] = 1;
            s44[1] = as231;
            s44[2] = j * aas234 + 1;
            s44[3] = s65 + (i * 12);
            s44[4] = s66 + (j * 16);
            s44[5] = s67 + (i * 12);
            s44[6] = s69;
            s44[7] = s71;
            s44[8] = aas234;
            s44[9] = 0;
            s72.add(s44);
        }
        s40.add(s72);
    }

    public void a50() {
        if (s77 == s73.size() - 1) {
            s77 = s73.size() - 1;
            return;
        }
        s78++;
        if (s78 == 20) {
            s77++;
            s78 = 0;
        }
    }

    public void as14() {
        if (System.currentTimeMillis() > s80) {
            s81 = true;
            s91++;
            if (s91 == 0) {
                s90 = true;
            }
        }
    }

    public void a51() {
        boolean a52 = false;
        do {
            if (s88 == 15) {
                s81 = false;
                a52 = true;
            }
            if (s81 == true) {
                if (s87 == 0) {
                    s83 = new StringBuilder();
                    s89++;
                    s82.add(s83);
                    s85 = s84[s88].toCharArray();
                }
                s86 = s85[s87];
                s87++;
                if (s87 == s85.length) {
                    s88++;
                    if (s88 >= s84.length) {
                        s88 = 0;
                    }
                    s87 = 0;
                }
                s82.get(s89).append(s86);
            }
        }
        while (a52 == false);
    }

    public void a53() {
        for (int i = 0; i < s19.length; i++) {
            s19[i][0]--;
            if (s19[i][0] == 0) {
                a6 = a5.get(i);
            }
        }
    }

    public void a54(int i, int j) {
        if (i == 0) {
            if (s101.get(i)[j] == 'o') {
                a7 = 15;
            }
            if (s101.get(i)[j] == 'T' || s101.get(i)[j] == 'c' || s101.get(i)[j] == 'b') {
                a7 = 14;
            }
            if (s101.get(i)[j] == 'n' || s101.get(i)[j] == 'd' || s101.get(i)[j] == 'a' || s101.get(i)[j] == 'g' || s101.get(i)[j] == 's') {
                a7 = 13;
            }
            if (s101.get(i)[j] == 'e' || s101.get(i)[j] == 'y') {
                a7 = 12;
            }
            if (s101.get(i)[j] == 'r') {
                a7 = 11;
            }
            if (s101.get(i)[j] == 'f') {
                a7 = 10;
            }
            if (s101.get(i)[j] == '*' || s101.get(i)[j] == 't') {
                a7 = 9;
            }
            if (s101.get(i)[j] == 'i') {
                a7 = 6;
            }
        }
        if (i == 1 || i == 2 || i == 3 || i == 4 || i == 5) {

            if (s101.get(i)[j] == 'ы' || s101.get(i)[j] == 'щ') {
                a7 = 12;
            }
            if (s101.get(i)[j] == 'm') {
                a7 = 11;
            }
            if (s101.get(i)[j] == 'л' || s101.get(i)[j] == 'П' || s101.get(i)[j] == 'м') {
                a7 = 10;
            }
            if (s101.get(i)[j] == 'я' || s101.get(i)[j] == 'и' || s101.get(i)[j] == 'Т' || s101.get(i)[j] == 'д' || s101.get(i)[j] == 'й' || s101.get(i)[j] == 'к') {
                a7 = 9;
            }
            if (s101.get(i)[j] == 'с' || s101.get(i)[j] == 'р' || s101.get(i)[j] == 'к' || s101.get(i)[j] == 'о' || s101.get(i)[j] == 'н' || s101.get(i)[j] == 'а' || s101.get(i)[j] == 'a' || s101.get(i)[j] == 'п' || s101.get(i)[j] == 'е' || s101.get(i)[j] == 'e' || s101.get(i)[j] == 'J' || s101.get(i)[j] == 'a' || s101.get(i)[j] == 'v' || s101.get(i)[j] == 'в' || s101.get(i)[j] == 'ь') {
                a7 = 8;
            }

            if (s101.get(i)[j] == 'з' || s101.get(i)[j] == 'т' || s101.get(i)[j] == 'г') {
                a7 = 6;
            }
            if (s101.get(i)[j] == '*' || s101.get(i)[j] == '(' || s101.get(i)[j] == ')' || s101.get(i)[j] == '-') {
                a7 = 5;
            }
            if (s101.get(i)[j] == '.' || s101.get(i)[j] == 'i' || s101.get(i)[j] == 'l' || s101.get(i)[j] == ':') {
                a7 = 3;
            }
        }
        if (i == 6) {

            if (s101.get(i)[j] == '@') {
                a7 = 20;
            }
            if (s101.get(i)[j] == 'm' || s101.get(i)[j] == 'w') {
                a7 = 16;
            }
            if (s101.get(i)[j] == 'g' || s101.get(i)[j] == 'a' || s101.get(i)[j] == 'd' || s101.get(i)[j] == 'o' || s101.get(i)[j] == 'p' || s101.get(i)[j] == 'n' || s101.get(i)[j] == 'g') {
                a7 = 11;
            }
            if (s101.get(i)[j] == 'e' || s101.get(i)[j] == 'v' || s101.get(i)[j] == 'c') {
                a7 = 10;
            }
            if (s101.get(i)[j] == 'r') {
                a7 = 8;
            }
            if (s101.get(i)[j] == '.' || s101.get(i)[j] == 'l' || s101.get(i)[j] == 'i') {
                a7 = 4;
            }
        }
        if (i == 7 || i == 8 || i == 9 || i == 10 || i == 11 || i == 12 || i == 13 || i == 14) {

            if (s101.get(i)[j] == 'Ю') {
                a7 = 12;
            }
            if (s101.get(i)[j] == 'Ж' || s101.get(i)[j] == 'm') {
                a7 = 11;
            }
            if (s101.get(i)[j] == 'ы' || s101.get(i)[j] == 'w') {
                a7 = 10;
            }
            if (s101.get(i)[j] == 'R' || s101.get(i)[j] == 'Q' || s101.get(i)[j] == 'S' || s101.get(i)[j] == 'Э' || s101.get(i)[j] == 'ш') {
                a7 = 9;
            }
            if (s101.get(i)[j] == 'л' || s101.get(i)[j] == 'К' || s101.get(i)[j] == 'в' || s101.get(i)[j] == 'P' || s101.get(i)[j] == 'G' || s101.get(i)[j] == 'A' || s101.get(i)[j] == 'g' || s101.get(i)[j] == 'y' || s101.get(i)[j] == 'n' || s101.get(i)[j] == 's' || s101.get(i)[j] == 'Х' || s101.get(i)[j] == 'Р' || s101.get(i)[j] == 'я') {
                a7 = 8;
            }
            if (s101.get(i)[j] == 'а' || s101.get(i)[j] == 'у' || s101.get(i)[j] == 'н' || s101.get(i)[j] == 'р' || s101.get(i)[j] == 'и' || s101.get(i)[j] == 'п' || s101.get(i)[j] == 'о' || s101.get(i)[j] == 'е' || s101.get(i)[j] == 'k' || s101.get(i)[j] == 'p' || s101.get(i)[j] == 'd' || s101.get(i)[j] == 'u' || s101.get(i)[j] == 'F' || s101.get(i)[j] == 'o' || s101.get(i)[j] == 'e' || s101.get(i)[j] == 'a' || s101.get(i)[j] == 'c' || s101.get(i)[j] == 'E' || s101.get(i)[j] == 'к') {
                a7 = 7;
            }
            if (s101.get(i)[j] == 'z') {
                a7 = 6;
            }
            if (s101.get(i)[j] == 'г' || s101.get(i)[j] == 'т' || s101.get(i)[j] == 'r') {
                a7 = 5;
            }
            if (s101.get(i)[j] == '(' || s101.get(i)[j] == ')' || s101.get(i)[j] == '-' || s101.get(i)[j] == 't') {
                a7 = 4;
            }
            if (s101.get(i)[j] == 'i' || s101.get(i)[j] == ':' || s101.get(i)[j] == ',' || s101.get(i)[j] == 'l') {
                a7 = 3;
            }
        }
    }

    public void a55() {
        for (int i = 0; i < s101.size(); i++) {
            for (int j = 0; j < s101.get(i).length; j++) {
                if (s97[i][j] <= 3) {
                    if (s95[i][j] == 1) {
                        if (s92[i][j] == 0) {
                            s94[i][j] = s94[i][j] - (int) (1 + (Math.random() * 25));
                            if (s94[i][j] <= 0) {
                                s94[i][j] = 255;
                                s92[i][j] = (int) (0 + (Math.random() * 500));
                                s97[i][j] = s97[i][j] + 1;
                            }
                        }
                        if (s92[i][j] != 0) {
                            s92[i][j]--;
                        }
                    }
                }
                if (s97[i][j] > 3) {
                    s94[i][j] = 255;
                    s92[i][j] = 0;
                }
            }
        }
    }

    public void a56() {
        if (a11 == a8.size() - 1) {
            a10 = false;
            a15 = true;
            return;
        }
        a12++;
        if (a12 == 1) {
            a11++;
            a12 = 0;
        }
    }

    public void a57() {
        if (a16 == a13.size() - 1) {
            a16 = a13.size() - 1;
            return;
        }
        a17++;
        if (a17 == 1) {
            a16++;
            a17 = 0;
        }
    }

    public void draw(Graphics2D g) {
        if (s22 == true) {
            a32();
            s21 = s20.get(s23);
            g.drawImage(new ImageIcon(s21).getImage(), 0, 0, null);
        }
        if (s3 == true) {
            g.drawImage(backgroundForGeneralFinishAnimation, 0, 0, null);
            if (s39 == true) {
                for (int i = 0; i < s40.size(); i++) {
                    for (int j = 0; j < s40.get(i).size() - 1; j++) {
                        if (s40.get(i).get(j)[4] >= s66 || s40.get(i).get(j)[4] <= s69 || s40.get(i).get(j)[3] > s65 || s40.get(i).get(j)[3] < s67) {
                            as15(i, j);
                            g.drawImage(new ImageIcon(s42).getImage(), s40.get(i).get(j)[3], s40.get(i).get(j)[4], null);
                            if (s40.get(i).get(j)[4] >= s69 || s40.get(i).get(j)[3] < s65 || s40.get(i).get(j)[3] > s67) {
                                s40.get(i).remove(j);
                            }
                        }
                    }
                }
                for (int i = 0; i < s70.length; i++) {
                    s70[i]--;
                }
                a123();
            }
            if (s75 == true) {
                a50();
                s74 = s73.get(s77);
                g.drawImage(new ImageIcon(s74).getImage(), 0, 0, null);
            }
            if (s37 == true) {
                AffineTransform affineTransform;
                affineTransform = g.getTransform();
                AffineTransform newAffineTransform = (AffineTransform) (affineTransform.clone());
                a30();
                newAffineTransform.rotate(s12, s10, s11);
                g.setTransform(newAffineTransform);
                g.drawImage(s5, s8, s9, null);
                g.setTransform(affineTransform);
                for (int i = 0; i < s18.length; i++) {
                    a31(i);
                    if (s18[i][1] == 1) {
                        s17 = s16.get((int) s18[i][0]);
                        g.drawImage(new ImageIcon(s17).getImage(), 0, 0, null);
                    }
                }
            }

            for (int i = 0; i < s33.length; i++) {
                if (s33[i][5] == 1) {
                    switch (s33[i][0]) {
                        case 1:
                            g.drawImage(new ImageIcon(s26).getImage(), s33[i][1], s33[i][2], null);
                            break;
                        case 2:
                            g.drawImage(new ImageIcon(s27).getImage(), s33[i][1], s33[i][2], null);
                            break;
                        case 3:
                            g.drawImage(new ImageIcon(s28).getImage(), s33[i][1], s33[i][2], null);
                            break;
                    }
                }
            }
            if (s36 == true) {
                sa34();
                g.drawImage(new ImageIcon(s29).getImage(), s30, s31, null);
            }
        }
        if (a1 == true) {
            AffineTransform affineTransform;
            affineTransform = g.getTransform();
            AffineTransform newAffineTransform = (AffineTransform) (affineTransform.clone());
            a30();
            newAffineTransform.rotate(s12, s10, s11);
            g.setTransform(newAffineTransform);
            g.drawImage(ss1, s8, s9, null);
            g.setTransform(affineTransform);
        }

        if (s90 == true) {
            int a60 = 0;
            int a61 = 0;
            int a62 = 0;
            int a63 = 0;
            int a64 = 0;
            int a65 = 0;
            int a66 = 0;
            int a68 = 0;
            int a69 = 0;
            int a70 = 0;
            int a71 = 0;
            int a72 = 0;
            int a73 = 0;
            int a75 = 0;
            int a78 = 0;
            int a80 = 27;
            a55();
            for (int i = 0; i < s101.size(); i++) {

                Font myFont25 = new Font(null, Font.BOLD, 25);
                Font myFont15 = new Font(null, Font.BOLD, 15);
                Font myFont20 = new Font(null, Font.BOLD, 20);
                Font myFont12 = new Font(null, Font.BOLD, 12);
                for (int j = 0; j < s101.get(i).length; j++) {
                    if (s92[i][j] == 0) {
                        if (i == 0) {
                            Color color1 = new Color(213, 216, 216, s94[i][j]);
                            g.setFont(myFont25);
                            g.setColor(color1);
                            a54(i, j);
                            g.drawChars(s101.get(i), j, 1, 795 + a60, 407);
                            a60 = a60 + a7;
                        }
                        if (i == 1) {
                            Color color1 = new Color(213, 216, 216, s94[i][j]);
                            g.setFont(myFont15);
                            g.setColor(color1);
                            a54(i, j);
                            g.drawChars(s101.get(i), j, 1, 820 + a61, 407 + (i * a80));
                            a61 = a61 + a7;
                        }
                        if (i == 2) {
                            Color color1 = new Color(213, 216, 216, s94[i][j]);
                            g.setFont(myFont15);
                            g.setColor(color1);
                            a54(i, j);
                            g.drawChars(s101.get(i), j, 1, 802 + a62, 407 + (i * a80));
                            a62 = a62 + a7;
                        }
                        if (i == 3) {
                            Color color1 = new Color(213, 216, 216, s94[i][j]);
                            g.setFont(myFont15);
                            g.setColor(color1);
                            a54(i, j);
                            g.drawChars(s101.get(i), j, 1, 782 + a63, 407 + (i * a80));
                            a63 = a63 + a7;
                        }
                        if (i == 4) {
                            Color color1 = new Color(213, 216, 216, s94[i][j]);
                            g.setFont(myFont15);
                            g.setColor(color1);
                            a54(i, j);
                            g.drawChars(s101.get(i), j, 1, 739 + a64, 407 + (i * a80));
                            a64 = a64 + a7;
                        }
                        if (i == 5) {
                            Color color1 = new Color(213, 216, 216, s94[i][j]);
                            g.setFont(myFont15);
                            g.setColor(color1);
                            a54(i, j);
                            g.drawChars(s101.get(i), j, 1, 780 + a65, 407 + (i * a80));
                            a65 = a65 + a7;
                        }
                        if (i == 6) {
                            Color color2 = new Color(0, 150, 255, s94[i][j]);
                            g.setFont(myFont20);
                            g.setColor(color2);
                            a54(i, j);
                            g.drawChars(s101.get(i), j, 1, 836 + a66, 407 + ((i - 1) * a80));
                            a66 = a66 + a7;
                        }
                        if (i == 7) {
                            Color color1 = new Color(213, 216, 216, s94[i][j]);
                            g.setFont(myFont12);
                            g.setColor(color1);
                            a54(i, j);
                            g.drawChars(s101.get(i), j, 1, 844 + a68, 407 + ((i - 1) * a80));
                            a68 = a68 + a7;
                        }

                        if (i == 8) {
                            Color color1 = new Color(213, 216, 216, s94[i][j]);
                            g.setFont(myFont12);
                            g.setColor(color1);
                            a54(i, j);
                            g.drawChars(s101.get(i), j, 1, 861 + a69, 407 + (((i - 1) * a80)) - 5);
                            a69 = a69 + a7;
                        }
                        if (i == 9) {
                            Color color1 = new Color(213, 216, 216, s94[i][j]);
                            g.setFont(myFont12);
                            g.setColor(color1);
                            a54(i, j);
                            g.drawChars(s101.get(i), j, 1, 861 + a70, 407 + (((i - 1) * a80)) - 10);
                            a70 = a70 + a7;
                        }
                        if (i == 10) {
                            Color color1 = new Color(213, 216, 216, s94[i][j]);
                            g.setFont(myFont12);
                            g.setColor(color1);
                            a54(i, j);
                            g.drawChars(s101.get(i), j, 1, 861 + a71, 407 + (((i - 1) * a80)) - 15);
                            a71 = a71 + a7;
                        }
                        if (i == 11) {
                            Color color1 = new Color(213, 216, 216, s94[i][j]);
                            g.setFont(myFont12);
                            g.setColor(color1);
                            a54(i, j);
                            g.drawChars(s101.get(i), j, 1, 861 + a72, 407 + (((i - 1) * a80)) - 20);
                            a72 = a72 + a7;
                        }
                        if (i == 12) {
                            Color color1 = new Color(213, 216, 216, s94[i][j]);
                            g.setFont(myFont12);
                            g.setColor(color1);
                            a54(i, j);
                            g.drawChars(s101.get(i), j, 1, 861 + a73, 407 + (((i - 1) * a80)) - 25);
                            a73 = a73 + a7;
                        }
                        if (i == 13) {
                            Color color1 = new Color(213, 216, 216, s94[i][j]);
                            g.setFont(myFont12);
                            g.setColor(color1);
                            a54(i, j);
                            g.drawChars(s101.get(i), j, 1, 841 + a75, 407 + (((i - 1) * a80)) - 30);
                            a75 = a75 + a7;
                        }
                        if (i == 14) {
                            Color color1 = new Color(213, 216, 216, s94[i][j]);
                            g.setFont(myFont12);
                            g.setColor(color1);
                            a54(i, j);
                            g.drawChars(s101.get(i), j, 1, 861 + a78, 407 + (((i - 1) * a80)) - 35);
                            a78 = a78 + a7;
                        }
                    }
                    if (s92[i][j] != 0) {
                        Color color1 = new Color(15, 32, 78);
                        if (i == 0) {
                            g.setFont(myFont25);
                            g.setColor(color1);
                            a54(i, j);
                            g.drawChars(s101.get(i), j, 1, 795 + a60, 407);
                            a60 = a60 + a7;
                        }
                        if (i == 1) {
                            g.setFont(myFont15);
                            g.setColor(color1);
                            a54(i, j);
                            g.drawChars(s101.get(i), j, 1, 820 + a61, 407 + (i * a80));
                            a61 = a61 + a7;
                        }
                        if (i == 2) {
                            g.setFont(myFont15);
                            g.setColor(color1);
                            a54(i, j);
                            g.drawChars(s101.get(i), j, 1, 802 + a62, 407 + (i * a80));
                            a62 = a62 + a7;
                        }
                        if (i == 3) {
                            g.setFont(myFont15);
                            g.setColor(color1);
                            a54(i, j);
                            g.drawChars(s101.get(i), j, 1, 782 + a63, 407 + (i * a80));
                            a63 = a63 + a7;
                        }
                        if (i == 4) {
                            g.setFont(myFont15);
                            g.setColor(color1);
                            a54(i, j);
                            g.drawChars(s101.get(i), j, 1, 739 + a64, 407 + (i * a80));
                            a64 = a64 + a7;
                        }
                        if (i == 5) {
                            g.setFont(myFont15);
                            g.setColor(color1);
                            a54(i, j);
                            g.drawChars(s101.get(i), j, 1, 780 + a65, 407 + (i * a80));
                            a65 = a65 + a7;
                        }
                        if (i == 6) {
                            g.setFont(myFont20);
                            g.setColor(color1);
                            a54(i, j);
                            g.drawChars(s101.get(i), j, 1, 836 + a66, 407 + ((i - 1) * a80));
                            a66 = a66 + a7;
                        }
                        if (i == 7) {
                            g.setFont(myFont12);
                            g.setColor(color1);
                            a54(i, j);
                            g.drawChars(s101.get(i), j, 1, 844 + a68, 407 + ((i - 1) * a80));
                            a68 = a68 + a7;
                        }
                        if (i == 8) {
                            g.setFont(myFont12);
                            g.setColor(color1);
                            a54(i, j);
                            g.drawChars(s101.get(i), j, 1, 861 + a69, 407 + (((i - 1) * a80)) - 5);
                            a69 = a69 + a7;
                        }
                        if (i == 9) {
                            g.setFont(myFont12);
                            g.setColor(color1);
                            a54(i, j);
                            g.drawChars(s101.get(i), j, 1, 861 + a70, 407 + (((i - 1) * a80)) - 10);
                            a70 = a70 + a7;
                        }
                        if (i == 10) {
                            g.setFont(myFont12);
                            g.setColor(color1);
                            a54(i, j);
                            g.drawChars(s101.get(i), j, 1, 861 + a71, 407 + (((i - 1) * a80)) - 15);
                            a71 = a71 + a7;
                        }
                        if (i == 11) {
                            g.setFont(myFont12);
                            g.setColor(color1);
                            a54(i, j);
                            g.drawChars(s101.get(i), j, 1, 861 + a72, 407 + (((i - 1) * a80)) - 20);
                            a72 = a72 + a7;
                        }
                        if (i == 12) {
                            g.setFont(myFont12);
                            g.setColor(color1);
                            a54(i, j);
                            g.drawChars(s101.get(i), j, 1, 861 + a73, 407 + (((i - 1) * a80)) - 25);
                            a73 = a73 + a7;
                        }
                        if (i == 13) {
                            g.setFont(myFont12);
                            g.setColor(color1);
                            a54(i, j);
                            g.drawChars(s101.get(i), j, 1, 841 + a75, 407 + (((i - 1) * a80)) - 30);
                            a75 = a75 + a7;
                        }
                        if (i == 14) {
                            g.setFont(myFont12);
                            g.setColor(color1);
                            a54(i, j);
                            g.drawChars(s101.get(i), j, 1, 861 + a78, 407 + (((i - 1) * a80)) - 35);
                            a78 = a78 + a7;
                        }
                    }
                }
            }
        }
        if (a2 == true) {
            a53();
            for (int i = 0; i < s19.length; i++) {
                if (s19[i][0] <= 0) {
                    s17 = s16.get(i);
                    g.drawImage(new ImageIcon(s17).getImage(), s19[i][1], s19[i][2], null);
                    g.drawImage(new ImageIcon(a6).getImage(), 0, 0, null);
                }
            }
        }
        if (a10 == true) {
            a56();
            a9 = a8.get(a11);
            g.drawImage(new ImageIcon(a9).getImage(), 0, 0, null);
        }
        if (a15 == true) {
            a57();
            a14 = a13.get(a16);
            g.drawImage(new ImageIcon(a14).getImage(), 0, 0, null);
        }
    }
}

