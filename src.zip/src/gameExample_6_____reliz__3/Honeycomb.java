package gameExample_6_____reliz__3;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Created by sofis on 02.06.2019.
 */
public class Honeycomb {
    //fields
    ArrayList<String> honeycomb = new ArrayList<>();   //коллекция картинок
    private String honeycombInstance;                //экземпляр картинки из коллекции honeycomb

    ArrayList<String> honeycomb2 = new ArrayList<>();   //коллекция картинок  //для второй части анимации

    // [0]-счетчик циклов для анимации honeycomb
    // [1]-направление движения по вертикали и размер шага движения
    // [2]-направление движения по горизонтали и размер шага движения
    // [3]-начальная координата 'archivTrackChameleon_x'
    // [4]-начальная координата 'archivTrackChameleon_y'

    private int[][] arrayCoordinatesHoneycomb = {

            {0, 5, 5, 245, -3735, 0, -95, 245, 0, -1, 1, 245, -95, -1, 1, 245, -95, -1, -5, 245, -95, 0, 0},     //2 (1)
            {0, 5, 5, 805, -3945, 0, -95, 805, 0, -1, 1, 805, -95, -1, 1, 805, -95, -1, -5, 805, -95, 0, 5},     //4 (2)
            {0, 5, 5, 1365, -3735, 0, -95, 1365, 0, -1, 1, 1365, -95, -1, 1, 1365, -95, -1, -5, 1365, -95, 0, 5},     //6 (3)

            {0, 5, 5, -1010, 391, 0, 391, 805, 0, -5, 5, 525, 391, 7, 1, 805, 391, -5, 5, 665, 634, 0, 5},     //26 (4)

            {0, -1, -1, 2710, 391, 0, 391, 2205, 0, -1120, -5, 1365, 391, 1, 1, 1365, 391, 5, 1, 1645, 391, 0, 5},     //22 (5)

            {0, 5, 5, 1225, -1392, 0, 634, 1225, 0, -6, -1, 945, 634, 0, 0, 945, 634, 0, 0, 945, 634, 0, 5},     //27 (6)
            {0, 5, 5, 1225, -1392, 0, 634, 1225, 0, 6, 1, 1505, 634, 0, 0, 1365, 391, 0, 0, 1505, 634, 0, 5},     //29 (7)

            {0, 5, 5, 1225, -1392, 0, 634, 1225, 0, 1, 1, 1225, 634, 0, 0, 1225, 634, 0, 0, 1225, 634, 0, 5},       //28 (8)

            {0, 5, 5, 1225, -1392, 0, 148, 1505, 0, 1, 1, 1505, 148, 0, 0, 1505, 148, 0, 0, 1505, 148, 0, 5},           //14
            {0, -5, 5, 1225, -1392, 0, 148, 945, 0, 1, 1, 945, 148, 0, 0, 945, 148, 0, 0, 945, 148, 0, 5},           //12
            {0, 5, 5, 1225, -1392, 0, 148, 1225, 0, 1, 1, 1225, 148, 0, 0, 1225, 148, 0, 0, 1225, 148, 0, 5},       //13

            {0, 5, -5, 435, 1000, 0, 391, 1365, 0, 1, 1, 1365, 391, 0, 0, 1365, 391, 0, 0, 1365, 391, 0, 5},        //21
            {0, 5, -5, 435, 1000, 0, 391, 1085, 0, 1, 1, 1085, 391, 0, 0, 1085, 391, 0, 0, 1085, 391, 0, 5},        //20

            {0, 1, 1, -1000, 148, 0, 148, -455, 0, 1120, 5, 385, 148, -1, -1, 385, 148, -5, -1, 105, 148, 0, 5},     //9  (14)
            {0, 1, 1, -1000, 634, 0, 634, -455, 0, 1120, 5, 385, 634, -1, -1, 385, 634, -5, -1, 105, 634, 0, 5},     //24  (15)

            {0, 5, 5, -1010, 391, 0, 391, 805, 0, -5, 5, 525, 391, 7, 1, 805, 391, 0, 0, 805, 391, 0, 5},     //19 (16)

            {0, 5, 5, -1010, 391, 0, 391, 805, 0, -5, 5, 525, 391, -5, -7, 385, 148, 5, 5, 665, 148, 0, 5},     //11 (17)
            {0, 5, 5, -1010, 391, 0, 391, 805, 0, -5, 5, 525, 391, -5, -7, 385, 148, 0, 0, 385, 148, 0, 5},     //10 (18)

            {0, 5, 5, -1010, 391, 0, 391, 805, 0, -5, 5, 525, 391, -5, 6, 385, 634, -5, -5, 245, 391, 0, 5},     //17 (19)
            {0, 5, 5, -1010, 391, 0, 391, 805, 0, -5, 5, 525, 391, -5, 6, 385, 634, 0, 0, 385, 634, 0, 5},     //25 (20)

            {0, 5, 5, -1010, 391, 0, 391, 805, 0, -5, 5, 525, 391, 0, 0, 525, 391, 0, 0, 525, 391, 0, 5},     //18 (21)

            {0, 5, 5, -3050, 391, 0, 391, -35, 0, -1, 1, -35, 391, 0, 0, -35, 391, 0, 0, -35, 391, 0, 5},     //16 (22)

            {0, 5, -5, -200, 3660, 0, 634, -175, 0, 1, 1, -175, 634, 0, 0, -175, 634, 0, 0, -175, 634, 0, 5},        //23  (23)
            {0, 5, 5, -200, -2881, 0, 148, -175, 0, 1, 1, -175, 148, 0, 0, -175, 148, 0, 0, -175, 148, 0, 5},        //8  (24)

            {0, -5, 5, 1810, -2881, 0, 148, 1785, 0, 1, 1, 1785, 148, 0, 0, 1785, 148, 0, 0, 1785, 148, 0, 5},        //15  (25)
            {0, -5, -5, 1810, 3660, 0, 634, 1785, 0, 1, 1, 1785, 634, 0, 0, 1785, 634, 0, 0, 1785, 634, 0, 5},        //30  (26)

            {0, 5, 5, -35, -3635, 0, -95, -35, 0, -1, 1, -35, -95, -1, 1, -35, -95, -1, -5, -35, -95, 0, 5},     //1 (27)
            {0, 5, 5, 525, -3835, 0, -95, 525, 0, -1, 1, 525, -95, -1, 1, 525, -95, -1, -5, 525, -95, 0, 5},     //3 (28)
            {0, 5, 5, 1085, -3835, 0, -95, 1085, 0, -1, 1, 1085, -95, -1, 1, 1085, -95, -1, -5, 1085, -95, 0, 5},     //5 (29)
            {0, 5, 5, 1645, -3635, 0, -95, 1645, 0, -1, 1, 1645, -95, -1, 1, 1645, -95, -1, -5, 1645, -95, 0, 5},     //7 (30)

            {0, 5, -5, -35, 3930, 0, 877, -35, 0, 1, 1, -35, 877, 0, 0, -35, 877, 0, 0, -35, 877, 0, 5},     //31  (31)
            {0, 5, -5, 245, 4010, 0, 877, 245, 0, 1, 1, 245, 877, 0, 0, 245, 877, 0, 0, 245, 877, 0, 5},     //32  (32)
            {0, 5, -5, 525, 4090, 0, 877, 525, 0, 1, 1, 525, 877, 0, 0, 525, 877, 0, 0, 525, 877, 0, 5},     //33  (33)
            {0, 5, -5, 805, 4170, 0, 877, 805, 0, 1, 1, 805, 877, 0, 0, 805, 877, 0, 0, 805, 877, 0, 5},     //34  (34)
            {0, 5, -5, 1085, 4250, 0, 877, 1085, 0, 1, 1, 1085, 877, 0, 0, 1085, 877, 0, 0, 1085, 877, 0, 5},     //35  (35)
            {0, 5, -5, 1365, 4330, 0, 877, 1365, 0, 1, 1, 1365, 877, 0, 0, 1365, 877, 0, 0, 1365, 877, 0, 5},     //36  (36)
            {0, 5, -5, 1645, 4430, 0, 877, 1645, 0, 1, 1, 1645, 877, 0, 0, 1645, 877, 0, 0, 1645, 877, 0, 5},     //37  (37)

            //    {0, 50, 50, -1010, 391, 0, 391, 805, 0, 5, -5, 905, 148,},     //     3---

            //  {0, 50, 50, -1010, 391, 0, 391, 805, 0, 5, 5, 905, 491,},     //   1---

            //    {0, 50, 50, -1010, 391, 0, 391, 805, 0, -5, -5, 705, 291,},     //   2---

            //    {0, 50, 50, -1010, 391, 0, 391, 805, 0, -5, 5, 705, 491,},     //   4---

    };



    // [0]-счетчик циклов для анимации honeycomb2
    // [1]-не задействован
    // [2]-не задействован
    // [3]-начальная координата 'archivTrackChameleon_x'
    // [4]-начальная координата 'archivTrackChameleon_y'
    private int[][] arrayCoordinatesHoneycomb2 = {
            {0, 1, 0, -175, 634,},               //23
            {0, 1, 0, -35, 877,},               //31
            {0, 1, 0, -175, 148,},               //8
            {0, 1, 0, -35, 391,},               //16
            {0, 1, 0, 105, 634,},               //24
            {0, 1, 0, 245, 877,},               //32
            {0, 1, 0, -35, -95},                 //1
            {0, 1, 0, 105, 148,},               //9
            {0, 1, 0, 245, 391},               //17
            {0, 1, 0, 385, 634,},               //25
            {0, 1, 0, 525, 877,},               //33
            {0, 1, 0, 245, -95},                //2
            {0, 1, 0, 385, 148,},               //10
            {0, 1, 0, 525, 391,},               //18
            {0, 1, 0, 665, 634,},               //26
            {0, 1, 0, 805, 877,},               //34
            {0, 1, 0, 525, -95},                //3
            {0, 1, 0, 665, 148,},               //11

            {0, 5, 0, 805, 391,},               //19   !!!

            {0, 1, 0, 945, 634,},               //27
            {0, 1, 0, 1085, 877,},               //35
            {0, 1, 0, 805, -95},               //4
            {0, 1, 0, 945, 148,},               //12
            {0, 1, 0, 1085, 391,},               //20
            {0, 1, 0, 1225, 634,},               //28
            {0, 1, 0, 1365, 877,},               //36
            {0, 1, 0, 1085, -95},               //5
            {0, 1, 0, 1225, 148,},               //13
            {0, 1, 0, 1365, 391,},               //21
            {0, 1, 0, 1505, 634,},               //29
            {0, 1, 0, 1645, 877,},               //37
            {0, 1, 0, 1365, -95},               //6
            {0, 1, 0, 1505, 148,},               //14
            {0, 1, 0, 1645, 391,},               //22
            {0, 1, 0, 1785, 634,},               //30
            {0, 1, 0, 1645, -95},               //7
            {0, 1, 0, 1785, 148,},               //15

          //  {0, 20, 0, 805, 391,},               //19   !!!


    };

    private boolean showONanimationHoneycomb = false;     //переменная,по состоянию которой продолжается или прекращается демонстрация анимации  сот в конечной точке назначения










    private boolean showONanimationHoneycomb2 = false;   //изменен (изначально - false) для ускорения разработки  //переменная,состояние которой разрешает или прекращает анимацию "showONanimationHoneycomb2"

    long startTime = System.currentTimeMillis();                        //переменная текущего времени (для фиксации времени начала анимации)
    long startTimeShowAnimationHoneycomb = startTime + 15 * 1000;   //(ключевая точка времени)время задержки начала анимации сот                           // 60 seconds * 1000 ms/sec;   //время окончания воспроизведения анимации


    private int timerSpeedHoneycomb = 50;       //скорость таймера для анимации honeycomb

    //constructor
    public Honeycomb() throws IOException {
        for (int i = 1; i <= 37; i++) {
            honeycomb.add("gameResourse2/resourseImages/ImagesForScreenSaver/honeycombMedium/" + i + ".png");   //заполнение коллекции honeycomb картинками сот
        }

        for (int i = 1; i <= 37; i++) {
           honeycomb2.add("gameResourse2/resourseImages/ImagesForScreenSaver/honeycombMedium/!/диагональ/" + i + ".png");
        }
    }


    Timer timerHoneycomb = new Timer(timerSpeedHoneycomb, new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            //код который нужно выполнить каждый интервал timerSpeed
            //настройка анимации появления картинки honeycomb


            if (showONanimationHoneycomb == true) {
                for (int i = 0; i < honeycomb.size(); i++) {


                    switch (arrayCoordinatesHoneycomb[i][0]) {

                        case 0:    //движение по оси "Y"
                            if (arrayCoordinatesHoneycomb[i][2] > 0) {      //проверка для движения вверх
                                if (Math.abs(arrayCoordinatesHoneycomb[i][4] - arrayCoordinatesHoneycomb[i][6]) < Math.abs(arrayCoordinatesHoneycomb[i][2])) {
                                    arrayCoordinatesHoneycomb[i][4] = arrayCoordinatesHoneycomb[i][4] + Math.abs(arrayCoordinatesHoneycomb[i][4] - arrayCoordinatesHoneycomb[i][6]);
                                } else {
                                    arrayCoordinatesHoneycomb[i][4] = arrayCoordinatesHoneycomb[i][4] + arrayCoordinatesHoneycomb[i][2];      //размер шага с которім движется картинка
                                }
                                if (arrayCoordinatesHoneycomb[i][4] >= arrayCoordinatesHoneycomb[i][6]) {
                                    arrayCoordinatesHoneycomb[i][0]++;
                                }
                            }
                            if (arrayCoordinatesHoneycomb[i][2] < 0) {      //проверка для движения вниз
                                if (Math.abs(arrayCoordinatesHoneycomb[i][4] - arrayCoordinatesHoneycomb[i][6]) < Math.abs(arrayCoordinatesHoneycomb[i][2])) {
                                    arrayCoordinatesHoneycomb[i][4] = arrayCoordinatesHoneycomb[i][4] - Math.abs(arrayCoordinatesHoneycomb[i][4] - arrayCoordinatesHoneycomb[i][6]);
                                } else {
                                    arrayCoordinatesHoneycomb[i][4] = arrayCoordinatesHoneycomb[i][4] + arrayCoordinatesHoneycomb[i][2];      //размер шага с которім движется картинка
                                }
                                if (arrayCoordinatesHoneycomb[i][4] <= arrayCoordinatesHoneycomb[i][6]) {
                                    arrayCoordinatesHoneycomb[i][0]++;
                                }
                            }
                            break;


                        case 1:         //движение по оси "Х"
                            if (arrayCoordinatesHoneycomb[i][1] > 0) {          //проверка для движения вправо
                                if (arrayCoordinatesHoneycomb[i][3] >= arrayCoordinatesHoneycomb[i][7]) {
                                    arrayCoordinatesHoneycomb[i][0]++;

                                    break;
                                }
                                if (Math.abs(arrayCoordinatesHoneycomb[i][7] - arrayCoordinatesHoneycomb[i][3]) < Math.abs(arrayCoordinatesHoneycomb[i][1])) {
                                    arrayCoordinatesHoneycomb[i][3] = arrayCoordinatesHoneycomb[i][3] + (arrayCoordinatesHoneycomb[i][7] - arrayCoordinatesHoneycomb[i][3]);
                                } else {
                                    arrayCoordinatesHoneycomb[i][3] = arrayCoordinatesHoneycomb[i][3] + arrayCoordinatesHoneycomb[i][1];
                                }
                                if (arrayCoordinatesHoneycomb[i][3] >= arrayCoordinatesHoneycomb[i][7]) {
                                    arrayCoordinatesHoneycomb[i][0]++;
                                }
                                break;
                            }
                            if (arrayCoordinatesHoneycomb[i][1] < 0) {           //проверка для движения влево
                                if (arrayCoordinatesHoneycomb[i][3] <= arrayCoordinatesHoneycomb[i][7]) {
                                    arrayCoordinatesHoneycomb[i][0]++;
                                    break;
                                }
                                if (Math.abs(arrayCoordinatesHoneycomb[i][7] - arrayCoordinatesHoneycomb[i][3]) < Math.abs(arrayCoordinatesHoneycomb[i][1])) {
                                    arrayCoordinatesHoneycomb[i][3] = arrayCoordinatesHoneycomb[i][3] + (arrayCoordinatesHoneycomb[i][7] - arrayCoordinatesHoneycomb[i][3]);
                                } else {
                                    arrayCoordinatesHoneycomb[i][3] = arrayCoordinatesHoneycomb[i][3] + arrayCoordinatesHoneycomb[i][1];
                                }
                                if (arrayCoordinatesHoneycomb[i][3] <= arrayCoordinatesHoneycomb[i][7]) {
                                    arrayCoordinatesHoneycomb[i][0]++;
                                }
                                break;
                            }

                        case 2:         //движение по оси "Х"
                            if (arrayCoordinatesHoneycomb[i][9] > 0) {          //проверка для движения вправо
                                if (arrayCoordinatesHoneycomb[i][3] >= arrayCoordinatesHoneycomb[i][11]) {
                                    arrayCoordinatesHoneycomb[i][0]++;

                                    break;
                                }
                                if (Math.abs(arrayCoordinatesHoneycomb[i][11] - arrayCoordinatesHoneycomb[i][3]) < Math.abs(arrayCoordinatesHoneycomb[i][9])) {
                                    arrayCoordinatesHoneycomb[i][3] = arrayCoordinatesHoneycomb[i][3] + (arrayCoordinatesHoneycomb[i][11] - arrayCoordinatesHoneycomb[i][3]);
                                } else {
                                    arrayCoordinatesHoneycomb[i][3] = arrayCoordinatesHoneycomb[i][3] + arrayCoordinatesHoneycomb[i][9];
                                }
                                if (arrayCoordinatesHoneycomb[i][3] >= arrayCoordinatesHoneycomb[i][11]) {
                                    arrayCoordinatesHoneycomb[i][0]++;
                                }
                                break;
                            }
                            if (arrayCoordinatesHoneycomb[i][9] < 0) {           //проверка для движения влево
                                if (arrayCoordinatesHoneycomb[i][3] <= arrayCoordinatesHoneycomb[i][11]) {
                                    arrayCoordinatesHoneycomb[i][0]++;
                                    break;
                                }
                                if (Math.abs(arrayCoordinatesHoneycomb[i][11] - arrayCoordinatesHoneycomb[i][3]) < Math.abs(arrayCoordinatesHoneycomb[i][9])) {
                                    arrayCoordinatesHoneycomb[i][3] = arrayCoordinatesHoneycomb[i][3] + (arrayCoordinatesHoneycomb[i][11] - arrayCoordinatesHoneycomb[i][3]);
                                } else {
                                    arrayCoordinatesHoneycomb[i][3] = arrayCoordinatesHoneycomb[i][3] + arrayCoordinatesHoneycomb[i][9];
                                }
                                if (arrayCoordinatesHoneycomb[i][3] <= arrayCoordinatesHoneycomb[i][11]) {
                                    arrayCoordinatesHoneycomb[i][0]++;
                                }
                                break;
                            }


                        case 3:

                            //проверка для движения вправо и вниз
                            if (arrayCoordinatesHoneycomb[i][13] > 0 && arrayCoordinatesHoneycomb[i][14] > 0) {
                                if (arrayCoordinatesHoneycomb[i][3] >= arrayCoordinatesHoneycomb[i][15] && arrayCoordinatesHoneycomb[i][4] >= arrayCoordinatesHoneycomb[i][16]) {
                                    arrayCoordinatesHoneycomb[i][0]++;
                                    break;
                                } else {
                                    if (arrayCoordinatesHoneycomb[i][3] < arrayCoordinatesHoneycomb[i][15]) {

                                        if (Math.abs(arrayCoordinatesHoneycomb[i][15] - arrayCoordinatesHoneycomb[i][3]) < Math.abs(arrayCoordinatesHoneycomb[i][13])) {
                                            arrayCoordinatesHoneycomb[i][3] = arrayCoordinatesHoneycomb[i][3] + (arrayCoordinatesHoneycomb[i][15] - arrayCoordinatesHoneycomb[i][3]);
                                        } else {
                                            arrayCoordinatesHoneycomb[i][3] = arrayCoordinatesHoneycomb[i][3] + arrayCoordinatesHoneycomb[i][13];
                                        }
                                    }
                                    if (arrayCoordinatesHoneycomb[i][4] < arrayCoordinatesHoneycomb[i][16]) {
                                        if (Math.abs(arrayCoordinatesHoneycomb[i][16] - arrayCoordinatesHoneycomb[i][4]) < Math.abs(arrayCoordinatesHoneycomb[i][14])) {
                                            arrayCoordinatesHoneycomb[i][4] = arrayCoordinatesHoneycomb[i][4] + (arrayCoordinatesHoneycomb[i][16] - arrayCoordinatesHoneycomb[i][4]);
                                        } else {
                                            arrayCoordinatesHoneycomb[i][4] = arrayCoordinatesHoneycomb[i][4] + arrayCoordinatesHoneycomb[i][14];
                                        }
                                    }
                                    break;
                                }
                            }

                            //проверка для движения влево и вверх
                            if (arrayCoordinatesHoneycomb[i][13] < 0 && arrayCoordinatesHoneycomb[i][14] < 0) {
                                if (arrayCoordinatesHoneycomb[i][3] <= arrayCoordinatesHoneycomb[i][15] && arrayCoordinatesHoneycomb[i][4] <= arrayCoordinatesHoneycomb[i][16]) {
                                    arrayCoordinatesHoneycomb[i][0]++;
                                    break;
                                } else {
                                    if (arrayCoordinatesHoneycomb[i][3] > arrayCoordinatesHoneycomb[i][15]) {

                                        if (Math.abs(arrayCoordinatesHoneycomb[i][15] - arrayCoordinatesHoneycomb[i][3]) < Math.abs(arrayCoordinatesHoneycomb[i][13])) {
                                            arrayCoordinatesHoneycomb[i][3] = arrayCoordinatesHoneycomb[i][3] + (arrayCoordinatesHoneycomb[i][15] - arrayCoordinatesHoneycomb[i][3]);
                                        } else {
                                            arrayCoordinatesHoneycomb[i][3] = arrayCoordinatesHoneycomb[i][3] + arrayCoordinatesHoneycomb[i][13];
                                        }
                                    }
                                    if (arrayCoordinatesHoneycomb[i][4] > arrayCoordinatesHoneycomb[i][16]) {
                                        if (Math.abs(arrayCoordinatesHoneycomb[i][16] - arrayCoordinatesHoneycomb[i][4]) < Math.abs(arrayCoordinatesHoneycomb[i][14])) {
                                            arrayCoordinatesHoneycomb[i][4] = arrayCoordinatesHoneycomb[i][4] + (arrayCoordinatesHoneycomb[i][16] - arrayCoordinatesHoneycomb[i][4]);
                                        } else {
                                            arrayCoordinatesHoneycomb[i][4] = arrayCoordinatesHoneycomb[i][4] + arrayCoordinatesHoneycomb[i][14];
                                        }
                                    }
                                    break;
                                }
                            }

                            //проверка для движения вправо и вверх
                            if (arrayCoordinatesHoneycomb[i][13] > 0 && arrayCoordinatesHoneycomb[i][14] < 0) {
                                if (arrayCoordinatesHoneycomb[i][3] >= arrayCoordinatesHoneycomb[i][15] && arrayCoordinatesHoneycomb[i][4] <= arrayCoordinatesHoneycomb[i][16]) {
                                    arrayCoordinatesHoneycomb[i][0]++;
                                    break;
                                } else {
                                    if (arrayCoordinatesHoneycomb[i][3] < arrayCoordinatesHoneycomb[i][15]) {

                                        if (Math.abs(arrayCoordinatesHoneycomb[i][15] - arrayCoordinatesHoneycomb[i][3]) < Math.abs(arrayCoordinatesHoneycomb[i][13])) {
                                            arrayCoordinatesHoneycomb[i][3] = arrayCoordinatesHoneycomb[i][3] + (arrayCoordinatesHoneycomb[i][15] - arrayCoordinatesHoneycomb[i][3]);
                                        } else {
                                            arrayCoordinatesHoneycomb[i][3] = arrayCoordinatesHoneycomb[i][3] + arrayCoordinatesHoneycomb[i][13];
                                        }
                                    }
                                    if (arrayCoordinatesHoneycomb[i][4] > arrayCoordinatesHoneycomb[i][16]) {
                                        if (Math.abs(arrayCoordinatesHoneycomb[i][16] - arrayCoordinatesHoneycomb[i][4]) < Math.abs(arrayCoordinatesHoneycomb[i][14])) {
                                            arrayCoordinatesHoneycomb[i][4] = arrayCoordinatesHoneycomb[i][4] + (arrayCoordinatesHoneycomb[i][16] - arrayCoordinatesHoneycomb[i][4]);
                                        } else {
                                            arrayCoordinatesHoneycomb[i][4] = arrayCoordinatesHoneycomb[i][4] + arrayCoordinatesHoneycomb[i][14];
                                        }
                                    }
                                    break;
                                }
                            }

                            //проверка для движения влево и вниз
                            if (arrayCoordinatesHoneycomb[i][13] < 0 && arrayCoordinatesHoneycomb[i][14] > 0) {
                                if (arrayCoordinatesHoneycomb[i][3] <= arrayCoordinatesHoneycomb[i][15] && arrayCoordinatesHoneycomb[i][4] >= arrayCoordinatesHoneycomb[i][16]) {
                                    arrayCoordinatesHoneycomb[i][0]++;
                                    break;
                                } else {
                                    if (arrayCoordinatesHoneycomb[i][3] > arrayCoordinatesHoneycomb[i][15]) {

                                        if (Math.abs(arrayCoordinatesHoneycomb[i][15] - arrayCoordinatesHoneycomb[i][3]) < Math.abs(arrayCoordinatesHoneycomb[i][13])) {
                                            arrayCoordinatesHoneycomb[i][3] = arrayCoordinatesHoneycomb[i][3] + (arrayCoordinatesHoneycomb[i][15] - arrayCoordinatesHoneycomb[i][3]);
                                        } else {
                                            arrayCoordinatesHoneycomb[i][3] = arrayCoordinatesHoneycomb[i][3] + arrayCoordinatesHoneycomb[i][13];
                                        }
                                    }
                                    if (arrayCoordinatesHoneycomb[i][4] < arrayCoordinatesHoneycomb[i][16]) {
                                        if (Math.abs(arrayCoordinatesHoneycomb[i][16] - arrayCoordinatesHoneycomb[i][4]) < Math.abs(arrayCoordinatesHoneycomb[i][14])) {
                                            arrayCoordinatesHoneycomb[i][4] = arrayCoordinatesHoneycomb[i][4] + (arrayCoordinatesHoneycomb[i][16] - arrayCoordinatesHoneycomb[i][4]);
                                        } else {
                                            arrayCoordinatesHoneycomb[i][4] = arrayCoordinatesHoneycomb[i][4] + arrayCoordinatesHoneycomb[i][14];
                                        }
                                    }
                                    break;
                                }
                            }

                        case 4:

                            //проверка для движения вправо и вниз
                            if (arrayCoordinatesHoneycomb[i][17] > 0 && arrayCoordinatesHoneycomb[i][18] > 0) {
                                if (arrayCoordinatesHoneycomb[i][3] >= arrayCoordinatesHoneycomb[i][19] && arrayCoordinatesHoneycomb[i][4] >= arrayCoordinatesHoneycomb[i][20]) {
                                    arrayCoordinatesHoneycomb[i][0]++;
                                    break;
                                } else {
                                    if (arrayCoordinatesHoneycomb[i][3] < arrayCoordinatesHoneycomb[i][19]) {

                                        if (Math.abs(arrayCoordinatesHoneycomb[i][19] - arrayCoordinatesHoneycomb[i][3]) < Math.abs(arrayCoordinatesHoneycomb[i][17])) {
                                            arrayCoordinatesHoneycomb[i][3] = arrayCoordinatesHoneycomb[i][3] + (arrayCoordinatesHoneycomb[i][19] - arrayCoordinatesHoneycomb[i][3]);
                                        } else {
                                            arrayCoordinatesHoneycomb[i][3] = arrayCoordinatesHoneycomb[i][3] + arrayCoordinatesHoneycomb[i][17];
                                        }
                                    }
                                    if (arrayCoordinatesHoneycomb[i][4] < arrayCoordinatesHoneycomb[i][20]) {
                                        if (Math.abs(arrayCoordinatesHoneycomb[i][20] - arrayCoordinatesHoneycomb[i][4]) < Math.abs(arrayCoordinatesHoneycomb[i][18])) {
                                            arrayCoordinatesHoneycomb[i][4] = arrayCoordinatesHoneycomb[i][4] + (arrayCoordinatesHoneycomb[i][20] - arrayCoordinatesHoneycomb[i][4]);
                                        } else {
                                            arrayCoordinatesHoneycomb[i][4] = arrayCoordinatesHoneycomb[i][4] + arrayCoordinatesHoneycomb[i][18];
                                        }
                                    }
                                    break;
                                }
                            }

                            //проверка для движения влево и вверх
                            if (arrayCoordinatesHoneycomb[i][17] < 0 && arrayCoordinatesHoneycomb[i][18] < 0) {
                                if (arrayCoordinatesHoneycomb[i][3] <= arrayCoordinatesHoneycomb[i][19] && arrayCoordinatesHoneycomb[i][4] <= arrayCoordinatesHoneycomb[i][20]) {
                                    arrayCoordinatesHoneycomb[i][0]++;
                                    break;
                                } else {
                                    if (arrayCoordinatesHoneycomb[i][3] > arrayCoordinatesHoneycomb[i][19]) {

                                        if (Math.abs(arrayCoordinatesHoneycomb[i][19] - arrayCoordinatesHoneycomb[i][3]) < Math.abs(arrayCoordinatesHoneycomb[i][17])) {
                                            arrayCoordinatesHoneycomb[i][3] = arrayCoordinatesHoneycomb[i][3] + (arrayCoordinatesHoneycomb[i][19] - arrayCoordinatesHoneycomb[i][3]);
                                        } else {
                                            arrayCoordinatesHoneycomb[i][3] = arrayCoordinatesHoneycomb[i][3] + arrayCoordinatesHoneycomb[i][17];
                                        }
                                    }
                                    if (arrayCoordinatesHoneycomb[i][4] > arrayCoordinatesHoneycomb[i][20]) {
                                        if (Math.abs(arrayCoordinatesHoneycomb[i][20] - arrayCoordinatesHoneycomb[i][4]) < Math.abs(arrayCoordinatesHoneycomb[i][18])) {
                                            arrayCoordinatesHoneycomb[i][4] = arrayCoordinatesHoneycomb[i][4] + (arrayCoordinatesHoneycomb[i][20] - arrayCoordinatesHoneycomb[i][4]);
                                        } else {
                                            arrayCoordinatesHoneycomb[i][4] = arrayCoordinatesHoneycomb[i][4] + arrayCoordinatesHoneycomb[i][18];
                                        }
                                    }
                                    break;
                                }
                            }

                            //проверка для движения вправо и вверх
                            if (arrayCoordinatesHoneycomb[i][17] > 0 && arrayCoordinatesHoneycomb[i][18] < 0) {
                                if (arrayCoordinatesHoneycomb[i][3] >= arrayCoordinatesHoneycomb[i][19] && arrayCoordinatesHoneycomb[i][4] <= arrayCoordinatesHoneycomb[i][20]) {
                                    arrayCoordinatesHoneycomb[i][0]++;
                                    break;
                                } else {
                                    if (arrayCoordinatesHoneycomb[i][3] < arrayCoordinatesHoneycomb[i][19]) {

                                        if (Math.abs(arrayCoordinatesHoneycomb[i][19] - arrayCoordinatesHoneycomb[i][3]) < Math.abs(arrayCoordinatesHoneycomb[i][17])) {
                                            arrayCoordinatesHoneycomb[i][3] = arrayCoordinatesHoneycomb[i][3] + (arrayCoordinatesHoneycomb[i][19] - arrayCoordinatesHoneycomb[i][3]);
                                        } else {
                                            arrayCoordinatesHoneycomb[i][3] = arrayCoordinatesHoneycomb[i][3] + arrayCoordinatesHoneycomb[i][17];
                                        }
                                    }
                                    if (arrayCoordinatesHoneycomb[i][4] > arrayCoordinatesHoneycomb[i][20]) {
                                        if (Math.abs(arrayCoordinatesHoneycomb[i][20] - arrayCoordinatesHoneycomb[i][4]) < Math.abs(arrayCoordinatesHoneycomb[i][18])) {
                                            arrayCoordinatesHoneycomb[i][4] = arrayCoordinatesHoneycomb[i][4] + (arrayCoordinatesHoneycomb[i][20] - arrayCoordinatesHoneycomb[i][4]);
                                        } else {
                                            arrayCoordinatesHoneycomb[i][4] = arrayCoordinatesHoneycomb[i][4] + arrayCoordinatesHoneycomb[i][18];
                                        }
                                    }
                                    break;
                                }
                            }

                            //проверка для движения влево и вниз
                            if (arrayCoordinatesHoneycomb[i][17] < 0 && arrayCoordinatesHoneycomb[i][18] > 0) {
                                if (arrayCoordinatesHoneycomb[i][3] <= arrayCoordinatesHoneycomb[i][19] && arrayCoordinatesHoneycomb[i][4] >= arrayCoordinatesHoneycomb[i][20]) {
                                    arrayCoordinatesHoneycomb[i][0]++;
                                    break;
                                } else {
                                    if (arrayCoordinatesHoneycomb[i][3] > arrayCoordinatesHoneycomb[i][19]) {

                                        if (Math.abs(arrayCoordinatesHoneycomb[i][19] - arrayCoordinatesHoneycomb[i][3]) < Math.abs(arrayCoordinatesHoneycomb[i][17])) {
                                            arrayCoordinatesHoneycomb[i][3] = arrayCoordinatesHoneycomb[i][3] + (arrayCoordinatesHoneycomb[i][19] - arrayCoordinatesHoneycomb[i][3]);
                                        } else {
                                            arrayCoordinatesHoneycomb[i][3] = arrayCoordinatesHoneycomb[i][3] + arrayCoordinatesHoneycomb[i][17];
                                        }
                                    }
                                    if (arrayCoordinatesHoneycomb[i][4] < arrayCoordinatesHoneycomb[i][20]) {
                                        if (Math.abs(arrayCoordinatesHoneycomb[i][20] - arrayCoordinatesHoneycomb[i][4]) < Math.abs(arrayCoordinatesHoneycomb[i][18])) {
                                            arrayCoordinatesHoneycomb[i][4] = arrayCoordinatesHoneycomb[i][4] + (arrayCoordinatesHoneycomb[i][20] - arrayCoordinatesHoneycomb[i][4]);
                                        } else {
                                            arrayCoordinatesHoneycomb[i][4] = arrayCoordinatesHoneycomb[i][4] + arrayCoordinatesHoneycomb[i][18];
                                        }
                                    }
                                    break;
                                }
                            }
                        case 5:                //условие для остановки таймера анимации Honeycomb
                            if (arrayCoordinatesHoneycomb[1][3] == 805 && arrayCoordinatesHoneycomb[1][4] == -95) {

                                showONanimationHoneycomb = false;
                                showONanimationHoneycomb2 = true;

                                timerHoneycomb.stop();
                                timerHoneycomb2.start();    //запуск таймера анимации Honeycomb2
                                arrayCoordinatesHoneycomb[i][0]++;
                            }
                            break;
                        case 6:                //условие для остановки таймера анимации Honeycomb
                            timerHoneycomb.stop();
                            break;
                        default:
                            System.out.println("что-то пошло не так!!!");
                    }
                }
            }
        }
    });


    //таймер для для 2-й части анимации honeycomb
    Timer timerHoneycomb2 = new Timer(timerSpeedHoneycomb, new ActionListener() {
        public void actionPerformed(ActionEvent e) {

            for (int i = 0; i <= honeycomb2.size() - 1; i++) {

                switch (arrayCoordinatesHoneycomb2[i][0]) {

                    case 0:
                        if (i == 0 && arrayCoordinatesHoneycomb2[i][1] > 0) {
                            arrayCoordinatesHoneycomb2[i][4] = arrayCoordinatesHoneycomb2[i][4] + 3;
                            arrayCoordinatesHoneycomb2[i][0]++;

                            break;
                        }

                        if (i != 0 && arrayCoordinatesHoneycomb2[i][1] > 0 && arrayCoordinatesHoneycomb2[i - 1][1] == 0) {
                            arrayCoordinatesHoneycomb2[i][4] = arrayCoordinatesHoneycomb2[i][4] + 3;
                            arrayCoordinatesHoneycomb2[i][0]++;

                            break;
                        }
                        break;

                    case 1:
                        if (i == 0 && arrayCoordinatesHoneycomb2[i][1] > 0) {
                            arrayCoordinatesHoneycomb2[i][4] = arrayCoordinatesHoneycomb2[i][4] - 3;
                            arrayCoordinatesHoneycomb2[i][0]++;
                            break;
                        }

                        if (i != 0 && arrayCoordinatesHoneycomb2[i][1] > 0 && arrayCoordinatesHoneycomb2[i - 1][1] == 0) {
                            arrayCoordinatesHoneycomb2[i][4] = arrayCoordinatesHoneycomb2[i][4] - 3;
                            arrayCoordinatesHoneycomb2[i][0]++;
                            break;
                        }
                        break;

                    case 2:
                        if (i == 0 && arrayCoordinatesHoneycomb2[i][1] > 0) {
                            arrayCoordinatesHoneycomb2[i][4] = arrayCoordinatesHoneycomb2[i][4] - 3;
                            arrayCoordinatesHoneycomb2[i][0]++;
                            break;
                        }

                        if (i != 0 && arrayCoordinatesHoneycomb2[i][1] > 0 && arrayCoordinatesHoneycomb2[i - 1][1] == 0) {
                            arrayCoordinatesHoneycomb2[i][4] = arrayCoordinatesHoneycomb2[i][4] - 3;
                            arrayCoordinatesHoneycomb2[i][0]++;
                            break;
                        }
                        break;

                    case 3:
                        if (i == 0 && arrayCoordinatesHoneycomb2[i][1] > 0) {
                            arrayCoordinatesHoneycomb2[i][4] = arrayCoordinatesHoneycomb2[i][4] + 3;
                            arrayCoordinatesHoneycomb2[i][0]++;
                            break;
                        }

                        if (i != 0 && arrayCoordinatesHoneycomb2[i][1] > 0 && arrayCoordinatesHoneycomb2[i - 1][1] == 0) {
                            arrayCoordinatesHoneycomb2[i][4] = arrayCoordinatesHoneycomb2[i][4] + 3;
                            arrayCoordinatesHoneycomb2[i][0]++;
                            break;
                        }
                        break;


                    case 4:
                        if (i == 0 && arrayCoordinatesHoneycomb2[i][1] > 0) {
                            arrayCoordinatesHoneycomb2[i][4] = arrayCoordinatesHoneycomb2[i][4] + 3;
                            arrayCoordinatesHoneycomb2[i][0]++;

                            break;
                        }

                        if (i != 0 && arrayCoordinatesHoneycomb2[i][1] > 0 && arrayCoordinatesHoneycomb2[i - 1][1] == 0) {
                            arrayCoordinatesHoneycomb2[i][4] = arrayCoordinatesHoneycomb2[i][4] + 3;
                            arrayCoordinatesHoneycomb2[i][0]++;

                            break;
                        }
                        break;

                    case 5:
                        if (i == 0 && arrayCoordinatesHoneycomb2[i][1] > 0) {
                            arrayCoordinatesHoneycomb2[i][4] = arrayCoordinatesHoneycomb2[i][4] - 3;
                            arrayCoordinatesHoneycomb2[i][0]++;
                            break;
                        }

                        if (i != 0 && arrayCoordinatesHoneycomb2[i][1] > 0 && arrayCoordinatesHoneycomb2[i - 1][1] == 0) {
                            arrayCoordinatesHoneycomb2[i][4] = arrayCoordinatesHoneycomb2[i][4] - 3;
                            arrayCoordinatesHoneycomb2[i][0]++;
                            break;
                        }
                        break;

                    case 6:
                        if (i == 0 && arrayCoordinatesHoneycomb2[i][1] > 0) {
                            arrayCoordinatesHoneycomb2[i][4] = arrayCoordinatesHoneycomb2[i][4] - 3;
                            arrayCoordinatesHoneycomb2[i][0]++;
                            break;
                        }

                        if (i != 0 && arrayCoordinatesHoneycomb2[i][1] > 0 && arrayCoordinatesHoneycomb2[i - 1][1] == 0) {
                            arrayCoordinatesHoneycomb2[i][4] = arrayCoordinatesHoneycomb2[i][4] - 3;
                            arrayCoordinatesHoneycomb2[i][0]++;
                            break;
                        }
                        break;

                    case 7:
                        if (i == 0 && arrayCoordinatesHoneycomb2[i][1] > 0) {
                            arrayCoordinatesHoneycomb2[i][4] = arrayCoordinatesHoneycomb2[i][4] + 3;
                            arrayCoordinatesHoneycomb2[i][0] = 0;
                            arrayCoordinatesHoneycomb2[i][1]--;

                            break;
                        }
                        if (i != 0 && arrayCoordinatesHoneycomb2[i][1] > 0 && arrayCoordinatesHoneycomb2[i - 1][1] == 0) {
                            arrayCoordinatesHoneycomb2[i][4] = arrayCoordinatesHoneycomb2[i][4] + 3;
                            arrayCoordinatesHoneycomb2[i][0] = 0;
                            arrayCoordinatesHoneycomb2[i][1]--;
                            if (i == 36 && arrayCoordinatesHoneycomb2[i][1] == 0) {
                                arrayCoordinatesHoneycomb2[i][0] = 8;
                                timerHoneycomb2.stop();

                                break;
                            }
                            break;
                        }
                        break;

                    case 8:
                        timerHoneycomb2.stop();
                        break;
                    default:
                        System.out.println("что-то пошло не так2!!!");
                }
            }
        }
    });


    //functions
    public void update() {
        if (showONanimationHoneycomb == true) {
            timerHoneycomb.start();   //запуск таймера анимации Honeycomb
        }
    }

    public void comparison_time() {
        if (System.currentTimeMillis() > startTimeShowAnimationHoneycomb) {               //проверка,если время,отведенное на анимацию пузырьков,время закончилось,то поменять true на false
            showONanimationHoneycomb = true;
        }
    }


    public void draw(Graphics2D g) {
        //  super.paintComponent(g);

        // Draw the background image.

        comparison_time();
        if (showONanimationHoneycomb == true) {
            for (int i = 0; i < honeycomb.size(); i++) {
                honeycombInstance = honeycomb.get(i);  //присвоение преременной honeycombInstance картинки из коллекции honeycomb с индексом "і"
                g.drawImage(new ImageIcon(honeycombInstance).getImage(), arrayCoordinatesHoneycomb[i][3], arrayCoordinatesHoneycomb[i][4], null);
            }
        }
        if (showONanimationHoneycomb2 == true) {
            for (int i = 0; i < honeycomb2.size(); i++) {

                honeycombInstance = honeycomb2.get(i);  //присвоение преременной honeycombInstance картинки из коллекции honeycomb2 с индексом "і"
                g.drawImage(new ImageIcon(honeycombInstance).getImage(), arrayCoordinatesHoneycomb2[i][3], arrayCoordinatesHoneycomb2[i][4], null);
            }
        }
    }
}
