package gameExample_6_____reliz__3.ObjectsForTheFinalAnimation;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Created by sofis on 27.05.2020.
 */
public class ConnectionStatusBackground {
    private Image s1;
    private int s2 = -1000;
    private int s3 = 0;
    private int s4 = 50;
    long s5 = System.currentTimeMillis();
    long s6 = s5 + 373 * 1000;
    private boolean s7 = false;
    private boolean s8 = false;
    ArrayList<String> s9 = new ArrayList<>();
    private String s10;
    private int s11 = 0;
    private int s12 = -13;
    private int s13 = 0;
    private int s14 = 0;
    private boolean s15 = false;
    ArrayList<String> s16 = new ArrayList<>();
    private String s17;
    private int s18 = 0;
    private int s19 = -9;
    private int s20 = 0;
    private int s21 = 0;
    public boolean s22 = false;
    private Image s23;
    private int s24;
    private int s25 = 0;
    double s26 = 0.0;
    private int s27 = 500;
    private String s28;
    private int s29;
    ArrayList<String> s30 = new ArrayList<>();
    private String s31;
    private Image s32;
    private boolean s33 = true;
    private ArrayList<StringBuilder> s34 = new ArrayList<>();
    private StringBuilder s35 = new StringBuilder();
    private String[] s36 = new String[33];
    private boolean s37 = false;
    private int s38 = 0;
    private int s39 = 0;
    private long s40 = s5 + 539 * 1000;
    private boolean s41 = false;
    private ArrayList<StringBuilder> s42 = new ArrayList<>();
    private StringBuilder s43 = new StringBuilder();
    private String[] s44 = new String[13];
    private char[] s45;
    private char s46;
    private int s47 = 0;
    private int s48 = 0;
    private int s49 = -1;
    private int s50 = -1;
    private boolean s51 = true;
    private boolean s52 = true;
    private long s53 = s5 + 544 * 1000;
    private String s55;
    private int s56 = 0;
    private int s57 = 255;
    private int s58 = 0;
    private boolean s59 = false;
    long s60 = s5 + 590 * 1000;
    private boolean s61 = false;

    public ConnectionStatusBackground() throws IOException {
        s1 = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/connectionStatusBackground/2connectionStatus_background.png"));
        for (int i = 1; i <= 21; i++) {
            s9.add("gameResourse2/resourseImages/ImagesForScreenSaver/connectionStatusBackgroundProgressBarPoints/" + i + ".png");
        }

        for (int i = 1; i <= 21; i++) {
            s16.add("gameResourse2/resourseImages/ImagesForScreenSaver/connectionStatusBackgroundProgressBar/" + i + ".png");
        }
        s32 = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/connectionStatusBackgroundProgressBarPoints/2connection established.png"));
        s36[0] = "               ";
        s36[1] = "       .       ";
        s36[2] = "      ...      ";
        s36[3] = "     . . .     ";
        s36[4] = "    .  .  .    ";
        s36[5] = "   .   .   .   ";
        s36[6] = "   .    .  .   ";
        s36[7] = "   .     . .   ";
        s36[8] = "   .      ..   ";
        s36[9] = "   .      . .  ";
        s36[10] = "   .      .  . ";
        s36[11] = "   .      .   .";
        s36[12] = "   .      .  . ";
        s36[13] = "   .      . .  ";
        s36[14] = "   .      ..   ";
        s36[15] = "   .     . .   ";
        s36[16] = "   .    .  .   ";
        s36[17] = "   .   .   .   ";
        s36[18] = "   .  .    .   ";
        s36[19] = "   . .     .   ";
        s36[20] = "   ..      .   ";
        s36[21] = "  . .      .   ";
        s36[22] = " .  .      .   ";
        s36[23] = ".   .      .   ";
        s36[24] = " .  .      .   ";
        s36[25] = "  . .      .   ";
        s36[26] = "   ..      .   ";
        s36[27] = "   . .     .   ";
        s36[28] = "   .  .    .   ";
        s36[29] = "   .   .   .   ";
        s36[30] = "    .  .  .    ";
        s36[31] = "     . . .     ";
        s36[32] = "      ...      ";
        s44[0] = "Уведомление о DOS-Атаке 81438 ";
        s44[1] = "                             ";
        s44[2] = "Фиксируется атака 81438 на IP 305.583.408.749 ";
        s44[3] = "(selectel-msk-transit-54186 ) ";
        s44[4] = "Мощность составляет 100.85 Мбит/сек,27369 ";
        s44[5] = "Важность:ВЫСОКАЯ.Тип:Total Traffic,UDP.";
        s44[6] = " ";
        s44[7] = " server ";
        s44[8] = "   was ";
        s44[9] = "hacked ";
        s44[10] = " ";
        s44[11] = "(сервер подвергся хакерской атаке)";
        s44[12] = " ";
    }

    Timer s69 = new Timer(s27, new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            s26 = s26 + 0.7;
            if (s26 >= 1.0) {
                s26 = s26 - 1.0;
                s24++;
            }
        }
    });

    Timer s70 = new Timer(s4, new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            if (s7 == true) {
                switch (s3) {
                    case 0:
                        s2 = s2 + 10;
                        if (s2 == 0) {
                            s3++;
                        }
                        break;
                    case 1:
                        s2 = s2 - 10;
                        if (s2 == -250) {
                            s3++;
                        }
                        break;
                    case 2:
                        s2 = s2 + 10;
                        if (s2 == 0) {
                            s3++;
                        }
                        break;
                    case 3:
                        s2 = s2 - 10;
                        if (s2 == -180) {
                            s3++;
                        }
                        break;
                    case 4:
                        s2 = s2 + 10;
                        if (s2 == 0) {
                            s3++;
                        }
                        break;
                    case 5:
                        s2 = s2 - 10;
                        if (s2 == -100) {
                            s3++;
                        }
                        break;
                    case 6:
                        s2 = s2 + 10;
                        if (s2 == 0) {
                            s3++;
                        }
                        break;
                    case 7:
                        s2 = s2 - 10;
                        if (s2 == -50) {
                            s3++;
                        }
                        break;
                    case 8:
                        s2 = s2 + 10;
                        if (s2 == 0) {
                            s3++;
                        }
                        break;
                    case 9:
                        s2 = s2 - 10;
                        if (s2 == -20) {
                            s3++;
                        }
                        break;
                    case 10:
                        s2 = s2 + 10;
                        if (s2 == 0) {
                            s3++;
                        }
                        break;
                    case 11:
                        s2 = s2 - 10;
                        if (s2 == -10) {
                            s3++;
                        }
                        break;
                    case 12:
                        s2 = s2 + 10;
                        if (s2 == 0) {
                            s3++;
                        }
                        break;
                    case 13:
                        s70.stop();
                        s8 = true;
                        s15 = true;
                        break;
                    default:
                        System.out.println("!");
                }
            }
        }
    });

    //functions
    public void update() throws IOException {
        s71();
        s70.start();
        if (s22 == true) {
            s69.start();
            if (s24 >= 190) {
                s69.stop();
            }
        }
    }


    public void s71() {
        if (System.currentTimeMillis() > s6) {
            s7 = true;
        }
        if (System.currentTimeMillis() > s60) {
            s61 = true;
        }
    }

    public void s73() {
        if (System.currentTimeMillis() > s40) {
            s41 = true;
        }
    }

    public void s74() {
        if (System.currentTimeMillis() > s53) {
            s52 = true;
        }
    }

    public void s76() {
        if (s48 == 12) {
            s52 = false;
        }
        if (s52 == true) {

            if (s47 == 0) {
                s43 = new StringBuilder();
                s50++;
                s42.add(s43);
                s45 = s44[s48].toCharArray();
            }
            s46 = s45[s47];
            s47++;
            if (s47 == s45.length) {
                s48++;
                if (s48 >= s44.length) {
                    s48 = 0;
                }
                s47 = 0;
            }
            s42.get(s50).append(s46);
        }
    }

    public void s77() {
        if (s11 == s9.size() - 1) {
            return;
        }
        s14++;
        if (s14 == 5) {
            s11++;
            s14 = 0;
        }
    }

    public void s78() {
        if (s18 == s16.size() - 1) {
            s22 = true;
            if (s24 < 190) {
                s37 = true;
            }
            return;
        }
        s21++;
        if (s21 == 5) {
            s18++;
            s21 = 0;
        }
    }

    public void s79() {
        s39++;
        if (s38 == s36.length - 1) {
            s38 = 3;
        }
        if (s39 == 3) {
            s39 = 0;
            s38++;
        }
    }

    public void s80() {
        if (s24 >= 190) {
            s24 = 190;
            return;
        }
        s25++;
        if (s25 == 2) {
        }
    }


    public void s81() {
        if (s56 == s9.size() - 1) {
            s15 = false;
            s22 = false;
            s59 = true;
            return;
        }
        s14++;
        if (s14 == 5) {
            s56++;
            s14 = 0;
            s37 = false;
        }
    }

    public void s82() {
        s58++;
        if (s58 == 3) {
            s57 = s57 - 1;
            s58 = 0;
            if (s57 <= 0) {
                s57 = 0;
            }
        }
    }


    public void draw(Graphics2D g) throws IOException {
        if (s61 == false) {
            g.drawImage(s1, -9, s2, null);
            if (s8 == true) {
                s77();
                s10 = s9.get(s11);
                g.drawImage(new ImageIcon(s10).getImage(), s12, s13, null);
            }
            if (s15 == true) {
                s78();
                s17 = s16.get(s18);
                g.drawImage(new ImageIcon(s17).getImage(), s19, s20, null);
            }
            if (s22 == true) {
                Color colorProgressBar = new Color(0, 150, 255);
                g.setColor(colorProgressBar);
                g.fillRect(784, 859, (0 + s24), 9);
                for (int i = s24; i <= s24; i++) {
                    s28 = String.valueOf(s24 * 100 / 190);
                    Font myFont = new Font(null, Font.BOLD, 20);
                    g.setFont(myFont);
                    g.drawString(s28 + "%", 982, 871);
                }
                if (s24 >= 190) {
                    if (s33 == true) {
                        g.drawImage(new ImageIcon(s32).getImage(), -10, 0, null);
                        s37 = false;
                    }
                }
            }
            if (s37 == true) {
                Font myFont3 = new Font(null, Font.BOLD, 62);
                g.setFont(myFont3);
                s79();
                g.drawString(String.valueOf(s36[s38]), 775, 807);
            }
            s73();
            s74();
            if (s41 == true) {
                s81();
                s55 = s9.get(s56);
                g.drawImage(new ImageIcon(s55).getImage(), s19 - 4, s20 + 63, null);
                s10 = s9.get(s56);
                g.drawImage(new ImageIcon(s10).getImage(), s12 - 1, s13 + 2, null);
                if (s59 == true) {
                    int coeff = 30;
                    int coeff2 = 10;
                    s76();
                    for (int i = 0; i < s42.size(); i++) {
                        if (i == 0) {
                            Color color1 = new Color(165, 9, 38);
                            g.setColor(color1);
                            Font myFont = new Font(null, Font.BOLD, 15);
                            g.setFont(myFont);
                            g.drawString(String.valueOf(s42.get(i)), 777, 807 + (i * coeff));
                        }
                        if (i >= 1 && i <= 6) {
                            Color color1 = new Color(9, 92, 245);
                            g.setColor(color1);
                            Font myFont = new Font(null, Font.BOLD, 11);
                            g.setFont(myFont);
                            g.drawString(String.valueOf(s42.get(i)), 777, 804 + (i * coeff2 + 29));
                        }

                        if (i >= 7 && i <= 10) {
                            s82();
                            Color color1 = new Color(2, 227, 10, s57);
                            g.setColor(color1);
                            Font myFont = new Font(null, Font.BOLD, 31);
                            g.setFont(myFont);
                            g.drawString(String.valueOf(s42.get(i)), 852, 189 + (i * 25));
                        }
                        if (i >= 11 && i <= 12) {
                            Color color1 = new Color(2, 227, 10, s57);
                            g.setColor(color1);
                            Font myFont = new Font(null, Font.BOLD, 15);
                            g.setFont(myFont);
                            g.drawString(String.valueOf(s42.get(i)), 770, 189 + (i * 23));
                        }
                    }
                }
            }
        }
    }
}
