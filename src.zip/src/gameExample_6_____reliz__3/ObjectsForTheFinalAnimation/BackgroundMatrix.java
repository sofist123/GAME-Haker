package gameExample_6_____reliz__3.ObjectsForTheFinalAnimation;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Created by sofis on 29.05.2020.
 */
public class BackgroundMatrix {
    long s = System.currentTimeMillis();
    long s1 = s + 376 * 1000;
    private boolean s2 = false;
    ArrayList<String> s3 = new ArrayList<>();
    private String s4;
    private int s5 = 0;
    private int s6 = 0;
    private boolean s7 = false;
    private int s8 = 0;
    private boolean s9 = false;
    private Image s10;
    private Image s11;
    private Image s12;
    private Image s13;
    private Image s14;
    private Image s15;
    private Image s16;
    private Image s17;
    private Image s18;
    ArrayList<String> s20 = new ArrayList<>();
    private String s21;
    private boolean s22 = false;
    private int s23 = 0;
    private int s24 = 0;
    private Image s25;
    private boolean s26 = false;
    ArrayList<String> s27 = new ArrayList<>();
    private String s28;
    private int s29 = 0;
    private int s30 = 0;
    ArrayList<String> s31 = new ArrayList<>();
    private String s32;
    private int s33 = 0;
    private int s34 = 0;
    public boolean ss35 = false;
    long s36 = s + 426 * 1000;
    private boolean s37 = false;
    ArrayList<String> s38 = new ArrayList<>();
    private String s39;
    private int s40 = 0;
    private int s41 = 0;
    private int[][] s42 = {

            {1, 1, 0, 1, 0, 1, 13, 14, 0, 0, 0, 73, 64, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 9, 0, 0, 0,},   //не планируется показывать (анимация через другой канал)
            {2, 1, 0, 12, 0, 2, 13, 14, 0, 0, 0, -167, -640, -167, 74, -167, 24, -167, 74, -167, 49, -167, 74, -167, 72, -167, 74, -167, 78, -167, 74, -167, -1, 73, -1, 73, 64,},
            {3, 1, 0, 12, 0, 2, 13, 14, 0, 0, 0, 63, -563, 63, -49, 63, -99, 63, -49, 63, -74, 63, -49, 63, -61, 63, -49, 63, -55, 63, -49, 163, -49, 163, 64, 73, 64,},
            {4, 1, 0, 12, 0, 2, 13, 14, 0, 0, 0, 288, 706, 288, 42, 288, 92, 288, 42, 288, 67, 288, 42, 288, 54, 288, 42, 288, 48, 288, 42, 288, 125, 73, 125, 73, 64,},
            {5, 1, 0, 12, 0, 2, 13, 14, 0, 0, 0, 33, 638, 33, 174, 33, 224, 33, 174, 33, 199, 33, 174, 33, 186, 33, 174, 33, 180, 33, 174, -90, 174, -90, 64, 73, 64,},
            {6, 1, 0, 10, 0, 2, 13, 14, 0, 0, 0, 173, -450, 173, 64, 173, 14, 173, 64, 173, 39, 173, 64, 173, 52, 173, 64, 173, 58, 173, 64, 73, 64,},
            {7, 1, 0, 10, 0, 2, 13, 14, 0, 0, 0, 173, 728, 173, 64, 173, 114, 173, 64, 173, 89, 173, 64, 173, 76, 173, 64, 173, 70, 173, 64, 73, 64,},
            {8, 1, 0, 10, 0, 2, 13, 14, 0, 0, 0, -27, 528, -27, 64, -27, 114, -27, 64, -27, 89, -27, 64, -27, 76, -27, 64, -27, 70, -27, 64, 73, 64,},
            {9, 1, 0, 10, 0, 2, 13, 14, 0, 0, 0, -27, -650, -27, 64, -27, 14, -27, 64, -27, 39, -27, 64, -27, 52, -27, 64, -27, 58, -27, 64, 73, 64,},
            {10, 1, 0, 5, 0, 2, 13, 14, 0, 0, 0, 73, 64, 73, 0, 0, 0, -550, 0, -550, 63, -550, 12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,},
    };

    private int s43 = 50;
    long s44 = s + 590 * 1000;
    private boolean s45 = false;

    public BackgroundMatrix() throws IOException {
        s25 = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/backgroundMatrix/2generalBackground.png"));

        s10 = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/backgroundMatrix/2clip-up.png"));
        s11 = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/backgroundMatrix/2clip-right.png"));
        s12 = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/backgroundMatrix/2clip-down.png"));
        s13 = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/backgroundMatrix/2clip-left.png"));

        s14 = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/backgroundMatrix/2panel-up-right.png"));
        s15 = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/backgroundMatrix/2panel-down-right.png"));
        s16 = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/backgroundMatrix/2panel-down-left.png"));
        s17 = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/backgroundMatrix/2panel-up-left.png"));

        for (int i = 1; i <= 115; i++) {
            s3.add("gameResourse2/resourseImages/ImagesForScreenSaver/backgroundMatrix/2crossTransformation/" + i + ".png");
        }

        for (int i = 1; i <= 21; i++) {
            s20.add("gameResourse2/resourseImages/ImagesForScreenSaver/backgroundMatrix/2seamTransparencyGeneralMatrix/" + i + ".png");
        }

        for (int i = 1; i <= 27; i++) {
            s27.add("gameResourse2/resourseImages/ImagesForScreenSaver/backgroundMatrix/2transparencyBackgroundMatrix/" + i + ".png");
        }

        for (int i = 1; i <= 28; i++) {
            s31.add("gameResourse2/resourseImages/ImagesForScreenSaver/backgroundMatrix/2solidFrame/" + i + ".png");
        }

        for (int i = 1; i <= 43; i++) {
            s38.add("gameResourse2/resourseImages/ImagesForScreenSaver/backgroundMatrix/2frameWindow/" + i + ".png");
        }
    }

    Timer s46 = new Timer(s43, new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            if (s2 == true) {
                for (int i = 0; i < s42.length; i++) {
                    if (s42[i][1] == 2) {
                        switch (s42[i][2]) {
                            case 0:
                                s42[i][2] = 1;
                                break;
                            case 1:
                                s47(i);
                                break;
                            case 2:
                                s42[i][1] = 2;
                                break;
                            default:
                                System.out.println("!");
                                break;
                        }
                    }
                }
            }
        }
    });


    public void s47(int i) {
        if (s42[i][1] == 2) {
            if (s42[i][11] < s42[i][s42[i][6]] && s42[i][12] == s42[i][s42[i][7]]) {
                if (s42[i][9] == 1) {
                    s42[i][11] = s42[i][11] + s42[i][8];
                    s42[i][8] = 0;
                }
                if (s42[i][9] == 0) {
                    s42[i][11] = s42[i][11] + (s42[i][5] * 2);
                    s42[i][9] = 1;
                }
                if (s42[i][11] < s42[i][s42[i][6]] && s42[i][12] == s42[i][s42[i][7]]) {
                    s42[i][9] = 0;
                    return;
                }
                if (s42[i][11] >= s42[i][s42[i][6]] && s42[i][12] == s42[i][s42[i][7]]) {
                    s42[i][8] = s42[i][11] - s42[i][s42[i][6]];
                    s42[i][11] = s42[i][s42[i][6]];
                    s42[i][4]++;
                    if (s42[i][4] == s42[i][3]) {
                        s42[i][2] = 2;
                        return;
                    }
                    s42[i][6] = s42[i][6] + 2;
                    s42[i][7] = s42[i][7] + 2;
                    s47(i);
                    s42[i][9] = 0;
                    return;
                }
            }
            if (s42[i][11] == s42[i][s42[i][6]] && s42[i][12] < s42[i][s42[i][7]]) {
                if (s42[i][9] == 1) {
                    s42[i][12] = s42[i][12] + s42[i][8];
                    s42[i][8] = 0;
                }
                if (s42[i][9] == 0) {
                    s42[i][12] = s42[i][12] + (s42[i][5] * 2);
                    s42[i][9] = 1;
                }
                if (s42[i][11] == s42[i][s42[i][6]] && s42[i][12] < s42[i][s42[i][7]]) {
                    s42[i][9] = 0;
                    return;
                }
                if (s42[i][11] == s42[i][s42[i][6]] && s42[i][12] >= s42[i][s42[i][7]]) {
                    s42[i][8] = s42[i][12] - s42[i][s42[i][7]];
                    s42[i][12] = s42[i][s42[i][7]];
                    s42[i][4]++;
                    if (s42[i][4] == s42[i][3]) {
                        s42[i][2] = 2;
                        return;
                    }
                    s42[i][6] = s42[i][6] + 2;
                    s42[i][7] = s42[i][7] + 2;
                    s47(i);
                    s42[i][9] = 0;
                    return;
                }
            }
            if (s42[i][11] > s42[i][s42[i][6]] && s42[i][12] == s42[i][s42[i][7]]) {
                if (s42[i][9] == 1) {
                    s42[i][11] = s42[i][11] - s42[i][8];
                    s42[i][8] = 0;
                }
                if (s42[i][9] == 0) {
                    s42[i][11] = s42[i][11] - (s42[i][5] * 2);
                    s42[i][9] = 1;
                }
                if (s42[i][11] > s42[i][s42[i][6]] && s42[i][12] == s42[i][s42[i][7]]) {
                    s42[i][9] = 0;
                    return;
                }
                if (s42[i][11] <= s42[i][s42[i][6]] && s42[i][12] == s42[i][s42[i][7]]) {
                    s42[i][8] = s42[i][s42[i][6]] - s42[i][11];
                    s42[i][11] = s42[i][s42[i][6]];
                    s42[i][4]++;
                    if (s42[i][4] == s42[i][3]) {
                        s42[i][2] = 2;
                        return;
                    }
                    s42[i][6] = s42[i][6] + 2;
                    s42[i][7] = s42[i][7] + 2;
                    s47(i);
                    s42[i][9] = 0;
                    return;
                }
            }
            if (s42[i][11] == s42[i][s42[i][6]] && s42[i][12] > s42[i][s42[i][7]]) {
                if (s42[i][9] == 1) {
                    s42[i][12] = s42[i][12] - s42[i][8];
                    s42[i][8] = 0;
                }
                if (s42[i][9] == 0) {
                    s42[i][12] = s42[i][12] - (s42[i][5] * 2);
                    s42[i][9] = 1;
                }
                if (s42[i][11] == s42[i][s42[i][6]] && s42[i][12] > s42[i][s42[i][7]]) {
                    s42[i][9] = 0;
                    return;
                }
                if (s42[i][11] == s42[i][s42[i][6]] && s42[i][12] <= s42[i][s42[i][7]]) {
                    s42[i][8] = s42[i][s42[i][7]] - s42[i][12];
                    s42[i][12] = s42[i][s42[i][7]];
                    s42[i][4]++;
                    if (s42[i][4] == s42[i][3]) {
                        s42[i][2] = 2;
                        return;
                    }
                    s42[i][6] = s42[i][6] + 2;
                    s42[i][7] = s42[i][7] + 2;
                    s47(i);
                    s42[i][9] = 0;
                    return;
                }
            }
            if (s42[i][11] < s42[i][s42[i][6]] && s42[i][12] < s42[i][s42[i][7]]) {
                if (s42[i][9] == 1) {
                    s42[i][11] = s42[i][11] + s42[i][8];
                    s42[i][12] = s42[i][12] + s42[i][8];
                    s42[i][8] = 0;
                }
                if (s42[i][9] == 0) {
                    s42[i][11] = s42[i][11] + (s42[i][5]);
                    s42[i][12] = s42[i][12] + (s42[i][5]);
                    s42[i][9] = 1;
                }
                if (s42[i][11] < s42[i][s42[i][6]] && s42[i][12] < s42[i][s42[i][7]]) {
                    s42[i][9] = 0;
                    return;
                }
                if (s42[i][11] >= s42[i][s42[i][6]] && s42[i][12] >= s42[i][s42[i][7]]) {
                    s42[i][8] = s42[i][11] - s42[i][s42[i][6]];
                    s42[i][11] = s42[i][s42[i][6]];
                    s42[i][12] = s42[i][s42[i][7]];
                    s42[i][4]++;
                    if (s42[i][4] == s42[i][3]) {
                        s42[i][2] = 2;
                        return;
                    }
                    s42[i][6] = s42[i][6] + 2;
                    s42[i][7] = s42[i][7] + 2;
                    s47(i);
                    s42[i][9] = 0;
                    return;
                }
            }
            if (s42[i][11] > s42[i][s42[i][6]] && s42[i][12] < s42[i][s42[i][7]]) {
                if (s42[i][9] == 1) {
                    s42[i][11] = s42[i][11] - s42[i][8];
                    s42[i][12] = s42[i][12] + s42[i][8];
                    s42[i][8] = 0;
                }
                if (s42[i][9] == 0) {
                    s42[i][11] = s42[i][11] - (s42[i][5]);
                    s42[i][12] = s42[i][12] + (s42[i][5]);
                    s42[i][9] = 1;
                }
                if (s42[i][11] > s42[i][s42[i][6]] && s42[i][12] < s42[i][s42[i][7]]) {
                    s42[i][9] = 0;
                    return;
                }
                if (s42[i][11] <= s42[i][s42[i][6]] && s42[i][12] >= s42[i][s42[i][7]]) {
                    s42[i][8] = s42[i][s42[i][6]] - s42[i][11];
                    s42[i][11] = s42[i][s42[i][6]];
                    s42[i][12] = s42[i][s42[i][7]];
                    s42[i][4]++;
                    if (s42[i][4] == s42[i][3]) {
                        s42[i][2] = 2;
                        return;
                    }
                    s42[i][6] = s42[i][6] + 2;
                    s42[i][7] = s42[i][7] + 2;
                    s47(i);
                    s42[i][9] = 0;
                    return;
                }
            }
            if (s42[i][11] < s42[i][s42[i][6]] && s42[i][12] > s42[i][s42[i][7]]) {

                if (s42[i][9] == 1) {
                    s42[i][11] = s42[i][11] + s42[i][8];
                    s42[i][12] = s42[i][12] - s42[i][8];
                    s42[i][8] = 0;
                }
                if (s42[i][9] == 0) {
                    s42[i][11] = s42[i][11] + (s42[i][5]);
                    s42[i][12] = s42[i][12] - (s42[i][5]);
                    s42[i][9] = 1;
                }
                if (s42[i][11] < s42[i][s42[i][6]] && s42[i][12] > s42[i][s42[i][7]]) {
                    s42[i][9] = 0;
                    return;
                }
                if (s42[i][11] >= s42[i][s42[i][6]] && s42[i][12] <= s42[i][s42[i][7]]) {
                    s42[i][8] = s42[i][11] - s42[i][s42[i][6]];
                    s42[i][11] = s42[i][s42[i][6]];
                    s42[i][12] = s42[i][s42[i][7]];
                    s42[i][4]++;
                    if (s42[i][4] == s42[i][3]) {
                        s42[i][2] = 2;
                        return;
                    }
                    s42[i][6] = s42[i][6] + 2;
                    s42[i][7] = s42[i][7] + 2;
                    s47(i);
                    s42[i][9] = 0;
                    return;
                }
            }
            if (s42[i][11] > s42[i][s42[i][6]] && s42[i][12] > s42[i][s42[i][7]]) {
                if (s42[i][9] == 1) {
                    s42[i][11] = s42[i][11] - s42[i][8];
                    s42[i][12] = s42[i][12] - s42[i][8];
                    s42[i][8] = 0;
                }
                if (s42[i][9] == 0) {
                    s42[i][11] = s42[i][11] - (s42[i][5]);
                    s42[i][12] = s42[i][12] - (s42[i][5]);
                    s42[i][9] = 1;
                }
                if (s42[i][11] > s42[i][s42[i][6]] && s42[i][12] > s42[i][s42[i][7]]) {
                    s42[i][9] = 0;
                    return;
                }
                if (s42[i][11] <= s42[i][s42[i][6]] && s42[i][12] <= s42[i][s42[i][7]]) {
                    s42[i][8] = s42[i][s42[i][6]] - s42[i][11];
                    s42[i][11] = s42[i][s42[i][6]];
                    s42[i][12] = s42[i][s42[i][7]];
                    s42[i][4]++;
                    if (s42[i][4] == s42[i][3]) {
                        s42[i][2] = 2;
                        return;
                    }
                    s42[i][6] = s42[i][6] + 2;
                    s42[i][7] = s42[i][7] + 2;
                    s47(i);
                    s42[i][9] = 0;
                    return;
                }
            }
        }
    }

    public void update() {
        s50();
        s46.start();
    }

    public void s50() {
        if (System.currentTimeMillis() > s1) {
            s2 = true;
            s8++;
            if (s8 == 1) {
                s7 = true;
            }
            if (s42[9][4] == s42[9][3]) {
                if (s29 == 14) {
                    ss35 = true;
                    s26 = false;
                    s42[9][4] = 6;
                }
            }
            if (System.currentTimeMillis() > s36) {
                ss35 = false;
                s37 = true;
            }
            if (System.currentTimeMillis() > s44) {
                s45 = true;
            }
        }
    }

    public void s51() {
        if (s5 == s3.size() - 1) {
            return;
        }
        if (s5 == s3.size() - 2) {
            for (int i = 1; i < s42.length - 1; i++) {
                s42[i][1] = 2;
            }
            s9 = true;
        }
        s6++;
        if (s6 == 2) {
            s5++;
            s6 = 0;
        }
    }

    public Image s52(int i) {
        switch (i) {
            case 1:
                s18 = s10;
                if (s42[1][4] == 12) {
                    s22 = true;
                    s9 = false;
                    s7 = false;
                }
                break;
            case 2:
                s18 = s11;
                break;
            case 3:
                s18 = s12;
                break;
            case 4:
                s18 = s13;
                break;
            case 5:
                s18 = s14;
                break;
            case 6:
                s18 = s15;
                break;
            case 7:
                s18 = s16;
                break;
            case 8:
                s18 = s17;
                break;
        }
        return s18;
    }

    public void s53() {
        if (s23 == s20.size() - 1) {
            s22 = false;
            s42[9][1] = 2;
            s26 = true;
            return;
        }
        s24++;
        if (s24 == 3) {
            s23++;
            s24 = 0;
        }
    }

    public void s54() {
        if (s29 == s27.size() - 1) {
            s29 = 0;
        }
        s30++;
        if (s30 == 4) {
            s29++;
            s30 = 0;
        }
    }

    public void s55() {
        if (s33 == s31.size() - 1) {
            s33 = 18;
            return;
        }
        s34++;
        if (s34 == 5) {
            s33++;
            s34 = 0;
        }
    }

    public void s56() {
        if (s40 == s38.size() - 1) {
            s40 = 1;
            return;
        }
        s41++;
        if (s41 == 3) {
            s40++;
            s41 = 0;
        }
    }

    public void draw(Graphics2D g) {
        if (s45 == false) {
            if (s2 == true) {
                if (s7 == true) {
                    s51();
                    s4 = s3.get(s5);
                    g.drawImage(new ImageIcon(s4).getImage(), s42[0][11], s42[0][12], null);
                }
                if (s9 == true) {
                    for (int i = 1; i < s42.length - 1; i++) {
                        s52(i);
                        g.drawImage(new ImageIcon(s18).getImage(), s42[i][11], s42[i][12], null);
                    }
                }
                if (s22 == true) {
                    g.drawImage(new ImageIcon(s25).getImage(), 73, 64, null);
                    s53();
                    s21 = s20.get(s23);
                    g.drawImage(new ImageIcon(s21).getImage(), 73, 64, null);
                }
                if (s26 == true) {
                    s54();
                    s28 = s27.get(s29);
                    g.drawImage(new ImageIcon(s28).getImage(), s42[9][11], s42[9][12], null);
                }
                if (ss35 == true) {
                    s55();
                    s32 = s31.get(s33);
                    g.drawImage(new ImageIcon(s32).getImage(), s42[9][11], s42[9][12], null);
                }
                if (s37 == true) {
                    s56();
                    s39 = s38.get(s40);
                    g.drawImage(new ImageIcon(s39).getImage(), s42[9][11], s42[9][12], null);
                }
            }
        }
    }
}

