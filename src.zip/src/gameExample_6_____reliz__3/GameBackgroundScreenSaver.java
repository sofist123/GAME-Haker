package gameExample_6_____reliz__3;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Created by sofis on 28.05.2019.
 */
public class GameBackgroundScreenSaver extends JPanel {
    //fields
    private Image backgroundImage;      //основной фон (черный)

    ArrayList<String> hieroglyphWhite1 = new ArrayList<>();   //коллекция картинок иерогифов (белые,1 - самый большой размер (размеры от 1 до 12), 12 - самый маленький размер)
    ArrayList<String> hieroglyphWhite2 = new ArrayList<>();
    ArrayList<String> hieroglyphWhite3 = new ArrayList<>();
    ArrayList<String> hieroglyphWhite4 = new ArrayList<>();
    ArrayList<String> hieroglyphWhite5 = new ArrayList<>();
    ArrayList<String> hieroglyphWhite6 = new ArrayList<>();
    ArrayList<String> hieroglyphWhite7 = new ArrayList<>();
    ArrayList<String> hieroglyphWhite8 = new ArrayList<>();
    ArrayList<String> hieroglyphWhite9 = new ArrayList<>();
    ArrayList<String> hieroglyphWhite10 = new ArrayList<>();
//    ArrayList<String> hieroglyphWhite11 = new ArrayList<>();
//    ArrayList<String> hieroglyphWhite12 = new ArrayList<>();

    ArrayList<String> hieroglyphGreen1 = new ArrayList<>();   //коллекция картинок иерогифов (зеленые,1 - самый большой размер (размеры от 1 до 12), 12 - самый маленький размер)
    ArrayList<String> hieroglyphGreen2 = new ArrayList<>();
    ArrayList<String> hieroglyphGreen3 = new ArrayList<>();
    ArrayList<String> hieroglyphGreen4 = new ArrayList<>();
    ArrayList<String> hieroglyphGreen5 = new ArrayList<>();
    ArrayList<String> hieroglyphGreen6 = new ArrayList<>();
    ArrayList<String> hieroglyphGreen7 = new ArrayList<>();
    ArrayList<String> hieroglyphGreen8 = new ArrayList<>();
    ArrayList<String> hieroglyphGreen9 = new ArrayList<>();
    ArrayList<String> hieroglyphGreen10 = new ArrayList<>();
    ArrayList<String> hieroglyphGreen11 = new ArrayList<>();
    ArrayList<String> hieroglyphGreen12 = new ArrayList<>();

    ArrayList<String> hieroglyphRed1 = new ArrayList<>();   //коллекция картинок иерогифов (зеленые,1 - самый большой размер (размеры от 1 до 3))
//    ArrayList<String> hieroglyphRed2 = new ArrayList<>();
//    ArrayList<String> hieroglyphRed3 = new ArrayList<>();

    private String hieroglyphInstance;                //экземпляр картинки из коллекции hieroglyph

    private Integer[] arrayScenarioPrime = new Integer[19];      //массив необходим в операциях,связаных с созданием и заполнением коллекций

    private int numberOfScenario;     //номер сценария,присутствующий в массиве arrayScenario
    private int quantityScenario = 480;     //количество сценариев, находящихся в коллекции сценариев (в одном столбце помещается 30 сценариев)
                           //960,480,240,120
    private  int minQuantityScenario = 10;    //минимальное количество сценариев,учавствующих в анимации


    private int gradualIncrease = 1;   //постепенное повышение количества сценариев,учавствующих в анимации
    private int deltaGradualIncrease;  //разница между quantityScenario и gradualIncrease

    private boolean reducedNumberOfScenarios = false;    //переменная регулирующая постепенное уменишение количества сценариев,учавствующих в анимации
    private boolean increaseNumberOfScenarios = true;     //переменная регулирующая постепенное повышение количества сценариев,учавствующих в анимации

    //массив  сценариев для анимации  иероглифов

    /*
    [0] - счетчик для таймера timerHieroglyph
    [1] - № иероглифа   (рандомно изменяеться от 0 до 16)
    [2] - координата "х" отображения иероглифа
    [3] - координата "у" отображения иероглифа
    [4] - задержка изменения отображения иероглифа

    [5] - порядковый номер сценария
    [6] - индекс приближения или удаления последовательности иероглифов (генерируесся рандомно,изначально =0)
    [7] - индексы для анимации отдельных иероглифов учавствующих в анимации приближения или удаления
    [8] - -----//-----
    [9] - -----//-----
    [10] - -----//-----
    [11] - -----//-----
    [12] - -----//-----
    [13] - -----//-----
    [14] - -----//-----
    [15] - -----//-----
    [16] - -----//-----
    [17] - -----//-----
    [18] - -----//-----
     */

    private Integer[][] arrayScenario = new Integer[1920][19];

    long startTime = System.currentTimeMillis();                        //переменная текущего времени (для фиксации времени начала анимации)
    long endTimeShowAnimationHieroglyph = startTime + 120 * 1000;                              // 120 seconds * 1000 ms/sec;   //время окончания воспроизведения анимации
    private boolean showONanimationHieroglyph = true;     //переменная,по состоянию которой продолжается или прекращается демонстрация анимации иероглифов

    private int timerSpeedHieroglyph = 50;       //скорость таймера для анимации Hieroglyph

    private int valueRandomDefinitionHieroglyph;   //значение,генерируемое рандомно,для задержки отображения иероглифа во время движения его по єкрану

    ArrayList<Integer[]> collectionScenarioForAnimationsHieroglyph = new ArrayList<Integer[]>();          //коллекция сценариев сгенерированых и заполненных из Integer[][] arrayScenario

    //constructor
    public GameBackgroundScreenSaver() throws IOException {
        backgroundImage = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/background/фон дым.png"));   //gameResourse/resourseImages/ImagesForScreenSaver/background(white).png

        createArrayScenario();
        createCollectionScenarioForAnimationsHieroglyph();

        for (int i = 0; i <= 17; i++) {
            hieroglyphWhite1.add("gameResourse2/resourseImages/ImagesForScreenSaver/big set/white/1/" + i + ".png");
        }

        for (int i = 0; i <= 17; i++) {
            hieroglyphWhite2.add("gameResourse2/resourseImages/ImagesForScreenSaver/big set/white/2/" + i + ".png");
        }

        for (int i = 0; i <= 17; i++) {
            hieroglyphWhite3.add("gameResourse2/resourseImages/ImagesForScreenSaver/big set/white/3/" + i + ".png");
        }

        for (int i = 0; i <= 17; i++) {
            hieroglyphWhite4.add("gameResourse2/resourseImages/ImagesForScreenSaver/big set/white/4/" + i + ".png");
        }

        for (int i = 0; i <= 17; i++) {
            hieroglyphWhite5.add("gameResourse2/resourseImages/ImagesForScreenSaver/big set/white/5/" + i + ".png");
        }

        for (int i = 0; i <= 17; i++) {
            hieroglyphWhite6.add("gameResourse2/resourseImages/ImagesForScreenSaver/big set/white/6/" + i + ".png");
        }

        for (int i = 0; i <= 17; i++) {
            hieroglyphWhite7.add("gameResourse2/resourseImages/ImagesForScreenSaver/big set/white/7/" + i + ".png");
        }

        for (int i = 0; i <= 17; i++) {
            hieroglyphWhite8.add("gameResourse2/resourseImages/ImagesForScreenSaver/big set/white/8/" + i + ".png");
        }

        for (int i = 0; i <= 17; i++) {
            hieroglyphWhite9.add("gameResourse2/resourseImages/ImagesForScreenSaver/big set/white/9/" + i + ".png");
        }

        for (int i = 0; i <= 17; i++) {
            hieroglyphWhite10.add("gameResourse2/resourseImages/ImagesForScreenSaver/big set/white/10/" + i + ".png");
        }

//        for (int i = 0; i <= 17; i++) {
//            hieroglyphWhite11.add("gameResourse/resourseImages/ImagesForScreenSaver/big set/white/11/" + i + ".png");
//        }
//
//        for (int i = 0; i <= 17; i++) {
//            hieroglyphWhite12.add("gameResourse/resourseImages/ImagesForScreenSaver/big set/white/12/" + i + ".png");
//        }

        //////////////////////////////////////////////////////////////////////

        for (int i = 0; i <= 17; i++) {
            hieroglyphGreen1.add("gameResourse2/resourseImages/ImagesForScreenSaver/big set/green/1/" + i + ".png");
        }

        for (int i = 0; i <= 17; i++) {
            hieroglyphGreen2.add("gameResourse2/resourseImages/ImagesForScreenSaver/big set/green/2/" + i + ".png");
        }

        for (int i = 0; i <= 17; i++) {
            hieroglyphGreen3.add("gameResourse2/resourseImages/ImagesForScreenSaver/big set/green/3/" + i + ".png");
        }

        for (int i = 0; i <= 17; i++) {
            hieroglyphGreen4.add("gameResourse2/resourseImages/ImagesForScreenSaver/big set/green/4/" + i + ".png");
        }

        for (int i = 0; i <= 17; i++) {
            hieroglyphGreen5.add("gameResourse2/resourseImages/ImagesForScreenSaver/big set/green/5/" + i + ".png");
        }

        for (int i = 0; i <= 17; i++) {
            hieroglyphGreen1.add("gameResourse2/resourseImages/ImagesForScreenSaver/big set/green/1/" + i + ".png");
        }

        for (int i = 0; i <= 17; i++) {
            hieroglyphGreen6.add("gameResourse2/resourseImages/ImagesForScreenSaver/big set/green/6/" + i + ".png");
        }

        for (int i = 0; i <= 17; i++) {
            hieroglyphGreen7.add("gameResourse2/resourseImages/ImagesForScreenSaver/big set/green/7/" + i + ".png");
        }

        for (int i = 0; i <= 17; i++) {
            hieroglyphGreen8.add("gameResourse2/resourseImages/ImagesForScreenSaver/big set/green/8/" + i + ".png");
        }

        for (int i = 0; i <= 17; i++) {
            hieroglyphGreen9.add("gameResourse2/resourseImages/ImagesForScreenSaver/big set/green/9/" + i + ".png");
        }

        for (int i = 0; i <= 17; i++) {
            hieroglyphGreen10.add("gameResourse2/resourseImages/ImagesForScreenSaver/big set/green/10/" + i + ".png");
        }

        for (int i = 0; i <= 17; i++) {
            hieroglyphGreen11.add("gameResourse2/resourseImages/ImagesForScreenSaver/big set/green/11/" + i + ".png");
        }

        for (int i = 0; i <= 17; i++) {
            hieroglyphGreen12.add("gameResourse2/resourseImages/ImagesForScreenSaver/big set/green/12/" + i + ".png");
        }

        //////////////////////////////////////////////////////////////////////

        for (int i = 0; i <= 17; i++) {
            hieroglyphRed1.add("gameResourse2/resourseImages/ImagesForScreenSaver/big set/red/1/" + i + ".png");
        }

//        for (int i = 0; i <= 17; i++) {
//            hieroglyphRed2.add("gameResourse/resourseImages/ImagesForScreenSaver/big set/red/2/" + i + ".png");
//        }
//
//        for (int i = 0; i <= 17; i++) {
//            hieroglyphRed3.add("gameResourse/resourseImages/ImagesForScreenSaver/big set/red/3/" + i + ".png");
//        }
    }


    //таймер для для  анимации
    Timer timerHieroglyph = new Timer(timerSpeedHieroglyph, new ActionListener() {
        public void actionPerformed(ActionEvent e) {

        //    System.out.println("старт timer...");
            for (int k = 0; k < collectionScenarioForAnimationsHieroglyph.size(); k++) {

                switch (collectionScenarioForAnimationsHieroglyph.get(k)[0]) {
                    case 0:
                        if (collectionScenarioForAnimationsHieroglyph.get(k)[6] == 1) {
                            if (collectionScenarioForAnimationsHieroglyph.get(k)[18] == 0) {
                                collectionScenarioForAnimationsHieroglyph.remove(k);

                                createCollectionScenarioForAnimationsHieroglyph();
                                break;
                            }
                        }
                        if (collectionScenarioForAnimationsHieroglyph.get(k)[6] == 2) {
                            if (collectionScenarioForAnimationsHieroglyph.get(k)[7] == 0) {
                                collectionScenarioForAnimationsHieroglyph.remove(k);

                                createCollectionScenarioForAnimationsHieroglyph();
                                break;
                            }
                        }
                        break;
                    case 1:
                        System.out.println("timerHieroglyph.stop();");
                        timerHieroglyph.stop();
                        break;
                    default:
                        System.out.println("что-то пошло не так2!!!");
                }
            }
        //    System.out.println("...финиш timer");
        }
    });


    //functions
    public void update() {
        timerHieroglyph.start();   //запуск таймера анимации Hieroglyph

    }

    public void comparison_time() {
        if (System.currentTimeMillis() > endTimeShowAnimationHieroglyph) {               //проверка,если время,отведенное на анимацию пузырьков,время закончилось,то поменять true на false
            showONanimationHieroglyph = false;
        }
    }

    public void createArrayScenario() {
        int coordinateY = 0;
        int columnIndex = 0;
        int scriptSequenceNumber = -1;   //порядковый номер сценария
        int indicesForAnimatingIndividualHieroglyphs1 = 2;       //индексы для анимации отдельных иероглифов учавствующих в анимации приближения или удаления
        //    int indicesForAnimatingIndividualHieroglyphs2 = 4;
        //    int delayInChangingTheHieroglyphDisplay;   //задержка изменения отображения иероглифа

        for (int i = 0; i < arrayScenario.length; i++) {

            //[0] - счетчик для таймера timerHieroglyph
            arrayScenario[i][0] = 0;

            // [1] - № иероглифа   (рандомно изменяеться от 0 до 16)
            arrayScenario[i][1] = (int) (0 + (Math.random() * 17));

            //[4] - задержка изменения отображения иероглифа

            //    delayInChangingTheHieroglyphDisplay = (int) (3 + (Math.random() * 4));
            arrayScenario[i][4] = (int) (1 + (Math.random() * 6));

            //[5] - порядковый номер сценария
            scriptSequenceNumber++;
            arrayScenario[i][5] = scriptSequenceNumber;


            //[6] - индекс приближения или удаления последовательности иероглифов (генерируесся рандомно,изначально =0)
            //метод рандомного определения анимации приближения или удаления последовательности иероглифов
            arrayScenario[i][6] = (int) (1 + (Math.random() * 2));

            indicesForAnimatingIndividualHieroglyphs1 = (int) (2 + (Math.random() * 3));

            if (arrayScenario[i][6] == 1) {
                arrayScenario[i][7] = indicesForAnimatingIndividualHieroglyphs1;
                arrayScenario[i][8] = indicesForAnimatingIndividualHieroglyphs1;
                arrayScenario[i][9] = indicesForAnimatingIndividualHieroglyphs1;
                arrayScenario[i][10] = indicesForAnimatingIndividualHieroglyphs1;
                arrayScenario[i][11] = indicesForAnimatingIndividualHieroglyphs1;
                arrayScenario[i][12] = indicesForAnimatingIndividualHieroglyphs1;
                arrayScenario[i][13] = indicesForAnimatingIndividualHieroglyphs1;
                arrayScenario[i][14] = indicesForAnimatingIndividualHieroglyphs1;
                arrayScenario[i][15] = indicesForAnimatingIndividualHieroglyphs1;
                arrayScenario[i][16] = indicesForAnimatingIndividualHieroglyphs1;
                arrayScenario[i][17] = indicesForAnimatingIndividualHieroglyphs1;
                arrayScenario[i][18] = indicesForAnimatingIndividualHieroglyphs1;
            }
            if (arrayScenario[i][6] == 2) {
                arrayScenario[i][7] = indicesForAnimatingIndividualHieroglyphs1;
                arrayScenario[i][8] = indicesForAnimatingIndividualHieroglyphs1;
                arrayScenario[i][9] = indicesForAnimatingIndividualHieroglyphs1;
                arrayScenario[i][10] = indicesForAnimatingIndividualHieroglyphs1;
                arrayScenario[i][11] = indicesForAnimatingIndividualHieroglyphs1;
                arrayScenario[i][12] = indicesForAnimatingIndividualHieroglyphs1;
                arrayScenario[i][13] = indicesForAnimatingIndividualHieroglyphs1;
                arrayScenario[i][14] = indicesForAnimatingIndividualHieroglyphs1;
                arrayScenario[i][15] = indicesForAnimatingIndividualHieroglyphs1;
                arrayScenario[i][16] = indicesForAnimatingIndividualHieroglyphs1;
                arrayScenario[i][17] = indicesForAnimatingIndividualHieroglyphs1;
                arrayScenario[i][18] = indicesForAnimatingIndividualHieroglyphs1;
            }

            //[2] - координата "х" отображения иероглифа
            if (columnIndex == 0) {
                arrayScenario[i][2] = 0;
            }

            if (columnIndex != 0) {
                arrayScenario[i][2] = columnIndex * 30;
            }

            //[3] - координата "archivTrackChameleon_y" отображения иероглифа
            if (columnIndex % 2 == 0) {
                if (coordinateY < 1035) {
                    arrayScenario[i][3] = coordinateY;
                    coordinateY = coordinateY + 35;
                    if (coordinateY >= 1035) {
                        coordinateY = coordinateY + 35;
                        arrayScenario[i][3] = coordinateY;
                        coordinateY = -50;
                        columnIndex++;
                    }
                }
            }

            if (columnIndex % 2 != 0) {
                if (coordinateY < 1035) {
                    arrayScenario[i][3] = coordinateY;
                    coordinateY = coordinateY + 35;
                }
                if (coordinateY >= 1035) {
                    coordinateY = coordinateY + 35;
                    arrayScenario[i][3] = coordinateY;
                    coordinateY = 0;
                    columnIndex++;
                }
            }
        }
    }

    //создание коллекции заполненой сценариями или пополнение недостающих сценариев в коллекции
    public void createCollectionScenarioForAnimationsHieroglyph() {

        int delta = quantityScenario - collectionScenarioForAnimationsHieroglyph.size();

        for (int i = 0; i < delta; i++) {       //колличество сценариев задействованых в анимации (7 - на даный момент,доступных)
            collectionScenarioForAnimationsHieroglyph.add(createScenarioHieroglyphs(i));
        }
    }


    public Integer[] createScenarioHieroglyphs(int a) {

        arrayScenarioPrime = new Integer[arrayScenarioPrime.length];
        boolean resolution = false;

    //    System.out.println("старт createScenarioHieroglyphs(int a)...");

        //генерация сценария
        if (collectionScenarioForAnimationsHieroglyph.size() == 0) {
            numberOfScenario = (int) (1 + (Math.random() * arrayScenario.length - 1));

            for (int i = 0; i < arrayScenarioPrime.length; i++) {
                arrayScenarioPrime[i] = arrayScenario[numberOfScenario][i];
            }
            //        animationOfApproachingOrRemovingHieroglyphs();
        }
        if (collectionScenarioForAnimationsHieroglyph.size() != 0) {

            //проверка на уже существующий сценарий в коллекции

            do {
                numberOfScenario = (int) (0 + (Math.random() * arrayScenario.length));
                for (int i = 0; i < collectionScenarioForAnimationsHieroglyph.size(); i++) {

                    if (collectionScenarioForAnimationsHieroglyph.get(i)[5] == numberOfScenario) {
                        resolution = false;
                        break;
                    } else {
                        resolution = true;
                    }
                }
                if (resolution == true) {
                    for (int i = 0; i < arrayScenarioPrime.length; i++) {
                        arrayScenarioPrime[i] = arrayScenario[numberOfScenario][i];
                    }
                }
            } while (resolution == false);
        }
        return arrayScenarioPrime;
    }


    public int randomDefinitionHieroglyph1(int indexArrayScript) {
        if (collectionScenarioForAnimationsHieroglyph.get(indexArrayScript)[4] == collectionScenarioForAnimationsHieroglyph.get(indexArrayScript)[5]) {
            valueRandomDefinitionHieroglyph = (int) (0 + (Math.random() * 17));
            collectionScenarioForAnimationsHieroglyph.get(indexArrayScript)[1] = valueRandomDefinitionHieroglyph;
            collectionScenarioForAnimationsHieroglyph.get(indexArrayScript)[4]--;

            return valueRandomDefinitionHieroglyph;
        }
        if (collectionScenarioForAnimationsHieroglyph.get(indexArrayScript)[4] < collectionScenarioForAnimationsHieroglyph.get(indexArrayScript)[5]) {
            valueRandomDefinitionHieroglyph = collectionScenarioForAnimationsHieroglyph.get(indexArrayScript)[1];
            collectionScenarioForAnimationsHieroglyph.get(indexArrayScript)[4]--;

            if (collectionScenarioForAnimationsHieroglyph.get(indexArrayScript)[4] == 0) {
                collectionScenarioForAnimationsHieroglyph.get(indexArrayScript)[4] = collectionScenarioForAnimationsHieroglyph.get(indexArrayScript)[5];
            }
            return valueRandomDefinitionHieroglyph;
        }
        return valueRandomDefinitionHieroglyph;
    }


    public void draw(Graphics2D g) {
        //    super.paintComponent(g);

        // Draw the background image.
        g.drawImage(backgroundImage, 0, 0, null);

        comparison_time();    //запуск функции для проверки,не окончилось ли время для анимации картинок

        //расчет deltaGradualIncrease на основании  quantityScenario и gradualIncrease
        deltaGradualIncrease = quantityScenario - gradualIncrease;

        if (showONanimationHieroglyph) {

    //        System.out.println("старт draw...");

            //проверка реализующая уменьшение и увеличение количества сценариев учавствующих в анимации
            if (increaseNumberOfScenarios == true) {
                gradualIncrease = gradualIncrease + 3;
                if (gradualIncrease >= quantityScenario) {
                    gradualIncrease = quantityScenario;
                }
                if (gradualIncrease == collectionScenarioForAnimationsHieroglyph.size()) {
                    reducedNumberOfScenarios = true;
                    increaseNumberOfScenarios = false;
                }
            }

            if (reducedNumberOfScenarios == true) {
                gradualIncrease = gradualIncrease - 3;
                if (gradualIncrease <= minQuantityScenario) {
                    gradualIncrease = minQuantityScenario;
                }
                if (gradualIncrease == minQuantityScenario) {
                    reducedNumberOfScenarios = false;
                    increaseNumberOfScenarios = true;
                }
            }

            for (int i = 0; i < collectionScenarioForAnimationsHieroglyph.size() - deltaGradualIncrease; i++) {

                int b;   //переменная устанавливающая рандомную частоту анимации зеленых,белых и красных иероглифов

                if (collectionScenarioForAnimationsHieroglyph.get(i)[6] == 1) {

                    if (collectionScenarioForAnimationsHieroglyph.get(i)[7] != 0) {
                        b = (int) (1 + (Math.random() * 45));
                        if (b >= 2 && b <= 44) {
                            hieroglyphInstance = hieroglyphGreen1.get(randomDefinitionHieroglyph1(i));
                        }
                        if (b <= 1) {
                            hieroglyphInstance = hieroglyphWhite1.get(randomDefinitionHieroglyph1(i));
                        }

                        if (b >= 45) {
                            hieroglyphInstance = hieroglyphRed1.get(randomDefinitionHieroglyph1(i));
                        }

//                        if (b >= 3 && b <= 13) {
//                            hieroglyphInstance = hieroglyphGreen1.get(randomDefinitionHieroglyph1(i));
//                        }
//                        if (b <= 2) {
//                            hieroglyphInstance = hieroglyphWhite1.get(randomDefinitionHieroglyph1(i));
//                        }
//                        if (b >= 14) {
//                            hieroglyphInstance = hieroglyphRed1.get(randomDefinitionHieroglyph1(i));
//                        }
                        collectionScenarioForAnimationsHieroglyph.get(i)[7]--;
                    }

                    if (collectionScenarioForAnimationsHieroglyph.get(i)[8] != 0 && collectionScenarioForAnimationsHieroglyph.get(i)[7] == 0) {
                        b = (int) (1 + (Math.random() * 25));
                        if (b >= 2) {
                            hieroglyphInstance = hieroglyphGreen2.get(randomDefinitionHieroglyph1(i));
                        }
                        if (b <= 1) {
                            hieroglyphInstance = hieroglyphWhite2.get(randomDefinitionHieroglyph1(i));
                        }

//                        if (b >= 3 && b <= 13) {
//                            hieroglyphInstance = hieroglyphGreen2.get(randomDefinitionHieroglyph1(i));
//                        }
//                        if (b <= 2) {
//                            hieroglyphInstance = hieroglyphWhite2.get(randomDefinitionHieroglyph1(i));
//                        }
//                        if (b >= 14) {
//                            hieroglyphInstance = hieroglyphRed2.get(randomDefinitionHieroglyph1(i));
//                        }
                        collectionScenarioForAnimationsHieroglyph.get(i)[8]--;
                    }
                    if (collectionScenarioForAnimationsHieroglyph.get(i)[9] != 0 && collectionScenarioForAnimationsHieroglyph.get(i)[8] == 0) {
                        b = (int) (1 + (Math.random() * 25));
                        if (b >= 2) {
                            hieroglyphInstance = hieroglyphGreen3.get(randomDefinitionHieroglyph1(i));
                        }
                        if (b <= 1) {
                            hieroglyphInstance = hieroglyphWhite3.get(randomDefinitionHieroglyph1(i));
                        }

//                        if (b >= 3 && b <= 13) {
//                            hieroglyphInstance = hieroglyphGreen3.get(randomDefinitionHieroglyph1(i));
//                        }
//                        if (b <= 2) {
//                            hieroglyphInstance = hieroglyphWhite3.get(randomDefinitionHieroglyph1(i));
//                        }
//                        if (b >= 14) {
//                            hieroglyphInstance = hieroglyphRed3.get(randomDefinitionHieroglyph1(i));
//                        }
                        collectionScenarioForAnimationsHieroglyph.get(i)[9]--;
                    }
                    if (collectionScenarioForAnimationsHieroglyph.get(i)[10] != 0 && collectionScenarioForAnimationsHieroglyph.get(i)[9] == 0) {
                        b = (int) (1 + (Math.random() * 25));
                        if (b >= 2) {
                            hieroglyphInstance = hieroglyphGreen4.get(randomDefinitionHieroglyph1(i));
                        }
                        if (b <= 1) {
                            hieroglyphInstance = hieroglyphWhite4.get(randomDefinitionHieroglyph1(i));
                        }
                        collectionScenarioForAnimationsHieroglyph.get(i)[10]--;
                    }
                    if (collectionScenarioForAnimationsHieroglyph.get(i)[11] != 0 && collectionScenarioForAnimationsHieroglyph.get(i)[10] == 0) {
                        b = (int) (1 + (Math.random() * 25));
                        if (b >= 2) {
                            hieroglyphInstance = hieroglyphGreen5.get(randomDefinitionHieroglyph1(i));
                        }
                        if (b <= 1) {
                            hieroglyphInstance = hieroglyphWhite5.get(randomDefinitionHieroglyph1(i));
                        }
                        collectionScenarioForAnimationsHieroglyph.get(i)[11]--;
                    }
                    if (collectionScenarioForAnimationsHieroglyph.get(i)[12] != 0 && collectionScenarioForAnimationsHieroglyph.get(i)[11] == 0) {
                        b = (int) (1 + (Math.random() * 25));
                        if (b >= 2) {
                            hieroglyphInstance = hieroglyphGreen6.get(randomDefinitionHieroglyph1(i));
                        }
                        if (b <= 1) {
                            hieroglyphInstance = hieroglyphWhite6.get(randomDefinitionHieroglyph1(i));
                        }
                        collectionScenarioForAnimationsHieroglyph.get(i)[12]--;
                    }
                    if (collectionScenarioForAnimationsHieroglyph.get(i)[13] != 0 && collectionScenarioForAnimationsHieroglyph.get(i)[12] == 0) {
                        b = (int) (1 + (Math.random() * 25));
                        if (b >= 2) {
                            hieroglyphInstance = hieroglyphGreen7.get(randomDefinitionHieroglyph1(i));
                        }
                        if (b <= 1) {
                            hieroglyphInstance = hieroglyphWhite7.get(randomDefinitionHieroglyph1(i));
                        }
                        collectionScenarioForAnimationsHieroglyph.get(i)[13]--;
                    }
                    if (collectionScenarioForAnimationsHieroglyph.get(i)[14] != 0 && collectionScenarioForAnimationsHieroglyph.get(i)[13] == 0) {
                        b = (int) (1 + (Math.random() * 25));
                        if (b >= 2) {
                            hieroglyphInstance = hieroglyphGreen8.get(randomDefinitionHieroglyph1(i));
                        }
                        if (b <= 1) {
                            hieroglyphInstance = hieroglyphWhite8.get(randomDefinitionHieroglyph1(i));
                        }
                        collectionScenarioForAnimationsHieroglyph.get(i)[14]--;
                    }
                    if (collectionScenarioForAnimationsHieroglyph.get(i)[15] != 0 && collectionScenarioForAnimationsHieroglyph.get(i)[14] == 0) {
                        b = (int) (1 + (Math.random() * 25));
                        if (b >= 2) {
                            hieroglyphInstance = hieroglyphGreen9.get(randomDefinitionHieroglyph1(i));
                        }
                        if (b <= 1) {
                            hieroglyphInstance = hieroglyphWhite9.get(randomDefinitionHieroglyph1(i));
                        }
                        collectionScenarioForAnimationsHieroglyph.get(i)[15]--;
                    }
                    if (collectionScenarioForAnimationsHieroglyph.get(i)[16] != 0 && collectionScenarioForAnimationsHieroglyph.get(i)[15] == 0) {
                        b = (int) (1 + (Math.random() * 25));
                        if (b >= 2) {
                            hieroglyphInstance = hieroglyphGreen10.get(randomDefinitionHieroglyph1(i));
                        }
                        if (b <= 1) {
                            hieroglyphInstance = hieroglyphWhite10.get(randomDefinitionHieroglyph1(i));
                        }
                        collectionScenarioForAnimationsHieroglyph.get(i)[16]--;
                    }
                    if (collectionScenarioForAnimationsHieroglyph.get(i)[17] != 0 && collectionScenarioForAnimationsHieroglyph.get(i)[16] == 0) {
                        hieroglyphInstance = hieroglyphGreen11.get(randomDefinitionHieroglyph1(i));
                        collectionScenarioForAnimationsHieroglyph.get(i)[17]--;
                    }
                    if (collectionScenarioForAnimationsHieroglyph.get(i)[18] != 0 && collectionScenarioForAnimationsHieroglyph.get(i)[17] == 0) {
                        hieroglyphInstance = hieroglyphGreen12.get(randomDefinitionHieroglyph1(i));
                        collectionScenarioForAnimationsHieroglyph.get(i)[18]--;
                    }

                    g.drawImage(new ImageIcon(String.valueOf(hieroglyphInstance)).getImage(), collectionScenarioForAnimationsHieroglyph.get(i)[2], collectionScenarioForAnimationsHieroglyph.get(i)[3], null);
                }

                if (collectionScenarioForAnimationsHieroglyph.get(i)[6] == 2) {

                    if (collectionScenarioForAnimationsHieroglyph.get(i)[18] != 0) {
                        hieroglyphInstance = hieroglyphGreen12.get(randomDefinitionHieroglyph1(i));
                        collectionScenarioForAnimationsHieroglyph.get(i)[18]--;
                    }
                    if (collectionScenarioForAnimationsHieroglyph.get(i)[17] != 0 && collectionScenarioForAnimationsHieroglyph.get(i)[18] == 0) {
                        hieroglyphInstance = hieroglyphGreen11.get(randomDefinitionHieroglyph1(i));
                        collectionScenarioForAnimationsHieroglyph.get(i)[17]--;
                    }
                    if (collectionScenarioForAnimationsHieroglyph.get(i)[16] != 0 && collectionScenarioForAnimationsHieroglyph.get(i)[17] == 0) {
                        b = (int) (1 + (Math.random() * 25));
                        if (b >= 2) {
                            hieroglyphInstance = hieroglyphGreen10.get(randomDefinitionHieroglyph1(i));
                        }
                        if (b <= 1) {
                            hieroglyphInstance = hieroglyphWhite10.get(randomDefinitionHieroglyph1(i));
                        }
                        collectionScenarioForAnimationsHieroglyph.get(i)[16]--;
                    }
                    if (collectionScenarioForAnimationsHieroglyph.get(i)[15] != 0 && collectionScenarioForAnimationsHieroglyph.get(i)[16] == 0) {
                        b = (int) (1 + (Math.random() * 25));
                        if (b >= 2) {
                            hieroglyphInstance = hieroglyphGreen9.get(randomDefinitionHieroglyph1(i));
                        }
                        if (b <= 1) {
                            hieroglyphInstance = hieroglyphWhite9.get(randomDefinitionHieroglyph1(i));
                        }
                        collectionScenarioForAnimationsHieroglyph.get(i)[15]--;
                    }
                    if (collectionScenarioForAnimationsHieroglyph.get(i)[14] != 0 && collectionScenarioForAnimationsHieroglyph.get(i)[15] == 0) {
                        b = (int) (1 + (Math.random() * 25));
                        if (b >= 2) {
                            hieroglyphInstance = hieroglyphGreen8.get(randomDefinitionHieroglyph1(i));
                        }
                        if (b <= 1) {
                            hieroglyphInstance = hieroglyphWhite8.get(randomDefinitionHieroglyph1(i));
                        }
                        collectionScenarioForAnimationsHieroglyph.get(i)[14]--;
                    }
                    if (collectionScenarioForAnimationsHieroglyph.get(i)[13] != 0 && collectionScenarioForAnimationsHieroglyph.get(i)[14] == 0) {
                        b = (int) (1 + (Math.random() * 25));
                        if (b >= 2) {
                            hieroglyphInstance = hieroglyphGreen7.get(randomDefinitionHieroglyph1(i));
                        }
                        if (b <= 1) {
                            hieroglyphInstance = hieroglyphWhite7.get(randomDefinitionHieroglyph1(i));
                        }
                        collectionScenarioForAnimationsHieroglyph.get(i)[13]--;
                    }
                    if (collectionScenarioForAnimationsHieroglyph.get(i)[12] != 0 && collectionScenarioForAnimationsHieroglyph.get(i)[13] == 0) {
                        b = (int) (1 + (Math.random() * 25));
                        if (b >= 2) {
                            hieroglyphInstance = hieroglyphGreen6.get(randomDefinitionHieroglyph1(i));
                        }
                        if (b <= 1) {
                            hieroglyphInstance = hieroglyphWhite6.get(randomDefinitionHieroglyph1(i));
                        }
                        collectionScenarioForAnimationsHieroglyph.get(i)[12]--;
                    }
                    if (collectionScenarioForAnimationsHieroglyph.get(i)[11] != 0 && collectionScenarioForAnimationsHieroglyph.get(i)[12] == 0) {
                        b = (int) (1 + (Math.random() * 25));
                        if (b >= 2) {
                            hieroglyphInstance = hieroglyphGreen5.get(randomDefinitionHieroglyph1(i));
                        }
                        if (b <= 1) {
                            hieroglyphInstance = hieroglyphWhite5.get(randomDefinitionHieroglyph1(i));
                        }
                        collectionScenarioForAnimationsHieroglyph.get(i)[11]--;
                    }
                    if (collectionScenarioForAnimationsHieroglyph.get(i)[10] != 0 && collectionScenarioForAnimationsHieroglyph.get(i)[11] == 0) {
                        b = (int) (1 + (Math.random() * 25));
                        if (b >= 2) {
                            hieroglyphInstance = hieroglyphGreen4.get(randomDefinitionHieroglyph1(i));
                        }
                        if (b <= 1) {
                            hieroglyphInstance = hieroglyphWhite4.get(randomDefinitionHieroglyph1(i));
                        }
                        collectionScenarioForAnimationsHieroglyph.get(i)[10]--;
                    }
                    if (collectionScenarioForAnimationsHieroglyph.get(i)[9] != 0 && collectionScenarioForAnimationsHieroglyph.get(i)[10] == 0) {
                        b = (int) (1 + (Math.random() * 25));
                        if (b >= 2) {
                            hieroglyphInstance = hieroglyphGreen3.get(randomDefinitionHieroglyph1(i));
                        }
                        if (b <= 1) {
                            hieroglyphInstance = hieroglyphWhite3.get(randomDefinitionHieroglyph1(i));
                        }

//                        if (b >= 3 && b <= 13) {
//                            hieroglyphInstance = hieroglyphGreen3.get(randomDefinitionHieroglyph1(i));
//                        }
//                        if (b <= 2) {
//                            hieroglyphInstance = hieroglyphWhite3.get(randomDefinitionHieroglyph1(i));
//                        }
//                        if (b >= 14) {
//                            hieroglyphInstance = hieroglyphRed3.get(randomDefinitionHieroglyph1(i));
//                        }
                        collectionScenarioForAnimationsHieroglyph.get(i)[9]--;
                    }
                    if (collectionScenarioForAnimationsHieroglyph.get(i)[8] != 0 && collectionScenarioForAnimationsHieroglyph.get(i)[9] == 0) {
                        b = (int) (1 + (Math.random() * 25));
                        if (b >= 2) {
                            hieroglyphInstance = hieroglyphGreen2.get(randomDefinitionHieroglyph1(i));
                        }
                        if (b <= 1) {
                            hieroglyphInstance = hieroglyphWhite2.get(randomDefinitionHieroglyph1(i));
                        }

//                        if (b >= 3 && b <= 13) {
//                            hieroglyphInstance = hieroglyphGreen2.get(randomDefinitionHieroglyph1(i));
//                        }
//                        if (b <= 2) {
//                            hieroglyphInstance = hieroglyphWhite2.get(randomDefinitionHieroglyph1(i));
//                        }
//                        if (b >= 14) {
//                            hieroglyphInstance = hieroglyphRed2.get(randomDefinitionHieroglyph1(i));
//                        }
                        collectionScenarioForAnimationsHieroglyph.get(i)[8]--;
                    }
                    if (collectionScenarioForAnimationsHieroglyph.get(i)[7] != 0 && collectionScenarioForAnimationsHieroglyph.get(i)[8] == 0) {
                        b = (int) (1 + (Math.random() * 45));
                        if (b >= 2 && b <= 44) {
                            hieroglyphInstance = hieroglyphGreen1.get(randomDefinitionHieroglyph1(i));
                        }
                        if (b <= 1) {
                            hieroglyphInstance = hieroglyphWhite1.get(randomDefinitionHieroglyph1(i));
                        }

                        if (b >= 45) {
                            hieroglyphInstance = hieroglyphRed1.get(randomDefinitionHieroglyph1(i));
                        }
//                        if (b >= 3 && b <= 13) {
//                            hieroglyphInstance = hieroglyphGreen1.get(randomDefinitionHieroglyph1(i));
//                        }
//                        if (b <= 2) {
//                            hieroglyphInstance = hieroglyphWhite1.get(randomDefinitionHieroglyph1(i));
//                        }
//                        if (b >= 14) {
//                            hieroglyphInstance = hieroglyphRed1.get(randomDefinitionHieroglyph1(i));
//                        }
                        collectionScenarioForAnimationsHieroglyph.get(i)[7]--;
                    }
                    g.drawImage(new ImageIcon(String.valueOf(hieroglyphInstance)).getImage(), collectionScenarioForAnimationsHieroglyph.get(i)[2], collectionScenarioForAnimationsHieroglyph.get(i)[3], null);
                }
            }
    //        System.out.println("...финиш draw");
        }
    }
}
