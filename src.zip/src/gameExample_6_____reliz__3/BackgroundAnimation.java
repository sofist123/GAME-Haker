package gameExample_6_____reliz__3;

import javax.imageio.ImageIO;
import java.awt.*;
import java.io.File;
import java.io.IOException;

/**
 * Created by sofis on 02.02.2020.
 */
public class BackgroundAnimation {
    //fields
    private Image backgroundForAnimation;       //переменная бекграунда с дорожками(все дорожки)
 //   private Image backgroundForAnimationWithWindow;       //переменная бекграунда с дорожками(все дорожки)

    public boolean showOnBackgroundAnimation = false;    //разрешение на анимацию бекграунда

    long startTime = System.currentTimeMillis();                        //переменная текущего времени (для фиксации времени начала анимации)
    long startTimeShowBackgroundAnimation = startTime + 347 * 1000;  //((347) - должно стоять в релизе)ключевая точка времени (изначально = ) //время задержки начала анимации бекграунда                          // 60 seconds * 1000 ms/sec;   //время окончания воспроизведения анимации

    //////////////////////////////////////////////

    private int[][][] arrayCoordinatesPieceOfTransparency = new int[390][220][3];        //массив с координатами частичек прозрачности
    //    private int row = 0;                                 //ряд
//    private int column = 0;                              //колонка
    private int particleSideSize = 5;               //размер стороны частички


    //////////////////////////////////////////////

    private Image particlesOfTransparency;          //картина частички прозрачности

    private Image particlesOfTransparency100;        //картина частички прозрачности (100% не прозрачная)
    private Image particlesOfTransparency75;         //картина частички прозрачности (75% не прозрачная)
    private Image particlesOfTransparency70;        //картина частички прозрачности (70% не прозрачная)
    private Image particlesOfTransparency0;         //картина частички прозрачности (полностью прозрачная)

    private int numberI = -1;                      //рандомное число для анимации изменения прозрачности
    private int numberJ = -1;                      //рандомное число для анимации изменения прозрачности
    private boolean permissionToChangeTransparencyInParticles = false;    //разрешение на изменение прозрачности у частичек

    private int countOfParticlesToBeChanged = 0;     //количество изменяемых частиц

    private int numberOfParticlesChanged = 0;         //количество измененных частиц

    private boolean  particleTransparencyPermission = true;    //разрешение на изменение прозрачности частиц
    ///////////////////////////////////////////////


    //constructor
    public BackgroundAnimation() throws IOException {

        backgroundForAnimation = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/backgroundForAnimation/2backgroundForAnimation.png"));

    //    backgroundForAnimationWithWindow =  ImageIO.read(new File("gameResourse/resourseImages/ImagesForScreenSaver/backgroundForAnimation/backgroundForAnimationWithWindow.png"));


        particlesOfTransparency100 = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/backgroundForAnimation/5-100.png"));
    //    particlesOfTransparency75 = ImageIO.read(new File("gameResourse/resourseImages/ImagesForScreenSaver/backgroundForAnimation/75.png"));
    //    particlesOfTransparency70 = ImageIO.read(new File("gameResourse/resourseImages/ImagesForScreenSaver/backgroundForAnimation/70.png"));
        particlesOfTransparency0 = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/backgroundForAnimation/5-0.png"));


        //заполнение массива данными (координаты расположения частичек прозрачности)
        for (int i = 0; i < arrayCoordinatesPieceOfTransparency.length; i++) {
            for (int j = 0; j < arrayCoordinatesPieceOfTransparency[i].length; j++) {
                arrayCoordinatesPieceOfTransparency[i][j][0] = 1;                               //1-частичка со 100%-й непроницаемостью (2-75%-ая проницаемость,3-70%-ая проницаемость)
                arrayCoordinatesPieceOfTransparency[i][j][1] = particleSideSize * i;
                arrayCoordinatesPieceOfTransparency[i][j][2] = particleSideSize * j;
            }
        }

    }

    //functions
    public void update() {
        comparison_time();


    }

    //определение времени запуска анимации прописаном в классе BackgroundAnimation
    public void comparison_time() {
        if (System.currentTimeMillis() > startTimeShowBackgroundAnimation) {               //проверка,если время,startTime = System.currentTimeMillis(); больше startTimeShowBackgroundAnimation,то поменять false  на true (т.е. разрешить анимацию бекграунда)
            showOnBackgroundAnimation = true;
        }
    }

    //замена частичек прозрачности
    public void replacingParticlesOfTransparency() {

        permissionToChangeTransparencyInParticles = false;
        //    countOfParticlesToBeChanged = 0;


        do {

            if (countOfParticlesToBeChanged == 200) {
                permissionToChangeTransparencyInParticles = true;
                return;
            }


            numberI = (int) (0 + (Math.random() * (arrayCoordinatesPieceOfTransparency.length )));
            numberJ = (int) (0 + (Math.random() * (arrayCoordinatesPieceOfTransparency[numberI].length )));

            if (arrayCoordinatesPieceOfTransparency[numberI][numberJ][0] == 1) {
                arrayCoordinatesPieceOfTransparency[numberI][numberJ][0] = 4;
                countOfParticlesToBeChanged++;

                numberOfParticlesChanged++;
                System.out.println("numberOfParticlesChanged = "+numberOfParticlesChanged);
                //            permissionToChangeTransparencyInParticles = true;
                //        return;
                break;
            }
//            if (arrayCoordinatesPieceOfTransparency[numberI][numberJ][0] == 2) {
//                arrayCoordinatesPieceOfTransparency[numberI][numberJ][0] = 3;
//                countOfParticlesToBeChanged++;
//                //            permissionToChangeTransparencyInParticles = true;
//                //        return;
//                break;
//            }
//            if (arrayCoordinatesPieceOfTransparency[numberI][numberJ][0] == 3) {
//                arrayCoordinatesPieceOfTransparency[numberI][numberJ][0] = 4;
//                countOfParticlesToBeChanged++;
//                //            permissionToChangeTransparencyInParticles = true;
//                //        return;
//                break;
//            }
            if (arrayCoordinatesPieceOfTransparency[numberI][numberJ][0] == 4) {
                permissionToChangeTransparencyInParticles = false;
                //        return;
                //    break;
            }

        } while (permissionToChangeTransparencyInParticles == false);

    }


    public void draw(Graphics2D g) {
        if (showOnBackgroundAnimation == true) {
            g.drawImage(backgroundForAnimation, 0, 0, null);
        }

        //проверка разрешения на изменеие прозрачности частиц
        if(numberOfParticlesChanged == 85800){
            particleTransparencyPermission = false;
            System.out.println("particleTransparencyPermission = "+ particleTransparencyPermission);

        }



        //изменеие прозрачности частиц
        if(particleTransparencyPermission == true && showOnBackgroundAnimation == true){

            System.out.println("particleTransparencyPermission = "+ particleTransparencyPermission);

            countOfParticlesToBeChanged = 0;
            do {
                if (countOfParticlesToBeChanged <= 200) {
                    replacingParticlesOfTransparency();
                    //        countOfParticlesToBeChanged++;
                }
            } while (permissionToChangeTransparencyInParticles == false);

            //       replacingParticlesOfTransparency();

            for (int i = 0; i < arrayCoordinatesPieceOfTransparency.length; i++) {
                for (int j = 0; j < arrayCoordinatesPieceOfTransparency[i].length; j++) {

                    if (arrayCoordinatesPieceOfTransparency[i][j][0] == 1) {
                        particlesOfTransparency = particlesOfTransparency100;
                        //                    arrayCoordinatesPieceOfTransparency[i][j][0] = 2;

                    }
//                    if (arrayCoordinatesPieceOfTransparency[i][j][0] == 2) {
//                        particlesOfTransparency = particlesOfTransparency75;
//                        //                    arrayCoordinatesPieceOfTransparency[i][j][0] = 3;
//                    }
//                    if (arrayCoordinatesPieceOfTransparency[i][j][0] == 3) {
//                        particlesOfTransparency = particlesOfTransparency70;
//                        //                    arrayCoordinatesPieceOfTransparency[i][j][0] = 4;
//                    }
                    if (arrayCoordinatesPieceOfTransparency[i][j][0] == 4) {
                        particlesOfTransparency = particlesOfTransparency0;
                    }

                    g.drawImage(particlesOfTransparency, arrayCoordinatesPieceOfTransparency[i][j][1], arrayCoordinatesPieceOfTransparency[i][j][2], null);
                    //                System.out.println("arrayCoordinatesPieceOfTransparency[i][j][1] = " + arrayCoordinatesPieceOfTransparency[i][j][1] + "    arrayCoordinatesPieceOfTransparency[i][j][2] = " + arrayCoordinatesPieceOfTransparency[i][j][2] + "   arrayCoordinatesPieceOfTransparency[i][j][0] = " + arrayCoordinatesPieceOfTransparency[i][j][0]);

                }
            }


        }

    }

}
