package gameExample_6_____reliz__3;

import gameExample_6_____reliz__3.ObjectsForTheFinalAnimation.BackgroundMatrix;
import gameExample_6_____reliz__3.Track.Track1;
import gameExample_6_____reliz__3.Track.Track2;
import gameExample_6_____reliz__3.Track.Track3;
import gameExample_6_____reliz__3.Track.Track4;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Created by sofis on 02.02.2020.
 */
public class ElectricalImpulse {
    //fields
    private Image backgroundForAnimation;       //переменная бекграунда с дорожками(все дорожки)
    public boolean showOnElectricalImpulse = false;    //разрешение на анимацию бекграунда

    private Image backgroundForAnimationWithWindow;       //переменная бекграунда с пустым окном под бекграунд матрицы


    long startTime = System.currentTimeMillis();                        //переменная текущего времени (для фиксации времени начала анимации)
    long startTimeShowElectricalImpulse = startTime + 372 * 1000;  //((372) - должно стоять в релизе)ключевая точка времени (изначально = ) //время задержки начала анимации бекграунда                          // 60 seconds * 1000 ms/sec;   //время окончания воспроизведения анимации

    /////////////////////////////////////////////////////

    ArrayList<String> impulseCollection = new ArrayList<>();   //коллекция картинок для анимации импульса
    private String impulseInstance;                //экземпляр картинки из коллекции eraserCollection

    private Image impulsePicture;    //изображение импульса
    //   private Image impulseFinishPicture;    //изображение окончания анимации изображения импульса


    ArrayList<String> impulseAttenuation = new ArrayList<>();    //коллекция картинок для анимации затухания

    /////////////////////////////////////////////////////

    private int[] way = new int[76];   //экземпляр пути, учавствующий в анимации в данный момент
    private int[] wayDublikatCorrector = new int[76];   //для записи скорректированого экземпляра

    private ArrayList<int[]> collectionsWayElectricalImpulseAnimationCoordinates = new ArrayList<>();   //коллекция  путей, учавствующих в анимации в данный момент

    //  private ArrayList<int[]> collectionForAnimation = new ArrayList<>();   //коллекция для анимации


    private int[] impulseComponentCoordinates = new int[2];
    //координаты  [0]-"x" конкретного istance
    //            [1]-"y" конкретного istance

    private ArrayList<ArrayList<int[]>> collectionOfCollectionsWayElectricalImpulseAnimationCoordinates = new ArrayList<>();   //коллекция коллекций путей, учавствующих в анимации в данный момент

    private int chainLengthWay = 1;        //длинна цепочки электронных импульсов (еоличество istance в конкретном импульсе)

    private int allowableCollectionSize = 30;                         //допустимый размер коллекции


    private int countAdmissionToTheMainPart = 1;           //счетчик доступа к основной части анимации импульсов
    private boolean admissionToTheMainPart = false;      //переменная,разрешающая допуск к основной части анимации
    //    private boolean admissionToTheMainPart2 = true;      //вспомогательная переменная анимации начальной части
    private int allowableCollectionSize2 = 1;                         //допустимый размер коллекции2


    private int axisCorrection_x = 3;                  //поправка по оси :x:
    private int axisCorrection_y = 7;                  //поправка по оси :y:

    private int numberWayAttachedToTheElectricalImpulseAnimationCollection = 0;     // колличетсво way присоедененных к коллекции анимации электрических импульсов
    private int numberClassTrack;                        //номер класса Track

    private int speedPointImpulse = 20;   //начальная скорость импульса (экземпляра импульса)


    private int stepBetweenInstancesInAImpulse = 3;    //шаг между экземплярами в импульсе

    private int speedDiapazonImpulse = 1;    //диапазон скоростей,которые будут присваиваться импульсам
    private int allowableNumberOfInstancesWay = 2;       //допустимое количество екземпляров way (путей одного направления)
    private int aIndex;                     //индекс для метода dataProcessingFotTimer
    private int bIndex;                     //индекс для метода dataProcessingFotTimer

    /////////////////////////////////////////////////////

//    [0] - номер пути
//    [1] - для timerWayForElectricalImpulse, номер case (для допуска отработки таймера,нужно поменять на "0")
//    [2] - номер рисунка для отображения анимации ElectricalImpulse  (от 1 до 5)
//    [3] - вспомогательный счетчик для анимации экземпляка картинки из коллекции impulseCollection (задержка анимации передвижения электрического импульса)
//    [4] - скорость электрического импульса (генерируется рандомно и для каждого way-импульса отдельно.содержащаяся информация в arrayCoordinatesTrackForСleaning не имеет значения)
//    [5] - шаг между экземплярами в импульсе
//
//
//    в этой ячейке содержится информация о кличестве экземпляров импульсов,походящихся на данной дорожке (данная информация важна только для учета и разрешения добавлять или нет на этот путь импульсы)
//
//    [6] - 1-я координата "x" кольца генерации электрического импульса
//    [7] - 1-я координата "y" кольца генерации электрического импульса
//    [8] - отработка  генерации импульса(1-не разрешено, 2-разрешено)
//    [9] - номер рисунка для отображения анимации генерации электрического импульса (для 1-го кольца) (от 0 до ?)
//    [10] - вспомогательный счетчик для анимации экземпляка картинки из коллекции generationElectricalImpulse (задержка анимации)
//
//    [11] - 2-я координата "x" кольца генерации электрического импульса
//    [12] - 2-я координата "y" кольца генерации электрического импульса
//    [13] - отработка   затухания импульса(1-не разрешено, 2-разрешено)
//    [14] - номер рисунка для отображения анимации затухания электрического импульса (для 2-го кольца) (от 0 до ?)
//    [15] - вспомогательный счетчик для анимации экземпляра картинки из коллекции generationElectricalImpulse (задержка анимации)
//
//    [16] - если отработка  генерации затухания импульса [13] - закончилась,то необходимо удалять этот (отработаный) путь из коллекции collectionOfCollectionsWayElectricalImpulseAnimationCoordinates ,куда он был ранее добавлен (1-не удалять ,2-удалять) (информация актуальна в коллекции collectionOfCollectionsWayElectricalImpulseAnimationCoordinates)
//    [17] - отработка анимации движения импульса (2-разрешена, 1-не разрешена)
//
//    [18] - начальная координата "x" пути
//    [19] - начальная координата "y" пути
//    [20] - 2-я координата 1-го отрезка пути координата "x"
//    [21] - 2-я координата 1-го отрезка пути координата "y"
//
//    [68] - количество пройденных отрезков анимации
//    [69] - количество отрезков в траектории движения импульса
//    [70] - остаток единиц скорости (для улучшения плавности анимации движения импульса)
//    [71] - информация о проведении расчетов координат в текущем шаге (0 -еще не проводился, 1 - уже проводился)
//    [72] - разрешение на пересчет позиции в текущем отрезке движения  (0-разрешено, 1- разрешено,пересчет,только с остатком единиц перемещения, 2- не разрешено )
//
//                              [73} - количество istance, находящихся в данный момент в коллекции данного импульса (в конце постройки должно соответствовать количеству istance в импульсе)

//    [74] - aIndex [20]
//    [75] - bIndex [21]

    ////////////////////////////////////////////////////

    private int timerSpeeWayForElectricalImpulse = 50;
    //  public boolean showOnAnimationWayForElectricalImpulse = false;    //разрешение на анимацию взрыва и стирания дорожек


    public BackgroundMatrix backgroundMatrix;                 //переменная для анимации backgroundMatrix

    long startTimeShowBackgroundForAnimationWithWindow = startTime + 372 * 1000;  //((372) - должно стоять в релизе)ключевая точка времени (изначально = ) //время задержки начала анимации бекграунда                          // 60 seconds * 1000 ms/sec;   //время окончания воспроизведения анимации
    private boolean showBackgroundForAnimationWithWindow = false;      //50 - связано со временем запуска анимации иерогилифов (в классе class Hieroglyphs - 16 строка   = то же значение  =+1)


    // private long startTimeShowElectricalImpulse = startTime + 53 * 1000;  //((372) - должно стоять в релизе)ключевая точка времени (изначально = ) //время задержки начала анимации бекграунда                          // 60 seconds * 1000 ms/sec;   //время окончания воспроизведения анимации
    private boolean impulseAnimationRestriction = false;    //ограничение анимации импульсов
    private int start_x = 731;
    private int start_y = 170;
    private int finish_x = 1043;
    private int finish_y = 620;


    private long generalFinishTimeShowElectricalImpulse = startTime + 587 * 1000;  //((372) - должно стоять в релизе)ключевая точка времени (изначально = ) //время задержки начала анимации бекграунда                          // 60 seconds * 1000 ms/sec;   //время окончания воспроизведения анимации
    private boolean startingGeneralFinishTimeShowElectricalImpulse = false;

    ////////////////////////////////////////////////////

    //constructor
    public ElectricalImpulse() throws IOException {
        backgroundForAnimation = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/backgroundForAnimation/2backgroundForAnimation.png"));

        backgroundForAnimationWithWindow = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/backgroundForAnimation/backgroundForAnimationWithWindow.png"));

        for (int i = 0; i <= 7; i++) {
            impulseCollection.add("gameResourse2/resourseImages/ImagesForScreenSaver/impulce/" + i + ".png");
        }

        impulsePicture = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/impulce/impulse.png"));
        //    impulseFinishPicture =


        for (int i = 0; i <= 6; i++) {
            impulseAttenuation.add("gameResourse2/resourseImages/ImagesForScreenSaver/impulse attenuation/" + i + ".png");
        }


//        try {
//            backgroundMatrix = new BackgroundMatrix();      //инициализация переменной electricalImpulse
//        } catch (IOException e) {
//            e.printStackTrace();
//        }

    }

    //functions
    public void update() {
        comparison_time();
        timerWayForElectricalImpulse.start();


        if (admissionToTheMainPart == false) {
            compilationNowWayArrayInitial();
        }

        if (admissionToTheMainPart == true) {
            compilationNowWayArray();
        }
    }

    //помощ для таймера (создание резервной копии после первого просчета координат)
    public void helpTimer1(int i) {

        wayDublikatCorrector = new int[76];
        for (int k = 0; k < wayDublikatCorrector.length; k++) {
            wayDublikatCorrector[k] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[k];
        }
    }

    //помощ для таймера (перезапись резервной копии)
    public void helpTimer2(int i) {

        for (int j = 0; j < wayDublikatCorrector.length; j++) {
            collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[j] = wayDublikatCorrector[j];
        }
    }

    Timer timerWayForElectricalImpulse = new Timer(timerSpeeWayForElectricalImpulse, new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            //код который нужно выполнить каждый интервал timerSpeed

            if (showOnElectricalImpulse == true) {

                //    collectionForAnimation = new ArrayList<>();

                for (int i = 0; i < collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.size(); i++) {

                    switch (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[1]) {
                        case 0:

                            collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[8] = 2;   //разрещение на отработку  генерации импульса 1-го кольца
                            break;

                        case 1:

                            if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[17] == 2) {

                                for (int j = 0; j < chainLengthWay; j++) {

                                    dataProcessingFotTimer(i, j);

                                    impulseComponentCoordinates = new int[2];
                                    impulseComponentCoordinates[0] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18];
                                    impulseComponentCoordinates[1] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19];

                                    collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).add(impulseComponentCoordinates);

                                    if (j == 0) {
                                        helpTimer1(i);
                                    }
                                }
                                helpTimer2(i);
                                break;
                            }
                            break;

                        case 2:

                            collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[17] = 1;     //завершить отрисовку движения импульса
                            collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[13] = 2;    //разрешить отработку генерации затухания импульса 2-го кольца

                            break;

                        default:

                            System.out.println("что-то пошло не так!!!");
                            break;
                    }
                }
            }
        }
    });


    public void dataProcessingFotTimer(int i, int j) {

        if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[17] == 2) {

            //движение вправо (прямая)
            if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] < collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74]] && collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] == collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75]]) {

                if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[71] == 0) {

                    //только пересчет оставшихся единиц перемещения
                    if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[72] == 1) {
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] + collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[70];
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[70] = 0;
                    }

                    if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[72] == 0) {
                        //пересчет позиции istance с учетом скорости перемещения
                        if (j == 0) {
                            collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] + (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[4] * 2);          //плюсуется значение скорости (если предусматривается движение импульса не по диагонали то нужно умножить на 2 движение )
                        }
                        //пересчет позиции istance с учетом шага между istance (stepBetweenInstancesInAImpulse)
                        if (j > 0) {
                            collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] + (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[5] * 2);          //плюсуется значение скорости (если предусматривается движение импульса не по диагонали то нужно умножить на 2 движение )
                        }
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[72] = 1;
                    }

                    //продолжаем находиться в пределах текущего отрезка
                    if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] < collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74]] && collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] == collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75]]) {
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[72] = 0;   //разрешить
                        return;
                    }

                    //переходим на следующий отрезок пути и записываем в get(i).get(0)[70] остатки единиц перемещения
                    if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] >= collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74]] && collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] == collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75]]) {
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[70] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] - collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74]];
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74]];

                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[68]++;
                        if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[68] == collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[69]) {
                            collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[1] = 2;
                            return;
                        }

                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74] + 2;
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75] + 2;

                        dataProcessingFotTimer(i, j);

                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[72] = 0;    //пересчет позиции для массива istance (для всего массива istance) закончен
                        return;
                    }
                }
            }

            //движение вниз (прямая)
            if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] == collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74]] && collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] < collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75]]) {

                if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[71] == 0) {

                    //только пересчет оставшихся единиц перемещения
                    if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[72] == 1) {
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] + collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[70];
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[70] = 0;
                    }

                    if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[72] == 0) {
                        //пересчет позиции istance с учетом скорости перемещения
                        if (j == 0) {
                            collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] + (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[4] * 2);          //плюсуется значение скорости (если предусматривается движение импульса не по диагонали то нужно умножить на 2 движение )
                        }
                        //пересчет позиции istance с учетом шага между istance (stepBetweenInstancesInAImpulse)
                        if (j > 0) {
                            collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] + (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[5] * 2);          //плюсуется значение скорости (если предусматривается движение импульса не по диагонали то нужно умножить на 2 движение )
                        }
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[72] = 1;
                    }

                    //продолжаем находиться в пределах текущего отрезка
                    if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] == collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74]] && collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] < collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75]]) {
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[72] = 0;
                        return;
                    }

                    //переходим на следующий отрезок пути и записываем в get(i).get(0)[70] остатки единиц перемещения
                    if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] == collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74]] && collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] >= collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75]]) {
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[70] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] - collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75]];
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75]];

                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[68]++;
                        if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[68] == collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[69]) {
                            collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[1] = 2;
                            return;
                        }

                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74] + 2;
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75] + 2;

                        dataProcessingFotTimer(i, j);

                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[72] = 0;    //пересчет позиции для массива istance (для всего массива istance) закончен
                        return;
                    }
                }
            }

            //движение влево (прямая)
            if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] > collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74]] && collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] == collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75]]) {

                if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[71] == 0) {
                    //только пересчет оставшихся единиц перемещения
                    if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[72] == 1) {
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] - collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[70];
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[70] = 0;
                    }

                    if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[72] == 0) {
                        //пересчет позиции istance с учетом скорости перемещения
                        if (j == 0) {
                            collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] - (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[4] * 2);          //плюсуется значение скорости (если предусматривается движение импульса не по диагонали то нужно умножить на 2 движение )
                        }
                        //пересчет позиции istance с учетом шага между istance (stepBetweenInstancesInAImpulse)
                        if (j > 0) {
                            collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] - (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[5] * 2);          //плюсуется значение скорости (если предусматривается движение импульса не по диагонали то нужно умножить на 2 движение )
                        }
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[72] = 1;
                    }

                    //продолжаем находиться в пределах текущего отрезка
                    if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] > collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74]] && collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] == collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75]]) {
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[72] = 0;
                        return;
                    }

                    //переходим на следующий отрезок пути и записываем в get(i).get(0)[70] остатки единиц перемещения
                    if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] <= collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74]] && collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] == collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75]]) {
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[70] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74]] - collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18];
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74]];

                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[68]++;
                        if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[68] == collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[69]) {
                            collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[1] = 2;
                            return;
                        }

                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74] + 2;
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75] + 2;

                        dataProcessingFotTimer(i, j);

                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[72] = 0;    //пересчет позиции для массива istance (для всего массива istance) закончен
                        return;
                    }
                }
            }

            //движение вверх (прямая)
            if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] == collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74]] && collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] > collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75]]) {

                if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[71] == 0) {

                    //только пересчет оставшихся единиц перемещения
                    if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[72] == 1) {
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] - collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[70];
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[70] = 0;
                    }

                    if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[72] == 0) {
                        //пересчет позиции istance с учетом скорости перемещения
                        if (j == 0) {
                            collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] - (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[4] * 2);          //плюсуется значение скорости (если предусматривается движение импульса не по диагонали то нужно умножить на 2 движение )
                        }
                        //пересчет позиции istance с учетом шага между istance (stepBetweenInstancesInAImpulse)
                        if (j > 0) {
                            collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] - (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[5] * 2);          //плюсуется значение скорости (если предусматривается движение импульса не по диагонали то нужно умножить на 2 движение )
                        }
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[72] = 1;
                    }

                    //продолжаем находиться в пределах текущего отрезка
                    if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] == collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74]] && collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] > collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75]]) {
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[72] = 0;
                        return;
                    }

                    //переходим на следующий отрезок пути и записываем в get(i).get(0)[70] остатки единиц перемещения
                    if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] == collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74]] && collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] <= collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75]]) {
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[70] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75]] - collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19];
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75]];

                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[68]++;
                        if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[68] == collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[69]) {
                            collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[1] = 2;
                            return;
                        }

                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74] + 2;
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75] + 2;

                        dataProcessingFotTimer(i, j);

                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[72] = 0;    //пересчет позиции для массива istance (для всего массива istance) закончен
                        return;
                    }
                }
            }

            //движение вниз вправо(диагональ)
            if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] < collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74]] && collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] < collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75]]) {

                if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[71] == 0) {

                    //только пересчет оставшихся единиц перемещения
                    if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[72] == 1) {
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] + collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[70];
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] + collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[70];          //плюсуется значение скорости (если предусматривается движение импульса не по диагонали то нужно умножить на 2 движение )
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[70] = 0;
                    }

                    if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[72] == 0) {
                        //пересчет позиции istance с учетом скорости перемещения
                        if (j == 0) {
                            collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] + (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[4]);          //плюсуется значение скорости (если предусматривается движение импульса не по диагонали то нужно умножить на 2 движение )
                            collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] + (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[4]);          //плюсуется значение скорости (если предусматривается движение импульса не по диагонали то нужно умножить на 2 движение )
                        }
                        //пересчет позиции istance с учетом шага между istance (stepBetweenInstancesInAImpulse)
                        if (j > 0) {
                            collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] + (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[5]);          //плюсуется значение скорости (если предусматривается движение импульса не по диагонали то нужно умножить на 2 движение )
                            collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] + (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[5]);          //плюсуется значение скорости (если предусматривается движение импульса не по диагонали то нужно умножить на 2 движение )
                        }
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[72] = 1;
                    }

                    //продолжаем находиться в пределах текущего отрезка
                    if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] < collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74]] && collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] < collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75]]) {
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[72] = 0;
                        return;
                    }

                    //переходим на следующий отрезок пути и записываем в get(i).get(0)[70] остатки единиц перемещения
                    if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] >= collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74]] && collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] >= collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75]]) {
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[70] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] - collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74]];
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74]];
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75]];

                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[68]++;
                        if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[68] == collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[69]) {
                            collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[1] = 2;
                            return;
                        }

                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74] + 2;
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75] + 2;

                        dataProcessingFotTimer(i, j);

                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[72] = 0;    //пересчет позиции для массива istance (для всего массива istance) закончен
                        return;
                    }
                }
            }

            //движение вниз влево(диагональ)
            if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] > collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74]] && collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] < collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75]]) {

                if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[71] == 0) {

                    //только пересчет оставшихся единиц перемещения
                    if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[72] == 1) {
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] - collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[70];
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] + collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[70];          //плюсуется значение скорости (если предусматривается движение импульса не по диагонали то нужно умножить на 2 движение )
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[70] = 0;
                    }

                    if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[72] == 0) {
                        //пересчет позиции istance с учетом скорости перемещения
                        if (j == 0) {
                            collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] - (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[4]);          //плюсуется значение скорости (если предусматривается движение импульса не по диагонали то нужно умножить на 2 движение )
                            collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] + (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[4]);          //плюсуется значение скорости (если предусматривается движение импульса не по диагонали то нужно умножить на 2 движение )
                        }
                        //пересчет позиции istance с учетом шага между istance (stepBetweenInstancesInAImpulse)
                        if (j > 0) {
                            collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] - (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[5]);          //плюсуется значение скорости (если предусматривается движение импульса не по диагонали то нужно умножить на 2 движение )
                            collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] + (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[5]);          //плюсуется значение скорости (если предусматривается движение импульса не по диагонали то нужно умножить на 2 движение )
                        }
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[72] = 1;
                    }

                    //продолжаем находиться в пределах текущего отрезка
                    if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] > collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74]] && collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] < collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75]]) {
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[72] = 0;
                        return;
                    }

                    //переходим на следующий отрезок пути и записываем в get(i).get(0)[70] остатки единиц перемещения
                    if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] <= collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74]] && collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] >= collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75]]) {
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[70] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74]] - collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18];
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74]];
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75]];

                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[68]++;
                        if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[68] == collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[69]) {
                            collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[1] = 2;
                            return;
                        }

                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74] + 2;
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75] + 2;

                        dataProcessingFotTimer(i, j);

                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[72] = 0;    //пересчет позиции для массива istance (для всего массива istance) закончен
                        return;
                    }
                }
            }

            //движение вверх вправо(диагональ)
            if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] < collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74]] && collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] > collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75]]) {

                if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[71] == 0) {

                    //только пересчет оставшихся единиц перемещения
                    if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[72] == 1) {
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] + collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[70];
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] - collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[70];          //плюсуется значение скорости (если предусматривается движение импульса не по диагонали то нужно умножить на 2 движение )
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[70] = 0;
                    }

                    if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[72] == 0) {
                        //пересчет позиции istance с учетом скорости перемещения
                        if (j == 0) {
                            collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] + (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[4]);          //плюсуется значение скорости (если предусматривается движение импульса не по диагонали то нужно умножить на 2 движение )
                            collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] - (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[4]);          //плюсуется значение скорости (если предусматривается движение импульса не по диагонали то нужно умножить на 2 движение )
                        }
                        //пересчет позиции istance с учетом шага между istance (stepBetweenInstancesInAImpulse)
                        if (j > 0) {
                            collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] + (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[5]);          //плюсуется значение скорости (если предусматривается движение импульса не по диагонали то нужно умножить на 2 движение )
                            collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] - (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[5]);          //плюсуется значение скорости (если предусматривается движение импульса не по диагонали то нужно умножить на 2 движение )
                        }
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[72] = 1;
                    }

                    //продолжаем находиться в пределах текущего отрезка
                    if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] < collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74]] && collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] > collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75]]) {
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[72] = 0;
                        return;
                    }

                    //переходим на следующий отрезок пути и записываем в get(i).get(0)[70] остатки единиц перемещения
                    if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] >= collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74]] && collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] <= collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75]]) {
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[70] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] - collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74]];
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74]];
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75]];

                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[68]++;
                        if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[68] == collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[69]) {
                            collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[1] = 2;
                            return;
                        }

                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74] + 2;
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75] + 2;

                        dataProcessingFotTimer(i, j);

                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[72] = 0;    //пересчет позиции для массива istance (для всего массива istance) закончен
                        return;
                    }
                }
            }

            //движение вверх влево(диагональ)
            if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] > collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74]] && collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] > collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75]]) {

                if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[71] == 0) {

                    //только пересчет оставшихся единиц перемещения
                    if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[72] == 1) {
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] - collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[70];
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] - collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[70];          //плюсуется значение скорости (если предусматривается движение импульса не по диагонали то нужно умножить на 2 движение )
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[70] = 0;
                        //        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[72] = 1;
                    }

                    if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[72] == 0) {
                        //пересчет позиции istance с учетом скорости перемещения
                        if (j == 0) {
                            collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] - (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[4]);          //плюсуется значение скорости (если предусматривается движение импульса не по диагонали то нужно умножить на 2 движение )
                            collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] - (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[4]);          //плюсуется значение скорости (если предусматривается движение импульса не по диагонали то нужно умножить на 2 движение )
                        }
                        //пересчет позиции istance с учетом шага между istance (stepBetweenInstancesInAImpulse)
                        if (j > 0) {
                            collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] - (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[5]);          //плюсуется значение скорости (если предусматривается движение импульса не по диагонали то нужно умножить на 2 движение )
                            collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] - (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[5]);          //плюсуется значение скорости (если предусматривается движение импульса не по диагонали то нужно умножить на 2 движение )
                        }
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[72] = 1;
                    }

                    //продолжаем находиться в пределах текущего отрезка
                    if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] > collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74]] && collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] > collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75]]) {
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[72] = 0;
                        return;
                    }

                    //переходим на следующий отрезок пути и записываем в get(i).get(0)[70] остатки единиц перемещения
                    if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] <= collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74]] && collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] <= collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75]]) {
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[70] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74]] - collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18];
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[18] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74]];
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[19] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75]];

                        //        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[1]++;
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[68]++;
                        if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[68] == collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[69]) {
                            collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[1] = 2;
                            return;
                        }

                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[74] + 2;
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75] = collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[75] + 2;

                        dataProcessingFotTimer(i, j);

                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[72] = 0;    //пересчет позиции для массива istance (для всего массива istance) закончен
                        return;
                    }
                }
            }
        }
    }


    //определение времени запуска анимации прописаном в классе ElectricalImpulse
    public void comparison_time() {
        if (System.currentTimeMillis() > startTimeShowElectricalImpulse) {               //проверка,если время,startTime = System.currentTimeMillis(); больше startTimeShowElectricalImpulse,то поменять false  на true (т.е. разрешить анимацию электроимпульсов)
            showOnElectricalImpulse = true;
        }
        if (System.currentTimeMillis() > startTimeShowBackgroundForAnimationWithWindow) {
            showBackgroundForAnimationWithWindow = true;
            impulseAnimationRestriction = true;
        }
        if (System.currentTimeMillis() > generalFinishTimeShowElectricalImpulse) {               //проверка,если время,startTime = System.currentTimeMillis(); больше startTimeShowElectricalImpulse,то поменять false  на true (т.е. разрешить анимацию электроимпульсов)
            startingGeneralFinishTimeShowElectricalImpulse = true;
        }
    }


    //начальный участок анимации эл.импульсов
    public void compilationNowWayArrayInitial() {

        for (int i = 0; i < collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.size(); i++) {

            if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[16] == 2) {
                collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.remove(i);
                numberWayAttachedToTheElectricalImpulseAnimationCollection--;
                //    admissionToTheMainPart2 = true;
                countAdmissionToTheMainPart++;

                System.out.println(countAdmissionToTheMainPart);

                if (countAdmissionToTheMainPart == 12) {
                    admissionToTheMainPart = true;
                }
            }
        }

        //    if (numberWayAttachedToTheElectricalImpulseAnimationCollection < allowableCollectionSize2) {
        if (numberWayAttachedToTheElectricalImpulseAnimationCollection < allowableCollectionSize2) {

            if (countAdmissionToTheMainPart == 1) {
                way = new int[]{49, 0, 4, 0, 1, 1, 1737, 169, 1, 0, 0, 703, 852, 1, 7, 0, 1, 1, 1750, 172, 1750, 158, 1723, 131, 1446, 131, 1395, 182, 1219, 182, 1186, 215, 1186, 667, 1151, 702, 1117, 702, 1084, 735, 1084, 775, 1119, 810, 1119, 886, 1091, 914, 1013, 914, 983, 944, 783, 944, 717, 878, 717, 877, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19, 0, 0, 0, 0, 20, 21,};

                way[4] = speedPointImpulse;
                way[5] = stepBetweenInstancesInAImpulse;    //шаг между экземплярами в импульсе

                collectionsWayElectricalImpulseAnimationCoordinates = new ArrayList<>();
                collectionsWayElectricalImpulseAnimationCoordinates.add(way);   //добавление в коллекцию данный way
                collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.add(collectionsWayElectricalImpulseAnimationCoordinates);
                numberWayAttachedToTheElectricalImpulseAnimationCollection++;
            }

            if (countAdmissionToTheMainPart == 2) {

                way = new int[]{46, 0, 4, 0, 1, 1, 728, 833, 1, 0, 0, 169, 173, 1, 7, 0, 1, 1, 741, 855, 741, 876, 791, 926, 975, 926, 1005, 896, 1083, 896, 1101, 878, 1101, 819, 1066, 784, 1066, 736, 1031, 701, 662, 701, 630, 669, 630, 354, 665, 319, 665, 192, 630, 157, 380, 157, 336, 113, 224, 113, 182, 155, 182, 176, 0, 0, 0, 0, 0, 0, 0, 21, 0, 0, 0, 0, 20, 21,};
                way[4] = speedPointImpulse;
                way[5] = stepBetweenInstancesInAImpulse;    //шаг между экземплярами в импульсе

                collectionsWayElectricalImpulseAnimationCoordinates = new ArrayList<>();
                collectionsWayElectricalImpulseAnimationCoordinates.add(way);   //добавление в коллекцию данный way
                collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.add(collectionsWayElectricalImpulseAnimationCoordinates);
                numberWayAttachedToTheElectricalImpulseAnimationCollection++;
            }

            if (countAdmissionToTheMainPart == 3) {

                for (int i = 0; i <= 8; i++) {
                    if (i == 0) {
                        way = new int[]{238, 0, 4, 0, 1, 1, 709, 155, 1, 0, 0, 1094, 225, 1, 7, 0, 1, 1, 716, 176, 687, 205, 687, 656, 700, 669, 851, 669, 858, 676, 928, 676, 935, 669, 1110, 669, 1123, 656, 1123, 255, 1113, 245, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 0, 0, 0, 0, 20, 21,};
                        way[4] = speedPointImpulse;
                        way[5] = stepBetweenInstancesInAImpulse;    //шаг между экземплярами в импульсе

                        collectionsWayElectricalImpulseAnimationCoordinates = new ArrayList<>();
                        collectionsWayElectricalImpulseAnimationCoordinates.add(way);   //добавление в коллекцию данный way
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.add(collectionsWayElectricalImpulseAnimationCoordinates);
                        numberWayAttachedToTheElectricalImpulseAnimationCollection++;

                    }
                    if (i == 1) {
                        way = new int[]{344, 0, 4, 0, 1, 1, 709, 155, 1, 0, 0, 1094, 374, 1, 7, 0, 1, 1, 716, 176, 687, 205, 687, 656, 700, 669, 851, 669, 858, 676, 928, 676, 935, 669, 1110, 669, 1123, 656, 1123, 404, 1113, 394, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 0, 0, 0, 0, 20, 21,};
                        way[4] = speedPointImpulse;
                        way[5] = stepBetweenInstancesInAImpulse;    //шаг между экземплярами в импульсе

                        collectionsWayElectricalImpulseAnimationCoordinates = new ArrayList<>();
                        collectionsWayElectricalImpulseAnimationCoordinates.add(way);   //добавление в коллекцию данный way
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.add(collectionsWayElectricalImpulseAnimationCoordinates);
                        numberWayAttachedToTheElectricalImpulseAnimationCollection++;
                    }
                    if (i == 2) {
                        way = new int[]{345, 0, 4, 0, 1, 1, 709, 155, 1, 0, 0, 1094, 537, 1, 7, 0, 1, 1, 716, 176, 687, 205, 687, 656, 700, 669, 851, 669, 858, 676, 928, 676, 935, 669, 1110, 669, 1123, 656, 1123, 567, 1113, 557, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 0, 0, 0, 0, 20, 21,};
                        way[4] = speedPointImpulse;
                        way[5] = stepBetweenInstancesInAImpulse;    //шаг между экземплярами в импульсе

                        collectionsWayElectricalImpulseAnimationCoordinates = new ArrayList<>();
                        collectionsWayElectricalImpulseAnimationCoordinates.add(way);   //добавление в коллекцию данный way
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.add(collectionsWayElectricalImpulseAnimationCoordinates);
                        numberWayAttachedToTheElectricalImpulseAnimationCollection++;
                    }
                    if (i == 3) {
                        way = new int[]{346, 0, 4, 0, 1, 1, 709, 155, 1, 0, 0, 1005, 633, 1, 7, 0, 1, 1, 716, 176, 687, 205, 687, 656, 700, 669, 851, 669, 858, 676, 928, 676, 935, 669, 997, 669, 1014, 652, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9, 0, 0, 0, 0, 20, 21,};
                        way[4] = speedPointImpulse;
                        way[5] = stepBetweenInstancesInAImpulse;    //шаг между экземплярами в импульсе

                        collectionsWayElectricalImpulseAnimationCoordinates = new ArrayList<>();
                        collectionsWayElectricalImpulseAnimationCoordinates.add(way);   //добавление в коллекцию данный way
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.add(collectionsWayElectricalImpulseAnimationCoordinates);
                        numberWayAttachedToTheElectricalImpulseAnimationCollection++;
                    }
                    if (i == 4) {
                        way = new int[]{347, 0, 4, 0, 1, 1, 709, 155, 1, 0, 0, 882, 633, 1, 7, 0, 1, 1, 716, 176, 687, 205, 687, 656, 700, 669, 851, 669, 858, 676, 867, 676, 891, 652, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 0, 0, 0, 20, 21,};
                        way[4] = speedPointImpulse;
                        way[5] = stepBetweenInstancesInAImpulse;    //шаг между экземплярами в импульсе

                        collectionsWayElectricalImpulseAnimationCoordinates = new ArrayList<>();
                        collectionsWayElectricalImpulseAnimationCoordinates.add(way);   //добавление в коллекцию данный way
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.add(collectionsWayElectricalImpulseAnimationCoordinates);
                        numberWayAttachedToTheElectricalImpulseAnimationCollection++;
                    }
                    if (i == 5) {
                        way = new int[]{348, 0, 4, 0, 1, 1, 709, 155, 1, 0, 0, 737, 633, 1, 7, 0, 1, 1, 716, 176, 687, 205, 687, 656, 700, 669, 729, 669, 746, 652, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 0, 20, 21,};
                        way[4] = speedPointImpulse;
                        way[5] = stepBetweenInstancesInAImpulse;    //шаг между экземплярами в импульсе

                        collectionsWayElectricalImpulseAnimationCoordinates = new ArrayList<>();
                        collectionsWayElectricalImpulseAnimationCoordinates.add(way);   //добавление в коллекцию данный way
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.add(collectionsWayElectricalImpulseAnimationCoordinates);
                        numberWayAttachedToTheElectricalImpulseAnimationCollection++;
                    }
                    if (i == 6) {
                        way = new int[]{349, 0, 4, 0, 1, 1, 709, 155, 1, 0, 0, 698, 499, 1, 7, 0, 1, 1, 716, 176, 687, 205, 687, 491, 705, 509, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 20, 21,};
                        way[4] = speedPointImpulse;
                        way[5] = stepBetweenInstancesInAImpulse;    //шаг между экземплярами в импульсе

                        collectionsWayElectricalImpulseAnimationCoordinates = new ArrayList<>();
                        collectionsWayElectricalImpulseAnimationCoordinates.add(way);   //добавление в коллекцию данный way
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.add(collectionsWayElectricalImpulseAnimationCoordinates);
                        numberWayAttachedToTheElectricalImpulseAnimationCollection++;
                    }
                    if (i == 7) {
                        way = new int[]{350, 0, 4, 0, 1, 1, 709, 155, 1, 0, 0, 696, 331, 1, 7, 0, 1, 1, 716, 176, 687, 205, 687, 324, 703, 340, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 20, 21,};
                        way[4] = speedPointImpulse;
                        way[5] = stepBetweenInstancesInAImpulse;    //шаг между экземплярами в импульсе

                        collectionsWayElectricalImpulseAnimationCoordinates = new ArrayList<>();
                        collectionsWayElectricalImpulseAnimationCoordinates.add(way);   //добавление в коллекцию данный way
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.add(collectionsWayElectricalImpulseAnimationCoordinates);
                        numberWayAttachedToTheElectricalImpulseAnimationCollection++;
                    }
                    if (i == 8) {
                        way = new int[]{351, 0, 4, 0, 1, 1, 709, 155, 1, 0, 0, 696, 221, 1, 7, 0, 1, 1, 716, 176, 687, 205, 687, 214, 704, 231, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 20, 21,};
                        way[4] = speedPointImpulse;
                        way[5] = stepBetweenInstancesInAImpulse;    //шаг между экземплярами в импульсе

                        collectionsWayElectricalImpulseAnimationCoordinates = new ArrayList<>();
                        collectionsWayElectricalImpulseAnimationCoordinates.add(way);   //добавление в коллекцию данный way
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.add(collectionsWayElectricalImpulseAnimationCoordinates);
                        numberWayAttachedToTheElectricalImpulseAnimationCollection++;
                        System.out.println(countAdmissionToTheMainPart);

                    }
                }
            }
        }
    }


    //построение коллекции учавствующих в анимации ElectricalImpulse в данное время(и проверка на пустоту или недостаточное колличество эллементов в коллекции)
    public void compilationNowWayArray() {

        int indexTrack1;
        int indexTrack2;
        int indexTrack3;
        int indexTrack4;

//прицепить множественные импульсы

        for (int i = 0; i < collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.size(); i++) {

            if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[16] == 2) {
                collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.remove(i);
                numberWayAttachedToTheElectricalImpulseAnimationCollection--;
            }
        }

        //если колличетсво way присоедененных к коллекции меньше допустимый размер коллекции (allowableCollectionSize) тогда ...
        if (numberWayAttachedToTheElectricalImpulseAnimationCollection < allowableCollectionSize) {

            boolean resolution = false;

            do {

                if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.size() == 0) {    //если коллекция пустая то...

                    numberClassTrack = (int) (1 + (Math.random() * 4));

                    if (numberClassTrack == 1) {
                        Track1 track1 = new Track1();
                        collectionsWayElectricalImpulseAnimationCoordinates = new ArrayList<>();
                        int numberWay1 = (int) (1 + (Math.random() * 54));       //вторая цифра соответствует количеству дорожек,находящихся в данном классе Track
                        indexTrack1 = numberWay1 - 1;
                        int countWay = 0;

                        way = new int[track1.arrayCoordinatesWayForElectricalImpulse[indexTrack1].length];

                        //перезаписывание данных из массива collectionRegistrationTrack, находящихся в ячейке под номером numberClassTrack
                        for (int i = 0; i < way.length; i++) {
                            way[i] = track1.arrayCoordinatesWayForElectricalImpulse[indexTrack1][i];
                        }

                        way[4] = speedPointImpulse;
                        way[5] = stepBetweenInstancesInAImpulse;    //шаг между экземплярами в импульсе

                        collectionsWayElectricalImpulseAnimationCoordinates.add(way);   //добавление в коллекцию данный way
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.add(collectionsWayElectricalImpulseAnimationCoordinates);
                        numberWayAttachedToTheElectricalImpulseAnimationCollection++;


                        if (indexTrack1 == 0 || indexTrack1 == 1 || indexTrack1 == 2 || indexTrack1 == 3 || indexTrack1 == 4) {

                            if (indexTrack1 == 0) {
                                countWay = 26;
                                indexTrack1 = 54;       //на 1 меньше ,чем индекс обозначеный в 0-й ячейке
                            }

                            if (indexTrack1 == 1) {
                                countWay = 10;
                                indexTrack1 = 81;
                            }

                            if (indexTrack1 == 2) {
                                countWay = 9;
                                indexTrack1 = 92;
                            }

                            if (indexTrack1 == 3) {
                                countWay = 7;
                                indexTrack1 = 102;
                            }

                            if (indexTrack1 == 4) {
                                countWay = 6;
                                indexTrack1 = 110;
                            }

                            for (int i = 0; i <= countWay; i++) {

                                way = new int[track1.arrayCoordinatesWayForElectricalImpulse[indexTrack1].length];
                                collectionsWayElectricalImpulseAnimationCoordinates = new ArrayList<>();
                                //перезаписывание данных из массива collectionRegistrationTrack, находящихся в ячейке под номером numberClassTrack
                                for (int j = 0; j < way.length; j++) {
                                    way[j] = track1.arrayCoordinatesWayForElectricalImpulse[indexTrack1][j];
                                }

                                way[4] = speedPointImpulse;
                                way[5] = stepBetweenInstancesInAImpulse;    //шаг между экземплярами в импульсе

                                collectionsWayElectricalImpulseAnimationCoordinates.add(way);   //добавление в коллекцию данный way
                                collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.add(collectionsWayElectricalImpulseAnimationCoordinates);
                                numberWayAttachedToTheElectricalImpulseAnimationCollection++;

                                indexTrack1++;
                            }
                        }
                    }

                    if (numberClassTrack == 2) {

                        Track2 track2 = new Track2();
                        collectionsWayElectricalImpulseAnimationCoordinates = new ArrayList<>();
                        int numberWay2 = (int) (118 + (Math.random() * 35));       //вторая цифра соответствует количеству дорожек,находящихся в данном классе Track
                        indexTrack2 = numberWay2 - 118;
                        int countWay = 0;

                        way = new int[track2.arrayCoordinatesWayForElectricalImpulse[indexTrack2].length];

                        //перезаписывание данных из массива collectionRegistrationTrack, находящихся в ячейке под номером numberClassTrack
                        for (int i = 0; i < way.length; i++) {
                            way[i] = track2.arrayCoordinatesWayForElectricalImpulse[indexTrack2][i];
                        }

                        way[4] = speedPointImpulse;
                        way[5] = stepBetweenInstancesInAImpulse;    //шаг между экземплярами в импульсе

                        collectionsWayElectricalImpulseAnimationCoordinates.add(way);   //добавление в коллекцию данный way
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.add(collectionsWayElectricalImpulseAnimationCoordinates);
                        numberWayAttachedToTheElectricalImpulseAnimationCollection++;

                        if (indexTrack2 == 0 || indexTrack2 == 1 || indexTrack2 == 2 || indexTrack2 == 3 || indexTrack2 == 4) {

                            if (indexTrack2 == 0) {
                                countWay = 56;
                                indexTrack2 = 35;
                            }

                            if (indexTrack2 == 1) {
                                countWay = 9;
                                indexTrack2 = 92;
                            }

                            if (indexTrack2 == 2) {
                                countWay = 5;
                                indexTrack2 = 102;
                            }

                            if (indexTrack2 == 3) {
                                countWay = 3;
                                indexTrack2 = 108;
                            }

                            if (indexTrack2 == 4) {
                                countWay = 3;
                                indexTrack2 = 112;
                            }


                            for (int i = 0; i <= countWay; i++) {

                                way = new int[track2.arrayCoordinatesWayForElectricalImpulse[indexTrack2].length];
                                collectionsWayElectricalImpulseAnimationCoordinates = new ArrayList<>();
                                //перезаписывание данных из массива collectionRegistrationTrack, находящихся в ячейке под номером numberClassTrack
                                for (int j = 0; j < way.length; j++) {
                                    way[j] = track2.arrayCoordinatesWayForElectricalImpulse[indexTrack2][j];
                                }

                                way[4] = speedPointImpulse;
                                way[5] = stepBetweenInstancesInAImpulse;    //шаг между экземплярами в импульсе

                                collectionsWayElectricalImpulseAnimationCoordinates.add(way);   //добавление в коллекцию данный way
                                collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.add(collectionsWayElectricalImpulseAnimationCoordinates);
                                numberWayAttachedToTheElectricalImpulseAnimationCollection++;

                                indexTrack2++;
                            }
                        }
                    }
                    if (numberClassTrack == 3) {

                        Track3 track3 = new Track3();
                        collectionsWayElectricalImpulseAnimationCoordinates = new ArrayList<>();
                        int numberWay3 = (int) (234 + (Math.random() * 61));       //вторая цифра соответствует количеству дорожек,находящихся в данном классе Track
                        indexTrack3 = numberWay3 - 234;
                        int countWay = 0;

                        way = new int[track3.arrayCoordinatesWayForElectricalImpulse[indexTrack3].length];

                        //перезаписывание данных из массива collectionRegistrationTrack, находящихся в ячейке под номером numberClassTrack
                        for (int i = 0; i < way.length; i++) {
                            way[i] = track3.arrayCoordinatesWayForElectricalImpulse[indexTrack3][i];
                        }

                        way[4] = speedPointImpulse;
                        way[5] = stepBetweenInstancesInAImpulse;    //шаг между экземплярами в импульсе

                        collectionsWayElectricalImpulseAnimationCoordinates.add(way);   //добавление в коллекцию данный way
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.add(collectionsWayElectricalImpulseAnimationCoordinates);
                        numberWayAttachedToTheElectricalImpulseAnimationCollection++;

                        if (indexTrack3 == 0 || indexTrack3 == 1 || indexTrack3 == 2 || indexTrack3 == 3 || indexTrack3 == 4) {

                            if (indexTrack3 == 0) {
                                countWay = 23;
                                indexTrack3 = 61;
                            }

                            if (indexTrack3 == 1) {
                                countWay = 9;
                                indexTrack3 = 85;
                            }

                            if (indexTrack3 == 2) {
                                countWay = 7;
                                indexTrack3 = 95;
                            }

                            if (indexTrack3 == 3) {
                                countWay = 6;
                                indexTrack3 = 103;
                            }

                            if (indexTrack3 == 4) {
                                countWay = 7;
                                indexTrack3 = 110;
                            }

                            for (int i = 0; i <= countWay; i++) {

                                way = new int[track3.arrayCoordinatesWayForElectricalImpulse[indexTrack3].length];
                                collectionsWayElectricalImpulseAnimationCoordinates = new ArrayList<>();
                                //перезаписывание данных из массива collectionRegistrationTrack, находящихся в ячейке под номером numberClassTrack
                                for (int j = 0; j < way.length; j++) {
                                    way[j] = track3.arrayCoordinatesWayForElectricalImpulse[indexTrack3][j];
                                }

                                way[4] = speedPointImpulse;
                                way[5] = stepBetweenInstancesInAImpulse;    //шаг между экземплярами в импульсе

                                collectionsWayElectricalImpulseAnimationCoordinates.add(way);   //добавление в коллекцию данный way
                                collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.add(collectionsWayElectricalImpulseAnimationCoordinates);
                                numberWayAttachedToTheElectricalImpulseAnimationCollection++;

                                indexTrack3++;
                            }
                        }

                    }
                    if (numberClassTrack == 4) {

                        Track4 track4 = new Track4();
                        collectionsWayElectricalImpulseAnimationCoordinates = new ArrayList<>();
                        int numberWay4 = (int) (352 + (Math.random() * 66));       //вторая цифра соответствует количеству дорожек,находящихся в данном классе Track
                        indexTrack4 = numberWay4 - 352;
                        int countWay = 0;

                        way = new int[track4.arrayCoordinatesWayForElectricalImpulse[indexTrack4].length];
                        //перезаписывание данных из массива collectionRegistrationTrack, находящихся в ячейке под номером numberClassTrack

                        for (int i = 0; i < way.length; i++) {
                            way[i] = track4.arrayCoordinatesWayForElectricalImpulse[indexTrack4][i];
                        }

                        way[4] = speedPointImpulse;
                        way[5] = stepBetweenInstancesInAImpulse;    //шаг между экземплярами в импульсе

                        collectionsWayElectricalImpulseAnimationCoordinates.add(way);   //добавление в коллекцию данный way
                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.add(collectionsWayElectricalImpulseAnimationCoordinates);
                        numberWayAttachedToTheElectricalImpulseAnimationCollection++;

                        if (indexTrack4 == 0 || indexTrack4 == 1 || indexTrack4 == 2 || indexTrack4 == 3 || indexTrack4 == 4) {

                            if (indexTrack4 == 0) {
                                countWay = 23;
                                indexTrack4 = 67;
                            }

                            if (indexTrack4 == 1) {
                                countWay = 9;
                                indexTrack4 = 91;
                            }

                            if (indexTrack4 == 2) {
                                countWay = 7;
                                indexTrack4 = 101;
                            }

                            if (indexTrack4 == 3) {
                                countWay = 6;
                                indexTrack4 = 109;
                            }

                            if (indexTrack4 == 4) {
                                countWay = 3;
                                indexTrack4 = 116;
                            }


                            for (int i = 0; i <= countWay; i++) {

                                way = new int[track4.arrayCoordinatesWayForElectricalImpulse[indexTrack4].length];
                                collectionsWayElectricalImpulseAnimationCoordinates = new ArrayList<>();
                                //перезаписывание данных из массива collectionRegistrationTrack, находящихся в ячейке под номером numberClassTrack
                                for (int j = 0; j < way.length; j++) {
                                    way[j] = track4.arrayCoordinatesWayForElectricalImpulse[indexTrack4][j];
                                }

                                way[4] = speedPointImpulse;
                                way[5] = stepBetweenInstancesInAImpulse;    //шаг между экземплярами в импульсе

                                collectionsWayElectricalImpulseAnimationCoordinates.add(way);   //добавление в коллекцию данный way
                                collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.add(collectionsWayElectricalImpulseAnimationCoordinates);
                                numberWayAttachedToTheElectricalImpulseAnimationCollection++;

                                indexTrack4++;
                            }
                        }
                    }
                }

                //проверка на уже существующий сценарий в коллекции
                if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.size() > 0) {
                    do {
                        numberClassTrack = (int) (1 + (Math.random() * 4));

                        if (numberClassTrack == 1) {

                            Track1 track1 = new Track1();
                            collectionsWayElectricalImpulseAnimationCoordinates = new ArrayList<>();
                            int numberWay1 = (int) (1 + (Math.random() * 54));    //вторая цифра соответствует количеству дорожек,находящихся в данном классе Track
                            indexTrack1 = numberWay1 - 1;
                            int countWay = 0;

                            way = new int[track1.arrayCoordinatesWayForElectricalImpulse[indexTrack1].length];
                            boolean resolution1 = true;

                            for (int i = 0; i < collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.size(); i++) {
                                if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[0] == track1.arrayCoordinatesWayForElectricalImpulse[indexTrack1][0]) {
                                    //эсли значение collectionRegistrationTrack.get(i)[0] совпадет с track1.arrayCoordinatesWayForElectricalImpulse[numberClassTrack][0]
                                    //значит экзепляр с таким номером уже присутствует в collectionOfCollectionsWayElectricalImpulseAnimationCoordinates
                                    //значит его нельзя снова добавлять в коллекцию,по этому назначаем false

                                    resolution1 = false;
                                }
                            }
                            if (resolution1 == true) {

                                for (int i = 0; i < way.length; i++) {
                                    way[i] = track1.arrayCoordinatesWayForElectricalImpulse[indexTrack1][i];
                                }

                                way[4] = speedPointImpulse;
                                way[5] = stepBetweenInstancesInAImpulse;    //шаг между экземплярами в импульсе


                                collectionsWayElectricalImpulseAnimationCoordinates.add(way);   //добавление в коллекцию данный way
                                collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.add(collectionsWayElectricalImpulseAnimationCoordinates);
                                numberWayAttachedToTheElectricalImpulseAnimationCollection++;

                                resolution = true;

                                if (indexTrack1 == 0 || indexTrack1 == 1 || indexTrack1 == 2 || indexTrack1 == 3 || indexTrack1 == 4) {

                                    if (indexTrack1 == 0) {
                                        countWay = 26;
                                        indexTrack1 = 54;       //на 1 меньше ,чем индекс обозначеный в 0-й ячейке
                                    }

                                    if (indexTrack1 == 1) {
                                        countWay = 10;
                                        indexTrack1 = 81;
                                    }

                                    if (indexTrack1 == 2) {
                                        countWay = 9;
                                        indexTrack1 = 92;
                                    }

                                    if (indexTrack1 == 3) {
                                        countWay = 7;
                                        indexTrack1 = 102;
                                    }

                                    if (indexTrack1 == 4) {
                                        countWay = 6;
                                        indexTrack1 = 110;
                                    }

                                    for (int i = 1; i <= countWay; i++) {

                                        way = new int[track1.arrayCoordinatesWayForElectricalImpulse[indexTrack1].length];
                                        collectionsWayElectricalImpulseAnimationCoordinates = new ArrayList<>();
                                        //перезаписывание данных из массива collectionRegistrationTrack, находящихся в ячейке под номером numberClassTrack
                                        for (int j = 0; j < way.length; j++) {
                                            way[j] = track1.arrayCoordinatesWayForElectricalImpulse[indexTrack1][j];
                                        }

                                        way[4] = speedPointImpulse;
                                        way[5] = stepBetweenInstancesInAImpulse;    //шаг между экземплярами в импульсе

                                        collectionsWayElectricalImpulseAnimationCoordinates.add(way);   //добавление в коллекцию данный way
                                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.add(collectionsWayElectricalImpulseAnimationCoordinates);
                                        numberWayAttachedToTheElectricalImpulseAnimationCollection++;

                                        indexTrack1++;
                                    }
                                }
                            }
                        }

                        if (numberClassTrack == 2) {

                            Track2 track2 = new Track2();
                            collectionsWayElectricalImpulseAnimationCoordinates = new ArrayList<>();
                            int numberWay2 = (int) (118 + (Math.random() * 35));       //вторая цифра соответствует количеству дорожек,находящихся в данном классе Track
                            indexTrack2 = numberWay2 - 118;
                            int countWay = 0;

                            way = new int[track2.arrayCoordinatesWayForElectricalImpulse[indexTrack2].length];
                            boolean resolution2 = true;

                            for (int i = 0; i < collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.size(); i++) {
                                if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[0] == track2.arrayCoordinatesWayForElectricalImpulse[indexTrack2][0]) {
                                    //эсли значение collectionRegistrationTrack.get(i)[0] совпадет с track1.arrayCoordinatesWayForElectricalImpulse[numberClassTrack][0]
                                    //значит экзепляр с таким номером уже присутствует в collectionOfCollectionsWayElectricalImpulseAnimationCoordinates
                                    //значит его нельзя снова добавлять в коллекцию,по этому назначаем false

                                    resolution2 = false;
                                }
                            }

                            if (resolution2 == true) {

                                //перезаписывание данных из массива collectionRegistrationTrack, находящихся в ячейке под номером numberClassTrack
                                for (int i = 0; i < way.length; i++) {
                                    way[i] = track2.arrayCoordinatesWayForElectricalImpulse[indexTrack2][i];
                                }

                                way[4] = speedPointImpulse;
                                way[5] = stepBetweenInstancesInAImpulse;    //шаг между экземплярами в импульсе


                                collectionsWayElectricalImpulseAnimationCoordinates.add(way);   //добавление в коллекцию данный way
                                collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.add(collectionsWayElectricalImpulseAnimationCoordinates);
                                numberWayAttachedToTheElectricalImpulseAnimationCollection++;

                                resolution = true;

                                if (indexTrack2 == 0 || indexTrack2 == 1 || indexTrack2 == 2 || indexTrack2 == 3 || indexTrack2 == 4) {

                                    if (indexTrack2 == 0) {
                                        countWay = 56;
                                        indexTrack2 = 35;
                                    }

                                    if (indexTrack2 == 1) {
                                        countWay = 9;
                                        indexTrack2 = 92;
                                    }

                                    if (indexTrack2 == 2) {
                                        countWay = 5;
                                        indexTrack2 = 102;
                                    }

                                    if (indexTrack2 == 3) {
                                        countWay = 3;
                                        indexTrack2 = 108;
                                    }

                                    if (indexTrack2 == 4) {
                                        countWay = 3;
                                        indexTrack2 = 112;
                                    }

                                    for (int i = 0; i <= countWay; i++) {

                                        way = new int[track2.arrayCoordinatesWayForElectricalImpulse[indexTrack2].length];
                                        collectionsWayElectricalImpulseAnimationCoordinates = new ArrayList<>();
                                        //перезаписывание данных из массива collectionRegistrationTrack, находящихся в ячейке под номером numberClassTrack
                                        for (int j = 0; j < way.length; j++) {
                                            way[j] = track2.arrayCoordinatesWayForElectricalImpulse[indexTrack2][j];
                                        }

                                        way[4] = speedPointImpulse;
                                        way[5] = stepBetweenInstancesInAImpulse;    //шаг между экземплярами в импульсе

                                        collectionsWayElectricalImpulseAnimationCoordinates.add(way);   //добавление в коллекцию данный way
                                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.add(collectionsWayElectricalImpulseAnimationCoordinates);
                                        numberWayAttachedToTheElectricalImpulseAnimationCollection++;

                                        indexTrack2++;
                                    }
                                }
                            }
                        }
                        if (numberClassTrack == 3) {

                            Track3 track3 = new Track3();
                            collectionsWayElectricalImpulseAnimationCoordinates = new ArrayList<>();
                            int numberWay3 = (int) (234 + (Math.random() * 61));       //вторая цифра соответствует количеству дорожек,находящихся в данном классе Track

                            indexTrack3 = numberWay3 - 234;
                            int countWay = 0;

                            way = new int[track3.arrayCoordinatesWayForElectricalImpulse[indexTrack3].length];
                            boolean resolution3 = true;

                            for (int i = 0; i < collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.size(); i++) {
                                if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[0] == track3.arrayCoordinatesWayForElectricalImpulse[indexTrack3][0]) {
                                    //эсли значение collectionRegistrationTrack.get(i)[0] совпадет с track1.arrayCoordinatesWayForElectricalImpulse[numberClassTrack][0]
                                    //значит экзепляр с таким номером уже присутствует в collectionOfCollectionsWayElectricalImpulseAnimationCoordinates
                                    //значит его нельзя снова добавлять в коллекцию,по этому назначаем false

                                    resolution3 = false;
                                }
                            }

                            if (resolution3 == true) {

                                //перезаписывание данных из массива collectionRegistrationTrack, находящихся в ячейке под номером numberClassTrack
                                for (int i = 0; i < way.length; i++) {
                                    way[i] = track3.arrayCoordinatesWayForElectricalImpulse[indexTrack3][i];
                                }

                                way[4] = speedPointImpulse;
                                way[5] = stepBetweenInstancesInAImpulse;    //шаг между экземплярами в импульсе

                                collectionsWayElectricalImpulseAnimationCoordinates.add(way);   //добавление в коллекцию данный way
                                collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.add(collectionsWayElectricalImpulseAnimationCoordinates);
                                numberWayAttachedToTheElectricalImpulseAnimationCollection++;

                                resolution = true;

                                if (indexTrack3 == 0 || indexTrack3 == 1 || indexTrack3 == 2 || indexTrack3 == 3 || indexTrack3 == 4) {

                                    if (indexTrack3 == 0) {
                                        countWay = 23;
                                        indexTrack3 = 61;
                                    }

                                    if (indexTrack3 == 1) {
                                        countWay = 9;
                                        indexTrack3 = 85;
                                    }

                                    if (indexTrack3 == 2) {
                                        countWay = 7;
                                        indexTrack3 = 95;
                                    }

                                    if (indexTrack3 == 3) {
                                        countWay = 6;
                                        indexTrack3 = 103;
                                    }

                                    if (indexTrack3 == 4) {
                                        countWay = 7;
                                        indexTrack3 = 110;
                                    }

                                    for (int i = 0; i <= countWay; i++) {

                                        way = new int[track3.arrayCoordinatesWayForElectricalImpulse[indexTrack3].length];
                                        collectionsWayElectricalImpulseAnimationCoordinates = new ArrayList<>();
                                        //перезаписывание данных из массива collectionRegistrationTrack, находящихся в ячейке под номером numberClassTrack
                                        for (int j = 0; j < way.length; j++) {
                                            way[j] = track3.arrayCoordinatesWayForElectricalImpulse[indexTrack3][j];
                                        }

                                        way[4] = speedPointImpulse;
                                        way[5] = stepBetweenInstancesInAImpulse;    //шаг между экземплярами в импульсе

                                        collectionsWayElectricalImpulseAnimationCoordinates.add(way);   //добавление в коллекцию данный way
                                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.add(collectionsWayElectricalImpulseAnimationCoordinates);
                                        numberWayAttachedToTheElectricalImpulseAnimationCollection++;

                                        indexTrack3++;
                                    }
                                }
                            }
                        }
                        if (numberClassTrack == 4) {

                            Track4 track4 = new Track4();
                            collectionsWayElectricalImpulseAnimationCoordinates = new ArrayList<>();
                            int numberWay4 = (int) (352 + (Math.random() * 66));       //вторая цифра соответствует количеству дорожек,находящихся в данном классе Track
                            indexTrack4 = numberWay4 - 352;
                            int countWay = 0;

                            way = new int[track4.arrayCoordinatesWayForElectricalImpulse[indexTrack4].length];
                            boolean resolution4 = true;

                            for (int i = 0; i < collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.size(); i++) {
                                if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[0] == track4.arrayCoordinatesWayForElectricalImpulse[indexTrack4][0]) {
                                    //эсли значение collectionRegistrationTrack.get(i)[0] совпадет с track1.arrayCoordinatesWayForElectricalImpulse[numberClassTrack][0]
                                    //значит экзепляр с таким номером уже присутствует в collectionOfCollectionsWayElectricalImpulseAnimationCoordinates
                                    //значит его нельзя снова добавлять в коллекцию,по этому назначаем false

                                    resolution4 = false;
                                }
                            }
                            if (resolution4 == true) {

                                //перезаписывание данных из массива collectionRegistrationTrack, находящихся в ячейке под номером numberClassTrack
                                for (int i = 0; i < way.length; i++) {
                                    way[i] = track4.arrayCoordinatesWayForElectricalImpulse[indexTrack4][i];

                                }
                                way[4] = speedPointImpulse;
                                way[5] = stepBetweenInstancesInAImpulse;    //шаг между экземплярами в импульсе

                                collectionsWayElectricalImpulseAnimationCoordinates.add(way);   //добавление в коллекцию данный way
                                collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.add(collectionsWayElectricalImpulseAnimationCoordinates);
                                numberWayAttachedToTheElectricalImpulseAnimationCollection++;

                                resolution = true;

                                if (indexTrack4 == 0 || indexTrack4 == 1 || indexTrack4 == 2 || indexTrack4 == 3 || indexTrack4 == 4) {

                                    if (indexTrack4 == 0) {
                                        countWay = 23;
                                        indexTrack4 = 67;
                                    }

                                    if (indexTrack4 == 1) {
                                        countWay = 9;
                                        indexTrack4 = 91;
                                    }

                                    if (indexTrack4 == 2) {
                                        countWay = 7;
                                        indexTrack4 = 101;
                                    }

                                    if (indexTrack4 == 3) {
                                        countWay = 6;
                                        indexTrack4 = 109;
                                    }

                                    if (indexTrack4 == 4) {
                                        countWay = 3;
                                        indexTrack4 = 116;
                                    }

                                    for (int i = 0; i <= countWay; i++) {

                                        way = new int[track4.arrayCoordinatesWayForElectricalImpulse[indexTrack4].length];
                                        collectionsWayElectricalImpulseAnimationCoordinates = new ArrayList<>();
                                        //перезаписывание данных из массива collectionRegistrationTrack, находящихся в ячейке под номером numberClassTrack
                                        for (int j = 0; j < way.length; j++) {
                                            way[j] = track4.arrayCoordinatesWayForElectricalImpulse[indexTrack4][j];
                                        }

                                        way[4] = speedPointImpulse;
                                        way[5] = stepBetweenInstancesInAImpulse;    //шаг между экземплярами в импульсе

                                        collectionsWayElectricalImpulseAnimationCoordinates.add(way);   //добавление в коллекцию данный way
                                        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.add(collectionsWayElectricalImpulseAnimationCoordinates);
                                        numberWayAttachedToTheElectricalImpulseAnimationCollection++;

                                        indexTrack4++;
                                    }
                                }
                            }
                        }
                    }
                    while (resolution == false);
                }
            }
            while (resolution == false);
        }

    }

    //анимация генерации импульса (возвращает значение-номер,который будет присвоен impulseInstance,для анимации генерации ElectricalImpulse )
    public void animationGenerationImpulse(int i) {
//то же что и в методе animationImpulse(int i),только поменять индексы ячеек (когда будут котовы рисунки генерации)

        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[10]++;
        if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[10] == 2) {
            collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[10] = -1;

            collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[9]++;
            if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[9] >= 7) {
                //    countEraserInstance = 0;

                collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[9] = 0;    //т.к. генерация импульса уже произошла,то отображать уже ничего не нужно (0-пустая картинка)
                collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[17] = 2;   //разрешить анимацию импулса на way
                collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[1]++;      //преход к следующему case в timerWayForElectricalImpulse
                collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[8] = 1;    //прекратить анимацию генерации импульса
            }
        }
    }


    //анимация импульса(смена картинки) (возвращает значение-номер,который будет присвоен impulseInstance,для анимации ElectricalImpulse )
    public void animationImpulse(int i) {

        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[2] = 4;

        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[3]++;
        if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[3] == 4) {
            collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[3] = -1;

            collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[2]++;
            if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[2] >= 7) {
                //    countEraserInstance = 0;

                collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[2] = 4;
            }
        }
    }


    //анимация затухания импульса (возвращает значение-номер,который будет присвоен impulseInstance,для анимации затухания ElectricalImpulse )
    public void animationAttenuationImpulse(int i) {
//то же что и в методе animationImpulse(int i),только поменять индексы ячеек (когда будут котовы рисунки затухания)

        collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[15]++;
        if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[15] == 1) {
            collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[15] = -1;

            collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[14]--;
            if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[14] <= 0) {

                collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[14] = 0;    //т.к. генерация импульса уже произошла,то отображать уже ничего не нужно (0-пустая картинка)
                collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[13] = 1;   //прекратить анимацию затухания импульса

                collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[16] = 2;
            }
        }
    }


    public void draw(Graphics2D g) {
        if (startingGeneralFinishTimeShowElectricalImpulse == false) {

            if (showOnElectricalImpulse == true) {

                if (showBackgroundForAnimationWithWindow == false) {
                    g.drawImage(backgroundForAnimation, 0, 0, null);
                }

                if (showBackgroundForAnimationWithWindow == true) {
                    g.drawImage(backgroundForAnimationWithWindow, 0, 0, null);
                }
            }

//        if(backgroundMatrix.showAnimationBackgroundAssemblyBlue == true){
//            g.drawImage(backgroundForAnimationWithWindow, 0, 0, null);
//
//        }

            for (int i = 0; i < collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.size(); i++) {


                if (impulseAnimationRestriction == false) {

//            //генерация импульса
                    if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[8] == 2) {
                        animationGenerationImpulse(i);
                        impulseInstance = impulseCollection.get(collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[9]);

                        g.drawImage(new ImageIcon(impulseInstance).getImage(), collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[6] + axisCorrection_x, collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[7] + axisCorrection_y, null);
                    }


                    //анимация импульса на пути (way)
                    if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[17] == 2) {

                        for (int k = 1; k < collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).size(); k++) {
                            g.drawImage(new ImageIcon(impulsePicture).getImage(), collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(k)[0] - 9, collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(k)[1] - 5, null);
                        }

                        //  удаление экземпляров istance после анимации
                        for (int j = 1; j < collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).size(); j++) {
                            collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).remove(j);
                        }
                    }

                    //затухание импульса
                    if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[13] == 2) {
                        animationAttenuationImpulse(i);
                        impulseInstance = impulseAttenuation.get(collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[14]);

                        g.drawImage(new ImageIcon(impulseInstance).getImage(), collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[11] + axisCorrection_x, collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[12] + axisCorrection_y, null);
                    }
                }


                if (impulseAnimationRestriction == true) {

                    //            //генерация импульса
                    if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[8] == 2) {
                        animationGenerationImpulse(i);
                        impulseInstance = impulseCollection.get(collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[9]);

                        if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[6] + axisCorrection_x < start_x || collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[6] + axisCorrection_x > finish_x || collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[7] + axisCorrection_y < start_y || collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[7] + axisCorrection_y > finish_y) {
                            g.drawImage(new ImageIcon(impulseInstance).getImage(), collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[6] + axisCorrection_x, collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[7] + axisCorrection_y, null);
                        }
                    }

                    //анимация импульса на пути (way)
                    if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[17] == 2) {

                        for (int k = 1; k < collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).size(); k++) {

                            if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(k)[0] - 9 < start_x || collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(k)[0] - 9 > finish_x || collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(k)[1] - 5 < start_y || collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(k)[1] - 5 > finish_y) {
                                g.drawImage(new ImageIcon(impulsePicture).getImage(), collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(k)[0] - 9, collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(k)[1] - 5, null);
                            }
                        }

                        //  удаление экземпляров istance после анимации
                        for (int j = 1; j < collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).size(); j++) {
                            collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).remove(j);
                        }
                    }

                    //затухание импульса
                    if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[13] == 2) {
                        animationAttenuationImpulse(i);
                        impulseInstance = impulseAttenuation.get(collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[14]);

                        if (collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[11] + axisCorrection_x < start_x || collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[11] + axisCorrection_x > finish_x || collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[12] + axisCorrection_y < start_y || collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[12] + axisCorrection_y > finish_y) {
                            g.drawImage(new ImageIcon(impulseInstance).getImage(), collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[11] + axisCorrection_x, collectionOfCollectionsWayElectricalImpulseAnimationCoordinates.get(i).get(0)[12] + axisCorrection_y, null);
                        }
                    }
                }
            }
        }
    }
}
