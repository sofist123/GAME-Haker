package gameExample_6_____reliz__3;

import gameExample_6_____reliz__3.ObjectsForTheFinalAnimation.*;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

/**
 * Created by sofis on 28.05.2019.
 */
public class GamePanelScreenSaver extends JPanel implements Runnable {

    //fields (поляЯ,переменные)
    // задаём размер панели
//    public static int WIDTH = 1024;
//    public static int HEIGHT = 680;
    static Dimension sSize = Toolkit.getDefaultToolkit().getScreenSize();     //определяем размер созданого окна сопоставимого с размером экрана
    public static int WIDTH = sSize.width;
    public static int HEIGHT = sSize.height - 85;
    private Thread thread; // Создаем поток- ссылка на обьект класса Thread
    private BufferedImage image;   //переменная холста
    private Graphics2D g;   //кисточка,которой мы рисуем

    private int FPS;
    private double millisToFPS;
    private long timerFPS;
    private int sleepTime;     //какое время будет спать

    private GameBackgroundScreenSaver backgroundScreenSaver;    //переменная бекграунда заставки
    private GameTime gameTimeDate;                              //переменная для анимации времени
    private Honeycomb honeycomb;                                 //переменная для анимации honeycomb (соты)
    private Honeycomb2 honeycomb2;                               //переменная для анимации honeycomb2 (соты анимации текста и анимации графиков)
    private TrackСleaning trackBuilding;                        //переменная для анимации trackBuilding
    private BackgroundAnimation backgroundAnimation;            //переменная для анимации backgroundAnimation
    private ElectricalImpulse electricalImpulse;                 //переменная для анимации electricalImpulse

    private ConnectionStatusBackground connectionStatusBackground;   //переменная для анимации ConnectionStatusBackground
    private BackgroundMatrix backgroundMatrix;                  //переменная для анимации BackgroundMatrix

    private Hieroglyphs hieroglyphs;                   //переменная для анимации Hieroglyphs

    private Server server;   //переменная для анимации Server
    private PC pc;           //переменная для анимации PC

    private IpAddressEndKeyboard ipAddressEndKeyboard;   //переменная для анимации IpAddressEndKeyboard

    private ServerRevitalization serverRevitalization;   //переменная для анимации ServerRevitalization

    private GeneralFinishAnimation generalFinishAnimation;   //переменная для анимации GeneralFinishAnimation

    private GeneralFinishAnimationMenu generalFinishAnimationMenu;  ////переменная для анимации GeneralFinishAnimationMenu

    //   private GamePC pc;                   //переменная изображения "pc"
    //   private GameServer server;                   //переменная изображения "server"

    //   private GameConnectionStatus backgrountConnectionStatus;    //переменная изображения "backgrountConnectionStatus"
    //    private GameConnectionStatusScreenSaver connectionStatus;              //переменная изображения "connectionStatus"
//    private GameConnectionStatusScreenSaver progressBar;                   //переменная изображения "progressBar"
////
//    private GameConnectionStatusScreenSaver connectionStatusEstablished;    //переменная изображения "connectionStatusEstablished"
//    private MovingPoints point;       // движущущаяся точка
//    private MatrixAnimation matrix;       // матрица


    //constructor
    public GamePanelScreenSaver() {
        super();
        setPreferredSize(new Dimension(WIDTH, HEIGHT));
        setFocusable(true);
        requestFocus();
    }

    //functions
    @Override
    public void run() {
        FPS = 30;
        millisToFPS = 1000 / FPS;
        sleepTime = 0;

        image = new BufferedImage(WIDTH, HEIGHT, BufferedImage.TYPE_INT_RGB);   //инициализация холста,на котором рисуем
        g = (Graphics2D) image.getGraphics();   //привязываем кисточку к нашему холсту
        try {
            backgroundScreenSaver = new GameBackgroundScreenSaver();      //инициализация переменной background
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            gameTimeDate = new GameTime();      //инициализация переменной gameTimeDate
        } catch (IOException e) {
            e.printStackTrace();
        }


        try {
            honeycomb = new Honeycomb();      //инициализация переменной honeycomb
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            honeycomb2 = new Honeycomb2();      //инициализация переменной honeycomb2
        } catch (IOException e) {
            e.printStackTrace();
        }

        //trackBuilding

        try {
            trackBuilding = new TrackСleaning();      //инициализация переменной trackBuilding
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            backgroundAnimation = new BackgroundAnimation();      //инициализация переменной backgroundAnimation
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            electricalImpulse = new ElectricalImpulse();      //инициализация переменной electricalImpulse
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            connectionStatusBackground = new ConnectionStatusBackground();      //инициализация переменной connectionStatusBackground
        } catch (IOException e) {
            e.printStackTrace();
        }


        try {
            backgroundMatrix = new BackgroundMatrix();   //инициализация переменной backgroundMatrix

        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            hieroglyphs = new Hieroglyphs();   //инициализация переменной hieroglyphs

        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            server = new Server();   //инициализация переменной server

        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            pc = new PC();   //инициализация переменной pc

        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            ipAddressEndKeyboard = new IpAddressEndKeyboard();   //инициализация переменной pc

        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            serverRevitalization = new ServerRevitalization();   //инициализация переменной pc

        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            generalFinishAnimation = new GeneralFinishAnimation();   //инициализация переменной pc

        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            generalFinishAnimationMenu = new GeneralFinishAnimationMenu();   //инициализация переменной pc

        } catch (IOException e) {
            e.printStackTrace();
        }




        while (true) {
            timerFPS = System.nanoTime();

            try {
                gameUpdate();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            try {
                gameRender();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            gameDraw();

            timerFPS = (System.nanoTime() - timerFPS) / 1000000;
            if (millisToFPS > timerFPS) {
                sleepTime = (int) (millisToFPS - timerFPS);
            } else sleepTime = 1;
            try {
                thread.sleep(sleepTime);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            timerFPS = 0;
            sleepTime = 1;
        }

    }

    // запуск потока
    public void start() {
        thread = new Thread((Runnable) this);
        thread.start();// запускаем поток
    }

    //update всех обьектов в игре (обновление)
    public void gameUpdate() throws IOException, InterruptedException {
        backgroundScreenSaver.update();                      //обновление изменений в background    (разкоментировать в релизе)

        //////////////    gameTimeDate.update();                           //обновление изменений в gameTimeDate

           honeycomb.update();                             //обновление изменений в honeycomb          (разкоментировать в релизе)
        honeycomb2.update();                             //обновление изменений в honeycomb2         (разкоментировать в релизе)
        trackBuilding.update();                           //обновление изменений в trackBuilding       (разкоментировать в релизе)

        backgroundAnimation.update();                   //обновление изменений в backgroundAnimation


        hieroglyphs.update();               //обновление изменений в hieroglyphs

        electricalImpulse.update();                    //обновление изменений в electricalImpulse

        connectionStatusBackground.update();           //обновление изменений в connectionStatusBackground

        backgroundMatrix.update();               //обновление изменений в backgroundMatrix

        server.update();                       //обновление изменений в server

        pc.update();                       //обновление изменений в pc

        ipAddressEndKeyboard.update();             //обновление изменений в ipAddressEndKeyboard

        serverRevitalization.update();    //обновление изменений в serverRevitalization

        gameTimeDate.update();                           //обновление изменений в gameTimeDate

        generalFinishAnimation.update();            //обновление изменений в generalFinishAnimation

        generalFinishAnimationMenu.update();        //обновление изменений в generalFinishAnimationMenu

    //    gameTimeDate.update();                           //обновление изменений в gameTimeDate


    }

    //обновление графической составляющей в игре
    public void gameRender() throws IOException, InterruptedException {
        backgroundScreenSaver.draw(g);                      //рисуем background   (разкоментировать в релизе)

        ///////////    gameTimeDate.draw(g);                            //рисуем gameTimeDate

        honeycomb.draw(g);                               //рисуем honeycomb         (разкоментировать в релизе)
        honeycomb2.draw(g);                               //рисуем honeycomb2      (разкоментировать в релизе)
        trackBuilding.draw(g);                            //рисуем trackBuilding     (разкоментировать в релизе)

        backgroundAnimation.draw(g);                     //рисуем backgroundAnimation


                hieroglyphs.draw(g);                         //рисуем hieroglyphs

                electricalImpulse.draw(g);                       //рисуем electricalImpulse


               connectionStatusBackground.draw(g);             //рисуем connectionStatusBackground

               backgroundMatrix.draw(g);                      //рисуем backgroundMatrix

               server.draw(g);                          //рисуем server

                 pc.draw(g);                          //рисуем pc

        ipAddressEndKeyboard.draw(g);                //рисуем ipAddressEndKeyboard

        serverRevitalization.draw(g);                 //рисуем serverRevitalization

        gameTimeDate.draw(g);                            //рисуем gameTimeDate

        generalFinishAnimation.draw(g);             //рисуем generalFinishAnimation

        generalFinishAnimationMenu.draw(g);       //рисуем generalFinishAnimationMenu

    //    gameTimeDate.draw(g);                            //рисуем gameTimeDate


    }

    //присоединение кисточки и холста к экрану (выведение на экран)
    private void gameDraw() {
        Graphics g2 = this.getGraphics();
        g2.drawImage(image, 0, 0, null);
        g2.dispose();       //сообщение для сборщика мусора убрать переменную g2(картинку),т.к. она уже нарисована
    }
}
