package gameExample_6_____reliz__3.ObjectsForTheFinalAnimation;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Created by sofis on 27.06.2020.
 */
public class PC {
    private Image pc;
    private Image a2;
    private int a3 = 50;
    private int a4 = 0;
    private int a5 = 900;
    long a6 = System.currentTimeMillis();                            long a7 = a6 + 390 * 1000;      private boolean a8 = false;
    private int a9 = 0;
    private int[][] a10 = {
            {0, 335, 283, 335, 283,},
            {0, 335, 283, 335, 283,},
            {0, 335, 283, 335, 283,},
            {0, 335, 283, 335, 283,},
            {0, 335, 283, 335, 283,},
            {0, 335, 283, 335, 283,},

    };
    private int a11 = 225;
    private int a12 = 445;
    private int a13 = 220;
    private int a14 = 225;
    private int a15 = 364;
    private int a16 = 139;
    private boolean a17 = false;
    private int a18 = 50;
    private int a20 = 0;
    private int[] a21 = {0, 0, 0};
    int r = 0;
    int q = 0;
    int b = 0;
    ArrayList<String> a22 = new ArrayList<>();
    private String a23;
    private int a24 = 0;
    private int a25 = 0;
    private boolean a26 = false;
    ArrayList<String> a27 = new ArrayList<>();
    private String a29;
    private int a30 = 0;
    private int a31 = -1;
    private int a32 = 0;
    private boolean a33 = false;
    ArrayList<String> a34 = new ArrayList<>();
    private String a35;
    private int a36 = 0;
    private int a37 = -1;
    private int a39 = 0;
    ArrayList<String> a40 = new ArrayList<>();       private String a41;        private int a42 = 0;         private int a43 = -1;       private int a44 = 0;
    long a56 = a6 + 590 * 1000;      private boolean a58 = false;

    public PC() throws IOException {
        pc = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/pc/2pc.png"));
        a2 = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/pc/2screenPcOff.png"));
        for (int i = 1; i <= 21; i++) {
            a22.add("gameResourse2/resourseImages/ImagesForScreenSaver/pc/2screenTransparency/" + i + ".png");
        }
        for (int i = 0; i <= 5; i++) {
            a27.add("gameResourse2/resourseImages/ImagesForScreenSaver/pc/2OffOnButtonPC/" + i + ".png");
        }
        for (int i = 0; i <= 1; i++) {
            a34.add("gameResourse2/resourseImages/ImagesForScreenSaver/pc/2lightBulb/" + i + ".png");
        }
        for (int i = 1; i <= 3; i++) {
            a40.add("gameResourse2/resourseImages/ImagesForScreenSaver/pc/2mouseTransparency/" + i + ".png");
        }
    }

    Timer a59 = new Timer(a18, new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            switch (a20) {
                case 0:
                    a20++;
                    break;
                case 1:
                    for (int i = 0; i < a10.length; i++) {
                        if (a10[i][1] < a10[i][3] && a10[i][2] == a10[i][4]) {
                            a10[i][1] = a10[i][1] + 1;
                            if (a10[i][1] == a10[i][3]) {
                                a60(1, i);
                            }
                        }
                        if (a10[i][1] == a10[i][3] && a10[i][2] < a10[i][4]) {
                            a10[i][2] = a10[i][2] + 1;
                            if (a10[i][2] == a10[i][4]) {
                                a60(2, i);
                            }
                        }
                        if (a10[i][1] > a10[i][3] && a10[i][2] == a10[i][4]) {
                            a10[i][1] = a10[i][1] - 1;
                            if (a10[i][1] == a10[i][3]) {
                                a60(1, i);
                            }
                        }
                        if (a10[i][1] == a10[i][3] && a10[i][2] > a10[i][4]) {
                            a10[i][2] = a10[i][2] - 1;
                            if (a10[i][2] == a10[i][4]) {
                                a60(2, i);
                            }
                        }
                        if (a10[i][1] < a10[i][3] && a10[i][2] < a10[i][4]) {
                            a10[i][1] = a10[i][1] + 1;
                            a10[i][2] = a10[i][2] + 1;
                            if (a10[i][1] == a10[i][3] && a10[i][2] == a10[i][4]) {
                                a60(3, i);
                            }
                        }
                        if (a10[i][1] > a10[i][3] && a10[i][2] < a10[i][4]) {
                            a10[i][1] = a10[i][1] - 1;
                            a10[i][2] = a10[i][2] + 1;
                            if (a10[i][1] == a10[i][3] && a10[i][2] == a10[i][4]) {
                                a60(3, i);
                            }
                        }
                        if (a10[i][1] < a10[i][3] && a10[i][2] > a10[i][4]) {
                            a10[i][1] = a10[i][1] + 1;
                            a10[i][2] = a10[i][2] - 1;
                            if (a10[i][1] == a10[i][3] && a10[i][2] == a10[i][4]) {
                                a60(3, i);
                            }
                        }
                        if (a10[i][1] > a10[i][3] && a10[i][2] > a10[i][4]) {
                            a10[i][1] = a10[i][1] - 1;
                            a10[i][2] = a10[i][2] - 1;
                            if (a10[i][1] == a10[i][3] && a10[i][2] == a10[i][4]) {
                                a60(3, i);
                            }
                        }
                        if (a10[i][1] == a10[i][3] && a10[i][2] == a10[i][4]) {
                            a60(3, i);
                        }
                    }
                    break;
                case 2:
                    break;
                default:
                    System.out.println("!");
                    break;
            }
        }
    });


    Timer a63 = new Timer(a3, new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            switch (a4) {
                case 0:
                    a5 = a5 - 10;
                    if (a5 == 0) {
                        a4++;
                    }
                    break;
                case 1:
                    a5 = a5 + 10;
                    if (a5 >= 200) {
                        a4++;
                    }
                    break;
                case 2:
                    a5 = a5 - 10;
                    if (a5 <= 0) {
                        a4++;
                    }
                    break;
                case 3:
                    a5 = a5 + 10;
                    if (a5 >= 150) {
                        a4++;
                    }
                    break;
                case 4:
                    a5 = a5 - 10;
                    if (a5 <= 0) {
                        a4++;
                    }
                    break;
                case 5:
                    a5 = a5 + 10;
                    if (a5 >= 70) {
                        a4++;
                    }
                    break;
                case 6:
                    a5 = a5 - 10;
                    if (a5 <= 0) {
                        a4++;
                    }
                    break;
                case 7:
                    a5 = a5 + 10;
                    if (a5 >= 40) {
                        a4++;
                    }
                    break;
                case 8:
                    a5 = a5 - 10;
                    if (a5 <= 0) {
                        a4++;
                    }
                    break;
                case 9:
                    a63.stop();
                    a26 = true;
                    a33 = true;
                    break;
                default:
                    System.out.println("!");
            }
        }
    });

    public void update() {
        a65();
    }

    public void a65() {
        if (System.currentTimeMillis() > a7) {
            a9++;
            if (a9 == 1) {
                a8 = true;
                a63.start();
            }
            if (a17 == true) {
                a59.start();
            }
        }
        if (System.currentTimeMillis() > a56) {
            a58 = true;
        }
    }

    public void a60(int countSwitch, int i) {
        switch (countSwitch) {
            case 1:
                a10[i][3] = (int) (a11 + (Math.random() * a13));
                a10[i][4] = (int) (a14 + (Math.random() * a16));
                break;
            case 2:
                a10[i][3] = (int) (a11 + (Math.random() * a13));
                a10[i][4] = (int) (a14 + (Math.random() * a16));
                break;
            case 3:
                a10[i][3] = (int) (a11 + (Math.random() * a13));
                a10[i][4] = (int) (a14 + (Math.random() * a16));
                break;
        }
    }

    public void a67() {
        if (r == a21[0] && q == a21[1] && b == a21[2]) {
            r = (int) (0 + (Math.random() * 224));
            q = (int) (0 + (Math.random() * 224));
            b = (int) (0 + (Math.random() * 224));
        }
        if (r != a21[0] || q != a21[1] || b != a21[2]) {
            if (r > a21[0]) {
                a21[0]++;
                return;
            }
            if (r < a21[0]) {
                a21[0]--;
                return;
            }
            if (q > a21[1]) {
                a21[1]++;
                return;
            }
            if (q < a21[1]) {
                a21[1]--;
                return;
            }
            if (b > a21[2]) {
                a21[2]++;
                return;
            }
            if (b < a21[2]) {
                a21[2]--;
                return;
            }
        }
    }

    public void a69() {
        if (a24 == a22.size() - 1) {
            a26 = false;
            a17 = true;
            a8 = false;
            return;
        }
        a25++;
        if (a25 == 2) {
            a24++;
            a25 = 0;
        }
    }

    public void a70() {
        a31++;
        if (a31 == a32) {
            a32 = (int) (1 + (Math.random() * 3));
            a31 = 0;
            a30 = (int) (2 + (Math.random() * 4));
        }
    }

    public void a71() {
        a37++;
        if (a37 == a39) {
            a39 = (int) (1 + (Math.random() * 4));
            a37 = 0;
            a36 = (int) (0 + (Math.random() * 2));
        }
    }

    public void a72() {
        a43++;
        if (a43 == a44) {
            a44 = (int) (1 + (Math.random() * 3));
            a43 = 0;
            a42 = (int) (0 + (Math.random() * 3));
        }
    }

    public void draw(Graphics2D g) {
        if (a58 == false) {
            if (a8 == true) {
                g.drawImage(a2, 0, a5, null);
            }
            if (a26 == true) {
                g.drawImage(pc, 0, a5, null);
                a69();
                a23 = a22.get(a24);
                g.drawImage(new ImageIcon(a23).getImage(), 0, 0, null);
            }
            if (a17 == true) {
                g.drawImage(pc, 0, a5, null);
                a67();
                Color colorLineTriangl = new Color(a21[0], a21[1], a21[2]);
                g.setColor(colorLineTriangl);
                g.setStroke(new BasicStroke(2));
                g.drawLine(a10[0][1], a10[0][2], a10[1][1], a10[1][2]);
                g.drawLine(a10[0][1], a10[0][2], a10[2][1], a10[2][2]);
                g.drawLine(a10[0][1], a10[0][2], a10[3][1], a10[3][2]);
                g.drawLine(a10[0][1], a10[0][2], a10[4][1], a10[4][2]);
                g.drawLine(a10[0][1], a10[0][2], a10[5][1], a10[5][2]);
                g.drawLine(a10[1][1], a10[1][2], a10[2][1], a10[2][2]);
                g.drawLine(a10[1][1], a10[1][2], a10[3][1], a10[3][2]);
                g.drawLine(a10[1][1], a10[1][2], a10[4][1], a10[4][2]);
                g.drawLine(a10[1][1], a10[1][2], a10[5][1], a10[5][2]);
                g.drawLine(a10[2][1], a10[2][2], a10[3][1], a10[3][2]);
                g.drawLine(a10[2][1], a10[2][2], a10[4][1], a10[4][2]);
                g.drawLine(a10[2][1], a10[2][2], a10[5][1], a10[5][2]);
                g.drawLine(a10[3][1], a10[3][2], a10[4][1], a10[4][2]);
                g.drawLine(a10[3][1], a10[3][2], a10[5][1], a10[5][2]);
                g.drawLine(a10[4][1], a10[4][2], a10[5][1], a10[5][2]);
            }
            if (a33 == true) {
                a70();
                a29 = a27.get(a30);
                g.drawImage(new ImageIcon(a29).getImage(), 0, 0, null);
                a71();
                a35 = a34.get(a36);
                g.drawImage(new ImageIcon(a35).getImage(), 0, 0, null);
                a72();
                a41 = a40.get(a42);
                g.drawImage(new ImageIcon(a41).getImage(), 0, 0, null);
            }
        }
    }
}
