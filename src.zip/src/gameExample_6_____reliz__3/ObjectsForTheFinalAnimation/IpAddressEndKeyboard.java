package gameExample_6_____reliz__3.ObjectsForTheFinalAnimation;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Created by sofis on 29.06.2020.
 */
public class IpAddressEndKeyboard {
    long a1 = System.currentTimeMillis();
    long a2 = a1 + 452 * 1000;
    private boolean a3 = false;
    private Image ipPCBackground;
    private int a5 = 50;
    private int a6 = 0;
    private int a7 = -700;
    private int a8 = 330;
    private Image a9;
    private int a10 = 50;
    private int a11 = 0;
    private int a12 = 700;
    private int a13 = 40;
    ArrayList<String> a14 = new ArrayList<>();
    private String a15;
    private int a16 = 0;
    private int a17 = -55;
    private boolean a18 = false;
    private int a19 = 0;
    private Image keyboard;
    private boolean a21 = false;
    ArrayList<String> a22 = new ArrayList<>();
    private boolean a23 = false;
    private boolean a24 = false;
    private int a25 = 0;
    private String a26;
    private String a28 = "123";
    private String a29 = "204";
    private String a30 = "760";
    private String a31 = "789";
    private int a32 = 0;
    ArrayList<Integer> a33 = new ArrayList<>();
    private boolean a34 = true;
    private String a35;
    private int a36 = 0;
    private int a37 = 1;
    private int a39 = 0;
    private boolean a40 = false;
    private boolean a41 = false;
    private int a42 = 0;
    private String a44;
    private String a45 = "305";
    private String a46 = "583";
    private String a47 = "408";
    private String a49 = "749";
    private int a50 = 0;
    ArrayList<Integer> a51 = new ArrayList<>();
    private boolean a52 = true;
    private int a57 = 1;
    private int a58 = 0;
    private int a59 = 0;
    long a60 = a1 + 590 * 1000;
    private boolean a61 = false;

    public IpAddressEndKeyboard() throws IOException {
        ipPCBackground = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/ipAddress/ipPCBackground.png"));
        a9 = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/ipAddress/ipServerBackground.png"));
        for (int i = 1; i <= 79; i++) {
            a14.add("gameResourse2/resourseImages/ImagesForScreenSaver/keyboard/transparencyKeyboard/" + i + ".png");
        }
        keyboard = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/keyboard/transparencyKeyboard/79.png"));
        for (int i = 0; i <= 13; i++) {
            a22.add("gameResourse2/resourseImages/ImagesForScreenSaver/keyboard/pressKeyboardGreen/" + i + ".png");
        }
    }

    Timer a66 = new Timer(a5, new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            switch (a6) {
                case 0:
                    a7 = a7 + 5;
                    if (a7 == 60) {
                        a6++;
                    }
                    break;
                case 1:
                    a7 = a7 - 5;
                    if (a7 == -60) {
                        a6++;
                    }
                    break;
                case 2:
                    a7 = a7 + 5;
                    if (a7 == 30) {
                        a6++;
                    }
                    break;
                case 3:
                    a7 = a7 - 3;
                    if (a7 == -30) {
                        a6++;
                    }
                    break;
                case 4:
                    a7 = a7 + 3;
                    if (a7 == 0) {
                        a6++;
                    }
                    break;
                case 5:
                    a8 = a8 - 4;
                    if (a8 <= -14) {
                        a6++;
                    }
                    break;
                case 6:
                    a8 = a8 + 2;
                    if (a8 == 20) {
                        a6++;
                    }
                    break;
                case 7:
                    a8 = a8 - 2;
                    if (a8 == -10) {
                        a6++;
                    }
                    break;
                case 8:
                    a8 = a8 + 1;
                    if (a8 == 10) {
                        a6++;
                    }
                    break;
                case 9:
                    a8 = a8 - 1;
                    if (a8 == 0) {
                        a6++;
                    }
                    break;
                case 10:
                    a66.stop();
                    break;
                default:
                    System.out.println("!");
            }
        }
    });

    Timer a67 = new Timer(a10, new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            switch (a11) {
                case 0:
                    a12 = a12 - 5;
                    if (a12 == -60) {
                        a11++;
                    }
                    break;
                case 1:
                    a12 = a12 + 5;
                    if (a12 == 60) {
                        a11++;
                    }
                    break;
                case 2:
                    a12 = a12 - 5;
                    if (a12 == -30) {
                        a11++;
                    }
                    break;
                case 3:
                    a12 = a12 + 3;
                    if (a12 == 30) {
                        a11++;
                    }
                    break;
                case 4:
                    a12 = a12 - 3;
                    if (a12 == 0) {
                        a11++;
                    }
                    break;
                case 5:
                    a13 = a13 - 2;
                    if (a13 == -14) {
                        a11++;
                    }
                    break;
                case 6:
                    a13 = a13 + 2;
                    if (a13 == 20) {
                        a11++;
                    }
                    break;
                case 7:
                    a13 = a13 - 2;
                    if (a13 == -10) {
                        a11++;
                    }
                    break;
                case 8:
                    a13 = a13 + 1;
                    if (a13 == 10) {
                        a11++;
                    }
                    break;
                case 9:
                    a13 = a13 - 1;
                    if (a13 == 0) {
                        a11++;
                    }
                    break;
                case 10:
                    a67.stop();
                    a19++;
                    if (a19 == 1) {
                        a18 = true;
                    }
                    break;
                default:
                    System.out.println("!");
            }
        }
    });


    public void update() {
        if (System.currentTimeMillis() > a2) {
            a66.start();
            a67.start();
            a3 = true;
        }
        if (System.currentTimeMillis() > a60) {
            a61 = true;
        }
    }

    public void a77() {
        if (a16 == a14.size() - 1) {
            a18 = false;
            a21 = true;
            a24 = true;
            return;
        }
        a17++;
        if (a17 == 1) {
            a16++;
            a17 = 0;
        }
    }

    public String a78() {
        int a79 = (int) (100 + (Math.random() * 899));
        a26 = String.valueOf(a79);
        return a26;
    }

    public void a80() {
        switch (a25) {
            case 0:
                a28 = a78();
                a29 = a78();
                a30 = a78();
                a31 = a78();
                break;
            case 1:
                a28 = "123";
                a29 = a78();
                a30 = a78();
                a31 = a78();
                break;
            case 2:
                a28 = "123";
                a29 = "204";
                a30 = a78();
                a31 = a78();
                break;
            case 3:
                a28 = "123";
                a29 = "204";
                a30 = "760";
                a31 = a78();
                break;
            case 4:
                a28 = "123";
                a29 = "204";
                a30 = "760";
                a31 = "789";
                if (a34 == true) {
                    a33 = new ArrayList<>();
                    a81(a28);
                    a81("10");
                    a81(a29);
                    a81("10");
                    a81(a30);
                    a81("10");
                    a81(a31);
                    a81("11");
                    a81("13");
                    a34 = false;
                }
                break;
        }
    }

    public void a84() {
        switch (a42) {
            case 0:
                a45 = a78();
                a46 = a78();
                a47 = a78();
                a49 = a78();
                break;
            case 1:
                a45 = "305";
                a46 = a78();
                a47 = a78();
                a49 = a78();
                break;
            case 2:
                a45 = "305";
                a46 = "583";
                a47 = a78();
                a49 = a78();
                break;
            case 3:
                a45 = "305";
                a46 = "583";
                a47 = "408";
                a49 = a78();
                break;
            case 4:
                a45 = "305";
                a46 = "583";
                a47 = "408";
                a49 = "749";
                if (a52 == true) {
                    a51 = new ArrayList<>();
                    a88(a45);
                    a88("10");
                    a88(a46);
                    a88("10");
                    a88(a47);
                    a88("10");
                    a88(a49);
                    a88("11");
                    a88("12");
                    a88("13");
                    a88("12");
                    a88("13");
                    a88("12");
                    a88("13");
                    a52 = false;
                }
                break;
        }

    }

    public void a81(String str) {
        int x = Integer.parseInt(str);
        if (x >= 100) {
            int b = x / 100;
            int c = x % 100 / 10;
            int d = x % 10;
            a33.add(b);
            a33.add(c);
            a33.add(d);
        }
        if (x == 10) {
            a33.add(10);
        }
        if (x == 11) {
            a33.add(11);
        }
        if (x == 12) {
            a33.add(12);
        }
        if (x == 13) {
            a33.add(13);
        }
    }

    public void a88(String str) {

        int x = Integer.parseInt(str);
        if (x >= 100) {
            int b = x / 100;
            int c = x % 100 / 10;
            int d = x % 10;
            a51.add(b);
            a51.add(c);
            a51.add(d);
        }
        if (x == 10) {
            a51.add(10);
        }
        if (x == 11) {
            a51.add(11);
        }
        if (x == 12) {
            a51.add(12);
        }
        if (x == 13) {
            a51.add(13);
        }
    }

    public void a90() {
        if (a25 == 4) {
            return;
        }
        a32++;
        if (a32 == 48) {
            a32 = 0;
            a25++;
        }
    }

    public void a91() {
        if (a42 == 4) {
            return;
        }
        a50++;
        if (a50 == 48) {
            a50 = 0;
            a42++;
        }
    }

    public void a92() {
        if (a39 == a33.size() - 1) {
            a36 = 13;
            a41 = true;
            return;
        }
        a37++;
        if (a37 == 5) {
            a39++;
            a36 = a33.get(a39);
            a37 = 0;
        }
    }

    public void a93() {
        if (a59 == a51.size() - 1) {
            a58 = 13;
            return;
        }
        a57++;
        if (a57 == 6) {
            a59++;
            a58 = a51.get(a59);
            a57 = 0;
        }
    }


    public void draw(Graphics2D g) {
        if (a61 == false) {
            Color color1 = new Color(0, 150, 255);
            g.setColor(color1);
            Color color2 = new Color(38, 178, 81);
            Font myFont = new Font(null, Font.BOLD, 30);
            g.setFont(myFont);
            if (a3 == true) {
                g.drawImage(ipPCBackground, a7, a8, null);
                g.drawImage(a9, a12, a13, null);
            }
            if (a18 == true) {
                a77();
                a15 = a14.get(a16);
                g.drawImage(new ImageIcon(a15).getImage(), -127, 36, null);
            }
            if (a21 == true) {
                g.drawImage(keyboard, -127, 36, null);
            }
            if (a24 == true) {
                a90();
                a80();
                switch (a25) {
                    case 0:
                        g.setColor(color1);
                        g.drawString(a28, 267, 603);
                        g.drawString("." + a29, 320, 603);
                        g.drawString("." + a30, 380, 603);
                        g.drawString("." + a31, 440, 603);
                        break;
                    case 1:
                        g.setColor(color2);
                        g.drawString(a28, 267, 603);
                        g.setColor(color1);
                        g.drawString("." + a29, 320, 603);
                        g.drawString("." + a30, 380, 603);
                        g.drawString("." + a31, 440, 603);
                        break;
                    case 2:
                        g.setColor(color2);
                        g.drawString(a28, 267, 603);
                        g.drawString("." + a29, 320, 603);
                        g.setColor(color1);
                        g.drawString("." + a30, 380, 603);
                        g.drawString("." + a31, 440, 603);

                        break;
                    case 3:
                        g.setColor(color2);
                        g.drawString(a28, 267, 603);
                        g.drawString("." + a29, 320, 603);
                        g.drawString("." + a30, 380, 603);
                        g.setColor(color1);
                        g.drawString("." + a31, 440, 603);
                        break;
                    case 4:
                        g.setColor(color2);
                        g.drawString(a28, 267, 603);
                        g.drawString("." + a29, 320, 603);
                        g.drawString("." + a30, 380, 603);
                        g.drawString("." + a31, 440, 603);
                        a23 = true;
                        a24 = false;
                        break;
                }
            }
            if (a23 == true) {
                g.setColor(color2);
                g.drawString(a28, 267, 603);
                g.drawString("." + a29, 320, 603);
                g.drawString("." + a30, 380, 603);
                g.drawString("." + a31, 440, 603);
                a92();
                a35 = a22.get(a36);
                g.drawImage(new ImageIcon(a35).getImage(), -127, 36, null);
            }
            if (a41 == true) {
                a91();
                a84();
                switch (a42) {
                    case 0:
                        g.setColor(color1);
                        g.drawString(a45, 1378, 886);
                        g.drawString("." + a46, 1431, 886);
                        g.drawString("." + a47, 1488, 886);
                        g.drawString("." + a49, 1545, 886);
                        break;
                    case 1:
                        g.setColor(color2);
                        g.drawString(a45, 1378, 886);
                        g.setColor(color1);
                        g.drawString("." + a46, 1431, 886);
                        g.drawString("." + a47, 1488, 886);
                        g.drawString("." + a49, 1545, 886);
                        break;
                    case 2:
                        g.setColor(color2);
                        g.drawString(a45, 1378, 886);
                        g.drawString("." + a46, 1431, 886);
                        g.setColor(color1);
                        g.drawString("." + a47, 1488, 886);
                        g.drawString("." + a49, 1545, 886);
                        break;
                    case 3:
                        g.setColor(color2);
                        g.drawString(a45, 1378, 886);
                        g.drawString("." + a46, 1431, 886);
                        g.drawString("." + a47, 1488, 886);
                        g.setColor(color1);
                        g.drawString("." + a49, 1545, 886);
                        break;
                    case 4:
                        g.setColor(color2);
                        g.drawString(a45, 1378, 886);
                        g.drawString("." + a46, 1431, 886);
                        g.drawString("." + a47, 1488, 886);
                        g.drawString("." + a49, 1545, 886);
                        a40 = true;
                        a41 = false;
                        break;
                }
            }
            if (a40 == true) {
                g.setColor(color2);
                g.drawString(a28, 267, 603);
                g.drawString("." + a29, 320, 603);
                g.drawString("." + a30, 380, 603);
                g.drawString("." + a31, 440, 603);
                g.drawString(a45, 1378, 886);
                g.drawString("." + a46, 1431, 886);
                g.drawString("." + a47, 1488, 886);
                g.drawString("." + a49, 1545, 886);
                a93();
                a35 = a22.get(a58);
                g.drawImage(new ImageIcon(a35).getImage(), -127, 36, null);
            }
        }
    }
}
