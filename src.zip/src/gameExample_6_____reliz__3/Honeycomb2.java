package gameExample_6_____reliz__3;



import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Created by sofis on 28.07.2019.
 */
public class Honeycomb2 {
    //fields
    private Image bigHoneycomb;       //переменная рисунка большой соты
    private int timerSpeeBigHoneycomb = 50;       //скорость таймера для анимации перемещения bigHoneycomb
    private int cycleCountBigHoneycomb = 0;         //счетчик циклов для перемещения bigHoneycomb
    private int bigHoneycomb_x = 1080;               //задается начальная координата "archivTrackChameleon_x",с которой начинается движение картинки "bigHoneycomb"
    private int bigHoneycomb_y = -900;               //задается начальная координата "archivTrackChameleon_y",с которой начинается движение картинки "bigHoneycomb"

    private int cycleFloatingHoneycomb = 0;     //счетчик циклов для "плаванья" bigHoneycomb
    private int[][] coordinatesForFloatingBigHoneycomb = {       //координаты для "плаванья" bigHoneycomb
            {1030, 50},    //[0]
            {1030, 150},    //[1]
            {1130, 50},    //[2]
            {1130, 150}};    //[3]

    private int numberOfPositioningNew = 0;    //номер позиции bigHoneycomb (в которую должна переместиться сота)
    private int numberOfPositioningOld = 0;
    private int num = 1;                       //на сколько пикселей смещается bigHoneycomb во время "плаванья"

    private Image mediumHoneycomb;       //переменная рисунка средние соты
    private String mediumHoneycombInstance;                //экземпляр картинки из коллекции honeycomb
    ArrayList<String> mediumHoneycombs = new ArrayList<>();   //коллекция картинок


    private int switch0 = 7;    //шаг перемещения средней соты
    private int switch1 = 3;
    private int switch2 = 5;


    // [0]-счетчик циклов для анимации honeycomb2
    // [1]-начальная координата 'archivTrackChameleon_x'
    // [2]-начальная координата 'archivTrackChameleon_y'
    // [3]-координата 'archivTrackChameleon_x' (промежуточная)
    // [4]-координата 'archivTrackChameleon_y' (промежуточная)
    // [5]-откат (координата 'archivTrackChameleon_x')
    // [6]-откат (координата 'archivTrackChameleon_y')
    // [7]-1-й цикл перестройки (координата 'archivTrackChameleon_x')
    // [8]-1-й цикл перестройки (координата 'archivTrackChameleon_y')


    // []-координата 'archivTrackChameleon_x' (конечная)
    // []-координата 'archivTrackChameleon_y' (конечная)

    private int[][] arrayCoordinatesMediumHoneycomb = {
            //0   1    2    3     4    5    6   7   8   9   10   11   12   13   14   15   16   17   18  19   20   21  22   23   24    25   26

            {0, -430, 430, 120, 430, 30, 430, 272, 70, 272, 160, 272, 70, 426, 517, 426, 429, 426, 522, 30, 430, 120, 430, 30, 430, -430, 430,},
            {0, 272, -385, 272, 162, 272, 70, 426, 517, 426, 429, 426, 522, 30, 430, 120, 430, 30, 430, 272, 70, 272, 162, 272, 70, 272, -385,},
            {0, 426, 980, 426, 429, 426, 522, 30, 430, 120, 430, 30, 430, 272, 70, 272, 163, 272, 70, 426, 522, 426, 430, 426, 522, 426, 980,},

    };


    long startTime = System.currentTimeMillis();                        //переменная текущего времени (для фиксации времени начала анимации)
    long startTimeShowAnimationBigHoneycomb = startTime + 70 * 1000;  //ключевая точка времени (изначально 85) //время задержки начала анимации сот                           // 60 seconds * 1000 ms/sec;   //время окончания воспроизведения анимации

    private boolean showONanimationBigHoneycomb = false;   //тригер запуска анимации bigHoneycomb

    private boolean permissionToContinueAnimationOnBigHoneycomb = false;    //разрешение на продолжения анимации на BigHoneycomb


    private long startTimeForMessageAnimation = System.currentTimeMillis();                        //переменная текущего времени (для фиксации времени начала анимации)
    private long startTimeShowForMessageAnimation = startTimeForMessageAnimation + 78 * 1000;   //(ключевая точка времени)время задержки начала анимации сообщений на BigHoneycomb                           // 60 seconds * 1000 ms/sec;   //время окончания воспроизведения анимации
    private int a = 0;

    //////////////////////////////////////////////////////


    //   private int showMessageAnimation_x = 1180;      //координата "archivTrackChameleon_x" для анимации сообщений на BigHoneycomb
    //   private int showMessageAnimation_y = 700;      //координата "archivTrackChameleon_y" для анимации сообщений на BigHoneycomb

    private Image miniHoneycomb;       //переменная рисунка большой соты
    private boolean showAnimationOnMediumHoneycomb_1_andGeneralOnMediumHoneycomb = false;       //переменная,регулируюшая анмацию прогрессбаров и т.д. на MediumHoneycomb


    private boolean showOnMessageAnimationOnMediumHoneycomb_1 = false;

    long startTimeForMediumHoneycomb = System.currentTimeMillis();                        //переменная текущего времени (для фиксации времени начала анимации MiniHoneycomb)
    long startTimeShowAnimationMediumHoneycomb = startTimeForMediumHoneycomb + 14 * 1000;

    private int positionMediumHoneycomb = 1;    //позиция MediumHoneycomb на экране (1,2,3)

    ArrayList<String> progressBarBigCircleArray = new ArrayList<>();   //коллекция картинок
    private String progressBarBigCircleInstance;                //экземпляр картинки из коллекции progressBarBigCircleArray
    private int coordinatesProgressBarBigCircle_x;             //координата "archivTrackChameleon_x" для ProgressBarBigCircle
    private int coordinatesProgressBarBigCircle_y;             //координата "archivTrackChameleon_y" для ProgressBarBigCircle
    private int countForProgressBarBigCircleInstance = 0;     //счетчик для ProgressBarBigCircleInstance (присоединяет картинку из progressBarBigCircleArray к переменной progressBarBigCircleInstance)
    private int auxiliaryCountForProgressBarBigCircleInstance = 0;                           //замедлитель для вращения progressBarBigCircleInstance

    ArrayList<String> progressBarSmallCircleArray = new ArrayList<>();   //коллекция картинок
    private String progressBarSmallCircleInstance;                //экземпляр картинки из коллекции progressBarSmallCircleArray
    private int coordinatesProgressBarSmallCircle_x;             //координата "archivTrackChameleon_x" для ProgressBarSmallCircle
    private int coordinatesProgressBarSmallCircle_y;             //координата "archivTrackChameleon_y" для ProgressBarSmallCircle
    private int countForProgressBarSmallCircleInstance = 1;     //счетчик для ProgressBarSmallCircleInstance (присоединяет картинку из progressBarSmallCircleArray к переменной progressBarSmallCircleInstance)
    private int auxiliaryCountForProgressBarSmallCircleInstance = 0;                           //замедлитель для вращения progressBarSmallCircleInstance

    ArrayList<String> bigCircleExtinctionCollection = new ArrayList<>();    //коллекция для исчезновения большого круга
    private int countForBigCircleExtinctionInstance = 0;     //счетчик для ProgressBarBigCircleInstance (присоединяет картинку из bigCircleExtinctionCollection к переменной progressBarBigCircleInstance) (учавствует в исчезновении большого круга прогрессбвра)
    private int auxiliaryCountBigCircleExtinctionInstance = 0;                           //замедлитель для вращения progressBarBigCircleInstance

    ArrayList<String> smallCircleExtinctionCollection = new ArrayList<>();    //коллекция для исчезновения малого круга
    private int countForSmallCircleExtinctionInstance = 0;     //счетчик для ProgressBarBigCircleInstance (присоединяет картинку из smallCircleExtinctionCollection к переменной progressBarBigCircleInstance) (учавствует в исчезновении малого круга прогрессбвра)
    private int auxiliaryCountSmallCircleExtinctionInstance = 0;                           //замедлитель для вращения progressBarBigCircleInstance

    private int proressBarPercentNumberForCircle = 0;        //процентное число прогрессбара
    private int coordinatesProressBarPercentNumberForCircle_x;    //координата "archivTrackChameleon_x" для proressBarPercentNumberForCircle
    private int coordinatesProressBarPercentNumberForCircle_y;    //координата "archivTrackChameleon_y" для proressBarPercentNumberForCircle
    private int auxiliaryCountProressBarPercentNumberForCircle = 0;  //замедлитель для анимации отщитывания часла в проценте (центр круга)
    private int numberMathRandomForCompositionCollectionBrick = 101; //число,для регуляции заполнения аквалайзера перед очисткой коллекции (аквалайзера),перед очисткой меняется па 50

    //  private int progressBarFillRate = 2;     //скорость заполнения прогрессбара

    ////////////////////////////////////////////////////////

    private boolean showOnMessageAnimationOnMediumHoneycomb_2 = false;   //тригер запуска анимации сообщений на MediumHoneycomb_2 (переменная должна распологаться в методе draw(Graphics2D g), как и переменная showOnMessageAnimationOnBigHoneycomb)
    private boolean showOnMessageAnimationOnMediumHoneycomb_2_afterAnimation = false;    //тригер запуска анимации сокращения коллекции collectonMessageAnimationOnMediumHoneycomb_2 (удаление эллементов из коллекции до полного ее опустошения)
    private boolean showOnMessageAnimationOnMediumHoneycomb_2_afterAnimation_2 = false;    //тригер запуска анимации сокращения коллекции collectonMessageAnimationOnMediumHoneycomb_2 (удаление эллементов из коллекции до полного ее опустошения)

    private boolean showOnMessageAnimationOnMediumHoneycomb_plus = true;
    private boolean showOnMessageAnimationOnMediumHoneycomb_equalizer = false;
    private boolean showOnMessageAnimationOnMediumHoneycomb_equalizer_2 = false;
    private boolean showOnMessageAnimationOnMediumHoneycomb_minus = false;

    private Image brickInstance;                //экземпляр картинки brick
    private int coordinatesBrickInstance_x;   //координата "archivTrackChameleon_x" для BrickInstance
    private int coordinatesBrickInstance_y;    //координата "archivTrackChameleon_y" для BrickInstance
    private boolean animationResolutionForBrick_1 = false;    //разрешение анимации для brick (связано с анимацией brickBasisInstance)

    private boolean animationResolutionForBrick_2 = false;
    private boolean animationResolutionForBrick_3 = false;

    ArrayList collectionBrick = new ArrayList<>();                        //коллекция для кирпичей

    ArrayList<String>[] collectionBricksArray = new ArrayList[6];

    //массив данных для "brick"
    /*
    [0] - номер столбца
    [1] - координата "х"
    [2] - координата "archivTrackChameleon_y"
    [3] - %-ое значение столбца (определяется рандомно) предыдущее
    [4] - %-ое значение столбца (определяется рандомно) текущее (к которому нужно стремится)

     */

    private int[][] brickArray = {
            {1, 530, 795, 0, 0,},
            {2, 564, 795, 0, 0,},
            {3, 598, 795, 0, 0,},
            {4, 632, 795, 0, 0,},
            {5, 666, 795, 0, 0,},
            {6, 700, 795, 0, 0,}};

    ArrayList<String> brickBasisArray = new ArrayList<>();     //массив картинок brickBasisArray
    private String brickBasisInstance;
    private int coordinatesBrickBasisInstance_x;   //координата "archivTrackChameleon_x" для brickBasisArray
    private int coordinatesBrickBasisInstance_y;   //координата "archivTrackChameleon_y" для brickBasisArray
    private int countForBrickBasisInstance = 0;     //счетчик для brickBasisInstance (присоединяет картинку из brickBasisArray к переменной brickBasisInstance)
    private int auxiliaryCountForBrickBasisInstance = 0;                           //замедлитель для анимации выведения brickBasisInstance

    /////////////////////////////////////////////////////

    private boolean showOnMessageAnimationOnMediumHoneycomb_3 = false;   //тригер запуска анимации сообщений на MediumHoneycomb_3 (переменная должна распологаться в методе draw(Graphics2D g), как и переменная showOnMessageAnimationOnBigHoneycomb)
    private boolean showOnMessageAnimationOnMediumHoneycomb_3_afterAnimation = false;   //тригер запуска анимации сокращения коллекции collectionBricksArray (удаление эллементов из коллекции до полного ее опустошения)
    private boolean showOnMessageAnimationOnMediumHoneycomb_3_afterAnimation_2 = false;   //тригер запуска анимации сокращения массива collectionBrick (удаление эллементов из массива до полного ее опустошения)


//    private boolean showOffMessageAnimationOnMediumHoneycomb = true;   ////тригер контроля выведения анимации сообщений на MediumHoneycomb
//    private boolean showFinishMessageAnimationOnMediumHoneycomb = true;   //тригер окончательной остановки анимации сообщений(когда они закончились)
//    private boolean temporaryStopperOnMediumHoneycomb = true;    //временный стопер (работает по опеределенный индексам строк из массива строк stringsForMediumHoneycomb)


    private ArrayList<StringBuilder> collectonMessageAnimationOnMediumHoneycomb_3 = new ArrayList<>();        //коллекция для анимации сообщений на MediumHoneycomb №3
    int countSizeCollectionMessageAnimationOnMediumHoneycomb_3 = 5;
    private ArrayList<StringBuilder> auxiliaryCollectonMessageAnimationOnMediumHoneycomb_3 = new ArrayList<>(); //вспомогательная коллекция для анимации сообщений на MediumHoneycomb №3

    //    private StringBuilder stringBuilderMessageAnimationOnMediumHoneycomb_3 = new StringBuilder();        //переменная StringBuilder для анимации сообщений на MediumHoneycomb №3
    private StringBuilder auxiliaryStringBuilderMessageAnimationOnMediumHoneycomb_3 = new StringBuilder();  //вспомогательная StringBuilder для анимации сообщений на MediumHoneycomb №3

    private StringBuilder stringsFor_3_MediumHoneycomb = new StringBuilder();

    private int numberOfRowsPerMediumHoneycomb_3 = 10;     //колличество сторок на BigHoneycomb,одномоментно прорисовываемых на MediumHoneycomb №3

    private boolean permissionToAddAnItem_1 = true;
    private boolean permissionToAddAnItem_2 = false;    //разрешение на добавление эллемента
    private boolean auxiliaryPermissionToAddAnItem = false;

    private int coordinatesForAnimatiomOnMediumHoneycomb_3_x;   //координата "archivTrackChameleon_x" для анимации сообщений на MediumHoneycomb №3
    private int coordinatesForAnimatiomOnMediumHoneycomb_3_y;   //координата "archivTrackChameleon_y" для анимации сообщений на MediumHoneycomb №3

    int countIndexCharArrayForMediumHoneycomb = 0;    //счетчик для массива char[] charsArrayForString
    int indexCollectonMessageAnimationForMediumHoneycomb = -1;    //индекс в коллекции StringBuilders
    char[] charsArrayForStringOnMediumHoneycomb;          //массив чаров из единичной строки
    int indexStringsForMediumHoneycomb = 0;           //индекс массива строк
    char symbolForMediumHoneycomb;     //конкретный символ из массива символов в строке

    String[] stringsForMediumHoneycomb_1 = new String[34];
    String[] stringsForMediumHoneycomb_2 = new String[12];
    String[] stringsForMediumHoneycomb_3 = new String[16];
    String[] stringsForMediumHoneycomb_4 = new String[23];
    String[][] stringsForMediumHoneycomb = {stringsForMediumHoneycomb_1, stringsForMediumHoneycomb_2, stringsForMediumHoneycomb_3, stringsForMediumHoneycomb_4};  //двумерный массив с сценариями сообщений для анимации на MediumHoneycomb_3

    private char[] charArrayForAnimationMassageOnMediumHoneycomb_3;    //массив чаров использующийся для анимации сообщений на MediumHoneycomb_3
    private char[] charArrayForAnimationMassageNumberOnMediumHoneycomb_3;   //массив чаров использующийся для анимации сообщений на MediumHoneycomb_3

    private boolean choiceScenarioTextFromStringsForMediumHoneycomb = true;   //выбор сценария текста из сценариев stringsForMediumHoneycomb
    private int numberScenarioFromStringsForMediumHoneycomb = 0;        //номер сценария из stringsForMediumHoneycomb (номер первой ячейки двухмерного массива )
    private int numberSecondCellForStringsForMediumHoneycomb;       //длинна у данного массива (из массива масивов) (stringsForMediumHoneycomb[][...])

    private int numberOfCyclesForMediumHoneycomb_3 = 10;      //количество циклов для MediumHoneycomb_3 (при достижении этого количества,прекращается анимация на MediumHoneycomb_3(и меняется цвет лампочки на зеленый))
    private int countNumberOfCyclesForMediumHoneycomb_3 = 0;    //счетчик количества циклов для MediumHoneycomb_3 (при достижении этого количества,прекращается анимация на MediumHoneycomb_3(и меняется цвет лампочки на зеленый))

    //////////////////////////////////////////////////////////

    private boolean showOnMessageAnimationOnBigHoneycomb = false;   //тригер запуска анимации сообщений на BigHoneycomb
    private boolean showOffMessageAnimationOnBigHoneycomb = true;   ////тригер контроля выведения анимации сообщений на BigHoneycomb
    private boolean showFinishMessageAnimationOnBigHoneycomb = true;   //тригер окончательной остановки анимации сообщений(когда они закончились)

    private boolean temporaryStopperOnBigHoneycomb = true;    //временный стопер (работает по опеределенный индексам строк из массива строк stringsForBigHoneycomb)


    private ArrayList<StringBuilder> collectonMessageAnimationOnBigHoneycomb = new ArrayList<>();        //коллекция для анимации сообщений на BigHoneycomb
    private StringBuilder stringBuilderMessageAnimationOnBigHoneycomb = new StringBuilder();        //переменная StringBuilder для анимации сообщений на BigHoneycomb

    private String[] stringsForBigHoneycomb = new String[84];    //массив строк с сообщениями (необходимо указать количество строк-размер массива) для на BigHoneycomb
    private char[] charsArrayForStringOnBigHoneycomb;          //массив чаров из единичной строки на BigHoneycomb
    private char symbolFromCharsArrayForStringOnBigHoneycomb;     //конкретный символ из массива символов в строке на BigHoneycomb

    private int numberOfRowsPerBigHoneycomb = 12;     //колличество сторок на BigHoneycomb,одномоментно прорисовываемых на BigHoneycomb

    private int countIndexCharArrayForStringOnBigHoneycomb = 0;    //счетчик для массива char[] charsArrayForStringOnBigHoneycomb
    private int indexStringsFromCharArrayForStringOnBigHoneycomb = 0;           //индекс массива строк из CharArrayForStringOnBigHoneycomb
    private int indexCollectonMessageAnimationOnBigHoneycomb = -1;    //индекс в коллекции StringBuilders для анимации на BigHoneycomb

    private int numberForComparison_time3;   //количество секунд задержки поеред анимацией на MediumHoneycombs,после начала части анимации на BigHoneycomb

    /////////////////////////////////////////////////////

    ArrayList<String> colorLightBulbRedArray = new ArrayList<>();     //массив картинок цвет лампочки (красный)

    ArrayList<String> colorLightBulbYellowArray = new ArrayList<>();     //массив картинок цвет лампочки (желтый)

    ArrayList<String> colorLightBulbGreenArray = new ArrayList<>();     //массив картинок цвет лампочки (зеленый)

    private int[][] dataForLightBulbsOnMediumHoneycombsArray = {                     //массив данных для лампочек на MediumHoneycombs
            /*
            [0] - номер сценария изменения цвета (1-красный  2-желтый  3-зеленый)
            [1] - счетчика изменения интенсивности картинки ламночки
            [2] - замедлителя изменения
            [3] - координата "х"
            [4] - координата "archivTrackChameleon_y"
             */

            {1, 0, 0, 185, 330,},
            {1, 4, 1, 185, 330,},
            {1, 8, 2, 185, 330,}};

    private String[] LightBulbs = new String[3];

    private boolean drawingExecutionForLightBulb1 = false;        //переменная,устанавливающая лампочек зеленый цвет,после полной отрисови анимации прогрессбара на своем  mediumHoneycomb (лампочка1)
//    private boolean drawingExecutionForLightBulb2 = false;        //переменная,устанавливающая лампочек зеленый цвет,после полной отрисови анимации прогрессбара на своем  mediumHoneycomb (лампочка2)
//    private boolean drawingExecutionForLightBulb3 = false;        //переменная,устанавливающая лампочек зеленый цвет,после полной отрисови анимации прогрессбара на своем  mediumHoneycomb (лампочка3)

    private boolean finishAnimationForMediumHoneycomb = false;    //переменная,разрешающая финишную анимацию для BigHoneycomb и MediumHoneycomb
    private int countCycleForBigAndMediumHoneycomb = 0;

    ////////////////////////////////////////////////////

    ArrayList<String> collectionForTransparencyHoneycomb_19 = new ArrayList<>();     //коллекция для анимации исчезновения бага на Honeycomb_19

    private String honeycomb_19_Instance;   //экземпляр для картинки из коллекции collectionForTransparencyHoneycomb_19

    private int coordinatesHoneycomb_19_x = 805;       //координата Honeycomb_19 по оси 'archivTrackChameleon_x'
    private int coordinatesHoneycomb_19_y = 391;       //координата Honeycomb_19 по оси 'archivTrackChameleon_y'

    private int animationDelayForTransparencyHoneycomb_19 = 0;   //прерменная,для задержки воспроизведения анимации прозрачности
    private int countForAnimationTransparencyHoneycomb_19 = 0;   //счетчик,для анимации Honeycomb_19

    private boolean animationForTransparencyHoneycomb_19 = false;   //переменная,разришающая анимацию прозрачности TransparencyHoneycomb_19

    ///////////////////////////////////////////////////

    ArrayList<String> collectionForTransparencyBackgroundHoneycomb = new ArrayList<>();     //коллекция для анимации исчезновения бага на Honeycomb_19

    private String backgroundHoneycombInstance;   //экземпляр для картинки из коллекции collectionForTransparencyHoneycomb_19

    private int backgroundHoneycomb_x = -9;       //координата BackgroundHoneycomb по оси 'archivTrackChameleon_x'
    private int backgroundHoneycomb_y = -7;       //координата BackgroundHoneycomb по оси 'archivTrackChameleon_y'

    private int animationDelayForBackgroundHoneycomb = 1;     //прерменная,для задержки воспроизведения анимации прозрачности
    private int countForAnimationBackgroundHoneycomb = 1;      //счетчик,для анимации BackgroundHoneycomb

    private boolean animationForTransparencyBackgroundHoneycomb = false;   //переменная,разришающая анимацию прозрачности BackgroundHoneycomb


    //constructor
    public Honeycomb2() throws IOException {
        bigHoneycomb = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/bigHoneycomb/bigHoneycomb5.png"));

        for (int i = 1; i <= 3; i++) {
            mediumHoneycombs.add("gameResourse2/resourseImages/ImagesForScreenSaver/bigHoneycomb/mediumHoneycomb4.png");   //заполнение коллекции honeycomb картинками сот
        }

        miniHoneycomb = ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/miniHoneycomb/miniHoneycomb4.png"));

        // stringsForBigHoneycomb[20] = "Haker works!!! inspections ......................20";

        stringsForBigHoneycomb[0] = "Развертывание и активация beta версии  ";
        stringsForBigHoneycomb[1] = "мобильного отладчика ";
        stringsForBigHoneycomb[2] = "'Debugger VIVISECTOR.ultra'...               ";
        stringsForBigHoneycomb[3] = "----------------------- это сообщение не выводится !!!!!!!!!";

        stringsForBigHoneycomb[4] = "   ";
        stringsForBigHoneycomb[5] = "Поиск критического фактора,вызвавшего ";
        stringsForBigHoneycomb[6] = "активацию дебагера...            ";
        stringsForBigHoneycomb[7] = "   ";
        stringsForBigHoneycomb[8] = "Обнаружено несоответствие со сценари-";
        stringsForBigHoneycomb[9] = "ем отображения матричной структуры ";
        stringsForBigHoneycomb[10] = "обЪекта МН-37g (Error 274/47.12i)";
        stringsForBigHoneycomb[11] = "   ";
        stringsForBigHoneycomb[12] = "Инициализация поиска корректного шаб-";
        stringsForBigHoneycomb[13] = "лона сценария по открытому шлюзу из";
        stringsForBigHoneycomb[14] = "базы данных GBD 4.18 ...       ";
        stringsForBigHoneycomb[15] = "   ";
        stringsForBigHoneycomb[16] = "Шаблон с поврежденной матричной ";
        stringsForBigHoneycomb[17] = "структурой объекта МН-37g обнаружен.";
        stringsForBigHoneycomb[18] = "Запуск KeigenLogPass v.3.27 для полу-";
        stringsForBigHoneycomb[19] = "чения логина и пароля к GBD 4.18 ...";
        stringsForBigHoneycomb[20] = "-----------------------";

        stringsForBigHoneycomb[21] = "                  ";
        stringsForBigHoneycomb[22] = "Логин : FN8w2S16yB2";
        stringsForBigHoneycomb[23] = "Пароль : **********";
        stringsForBigHoneycomb[24] = "                  ";
        stringsForBigHoneycomb[25] = "Запрос валидатора на персонификацию";
        stringsForBigHoneycomb[26] = "пользователя для входа в GBD 4.18 ...";
        stringsForBigHoneycomb[27] = "                  ";
        stringsForBigHoneycomb[28] = "Получен доступ к GBD 4.18 .";
        stringsForBigHoneycomb[29] = "                  ";
        stringsForBigHoneycomb[30] = "Шаблон сценария МН-37g идентифициро-";
        stringsForBigHoneycomb[31] = "ван. ";
        stringsForBigHoneycomb[32] = "                  ";
        stringsForBigHoneycomb[33] = "Компиляция CRUDS-application...     ";
        stringsForBigHoneycomb[34] = "                  ";
        stringsForBigHoneycomb[35] = "Локализована причина повреждения мат-";
        stringsForBigHoneycomb[36] = "ричной структуры обЪекта МН-37g.    ";
        stringsForBigHoneycomb[37] = "                  ";
        stringsForBigHoneycomb[38] = "Реинтеграция обновленной α-матрицы у ";
        stringsForBigHoneycomb[39] = "обЪекта МН-37g ... ";
        stringsForBigHoneycomb[40] = "                  ";
        stringsForBigHoneycomb[41] = "Запуск мобильного автономного менед-";
        stringsForBigHoneycomb[42] = "жера TotalControl CoT-17 v.3.149 для ";
        stringsForBigHoneycomb[43] = "восстановления поврежденной матрич-";
        stringsForBigHoneycomb[44] = "ной структуры объекта МН-37g ...";
        stringsForBigHoneycomb[45] = "-----------------------";

        stringsForBigHoneycomb[46] = "    ";
        stringsForBigHoneycomb[47] = "Запуск копирования шаблона сценария на ";
        stringsForBigHoneycomb[48] = "резервный виртуальный сервер для ком-";
        stringsForBigHoneycomb[49] = "пиляции в среде развертывания сцена- ";
        stringsForBigHoneycomb[50] = "риев...                             ";
        stringsForBigHoneycomb[51] = "    ";
        stringsForBigHoneycomb[52] = "Копирование шаблона завершено удачно.";
        stringsForBigHoneycomb[53] = "Запуск компиляции шаблона сценария в ";
        stringsForBigHoneycomb[54] = "среде развертывания сценариев...     ";
        stringsForBigHoneycomb[55] = "    ";
        stringsForBigHoneycomb[56] = "Ошибка запуска компиляции шаблона : ";
        stringsForBigHoneycomb[57] = "Error STC-488.17";
        stringsForBigHoneycomb[58] = "Запуск TPV.plus ...";
        stringsForBigHoneycomb[59] = "    ";

        stringsForBigHoneycomb[60] = "Обнаружено вредоносное ПО. Запущена ";
        stringsForBigHoneycomb[61] = "идентификация вредоносного ПО...";
        stringsForBigHoneycomb[62] = "Зпущена локализация вредоносного ПО...";
        stringsForBigHoneycomb[63] = "Вредоносное ПО локализовано.";
        stringsForBigHoneycomb[64] = "    ";
        stringsForBigHoneycomb[65] = "Осуществлена timing-закладка для устра-";
        stringsForBigHoneycomb[66] = "нения несоответствия со сценарием ото-";
        stringsForBigHoneycomb[67] = "бражения матричной структуры объекта";
        stringsForBigHoneycomb[68] = "МН-37g .";
        stringsForBigHoneycomb[69] = "Запуск инактивации 'Debugger ";
        stringsForBigHoneycomb[70] = "VIVISECTOR.ultra' ...";
        stringsForBigHoneycomb[71] = "-----------------------";

        stringsForBigHoneycomb[72] = "    ";
        stringsForBigHoneycomb[73] = "    ";
        stringsForBigHoneycomb[74] = "    ";
        stringsForBigHoneycomb[75] = "    ";
        stringsForBigHoneycomb[76] = "    ";
        stringsForBigHoneycomb[77] = "    ";
        stringsForBigHoneycomb[78] = "    ";
        stringsForBigHoneycomb[79] = "    ";
        stringsForBigHoneycomb[80] = "    ";
        stringsForBigHoneycomb[81] = "    ";
        stringsForBigHoneycomb[82] = "    ";
        stringsForBigHoneycomb[83] = "    ";


        charArrayForAnimationMassageOnMediumHoneycomb_3 = new char[]{'A', 'a', 'B', 'b', 'C', 'c', 'D', 'd', 'E', 'e', 'I', 'i', 'F', 'f', 'G', 'g', 'H', 'h', 'J', 'j', 'K', 'k', 'L', 'l', 'M', 'm', 'N', 'n', 'O', 'o', 'P', 'p', 'Q', 'q', 'R', 'r', 'S', 's', 'T', 't', 'U', 'u', 'V', 'v', 'W', 'w', 'Y', 'y', 'X', 'x', 'Z', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9'};
        charArrayForAnimationMassageNumberOnMediumHoneycomb_3 = new char[]{'0', '1', '2', '3', '4', '5', '6', '7', '8', '9'};


        stringsForMediumHoneycomb_1[0] = "public static void main(String[] args) {";
        stringsForMediumHoneycomb_1[1] = "   //fields";
        stringsForMediumHoneycomb_1[2] = "  private int = 21;";
        stringsForMediumHoneycomb_1[3] = "  private double = 36.348";
        stringsForMediumHoneycomb_1[4] = "  private boolean = true";
        stringsForMediumHoneycomb_1[5] = "  private byte=  127";
        stringsForMediumHoneycomb_1[6] = "  private short = -32768";
        stringsForMediumHoneycomb_1[7] = "  private char = 'a'";
        stringsForMediumHoneycomb_1[8] = "  private float = 3.14f";
        stringsForMediumHoneycomb_1[9] = "  private long = 2147483648L";
        stringsForMediumHoneycomb_1[10] = "  ";

        stringsForMediumHoneycomb_1[11] = "    //constructor";
        stringsForMediumHoneycomb_1[12] = "  public Raptor(){";
        stringsForMediumHoneycomb_1[13] = "     for (int i = 1; i <= 37; i++) {";
        stringsForMediumHoneycomb_1[14] = "        raptor.add();";
        stringsForMediumHoneycomb_1[15] = "     }";
        stringsForMediumHoneycomb_1[16] = "  }";
        stringsForMediumHoneycomb_1[17] = "  ";

        stringsForMediumHoneycomb_1[18] = "  //functions";
        stringsForMediumHoneycomb_1[19] = " @Override";
        stringsForMediumHoneycomb_1[20] = "  public void run() {";
        stringsForMediumHoneycomb_1[21] = "     FPS = 30;";
        stringsForMediumHoneycomb_1[22] = "     millisToFPS = 1000 / FPS;";
        stringsForMediumHoneycomb_1[23] = "     sleepTime = 0;";
        stringsForMediumHoneycomb_1[24] = "     g=(Graphics2D)image.getGraphics();";
        stringsForMediumHoneycomb_1[25] = "     try {";
        stringsForMediumHoneycomb_1[26] = "       backgroundScreenSaver = ";
        stringsForMediumHoneycomb_1[27] = "       new BackgroundScreenSaver();";
        stringsForMediumHoneycomb_1[28] = "     } catch (IOException e) {";
        stringsForMediumHoneycomb_1[29] = "       e.printStackTrace();";
        stringsForMediumHoneycomb_1[30] = "     }";
        stringsForMediumHoneycomb_1[31] = "  }";
        stringsForMediumHoneycomb_1[32] = "  ";

        stringsForMediumHoneycomb_1[33] = "<Haker.command.startBeginer>";

        ///////////////////////////////

        stringsForMediumHoneycomb_2[0] = "start(int delay_secs);";
        stringsForMediumHoneycomb_2[1] = "createCache(int size_mb);";
        stringsForMediumHoneycomb_2[2] = "downloadFile(float max_kbps);";
        stringsForMediumHoneycomb_2[3] = "rotate(float degrees_cw);";
        stringsForMediumHoneycomb_2[4] = "  ";

        stringsForMediumHoneycomb_2[5] = "  public void run() {";
        stringsForMediumHoneycomb_2[6] = "     for (int i = 1; i <= 37; i++) {";
        stringsForMediumHoneycomb_2[7] = "        raptor.add();";
        stringsForMediumHoneycomb_2[8] = "     }";
        stringsForMediumHoneycomb_2[9] = "  }";
        stringsForMediumHoneycomb_2[10] = "  ";

        stringsForMediumHoneycomb_2[11] = "<Haker.command.startBeginer>";

        ////////////////////////////////


        stringsForMediumHoneycomb_3[0] = "#!/usr/bin/python";
        stringsForMediumHoneycomb_3[1] = "# -*- coding: utf-8 -*-";
        stringsForMediumHoneycomb_3[2] = "import sqlite3 as lite";
        stringsForMediumHoneycomb_3[3] = "import sys";
        stringsForMediumHoneycomb_3[4] = "  ";
        stringsForMediumHoneycomb_3[5] = "con = lite.connect('test.db')";
        stringsForMediumHoneycomb_3[6] = "  ";
        stringsForMediumHoneycomb_3[7] = "with con:";
        stringsForMediumHoneycomb_3[8] = "   cur = con.cursor()";
        stringsForMediumHoneycomb_3[9] = "   cur.execute(\"SELECT * FROM Cars\")";
        stringsForMediumHoneycomb_3[10] = "  rows = cur.fetchall()";
        stringsForMediumHoneycomb_3[11] = "  ";
        stringsForMediumHoneycomb_3[12] = "  for row in rows:";
        stringsForMediumHoneycomb_3[13] = "     print row";
        stringsForMediumHoneycomb_3[14] = "  ";
        stringsForMediumHoneycomb_3[15] = "<Haker.command.startBeginer>";

        ///////////////////////////////////////////

        stringsForMediumHoneycomb_4[0] = "div onmousedown=";
        stringsForMediumHoneycomb_4[1] = "  'mDown(this)' onmouseup=";
        stringsForMediumHoneycomb_4[2] = "  'mUp(this)";
        stringsForMediumHoneycomb_4[3] = "style=140px;height: color:";
        stringsForMediumHoneycomb_4[4] = "  'background-color:green;width:";
        stringsForMediumHoneycomb_4[5] = "  20px;padding:20px;";
        stringsForMediumHoneycomb_4[6] = "  #fff'>Нажать здесь</div>";
        stringsForMediumHoneycomb_4[7] = "  ";

        stringsForMediumHoneycomb_4[8] = "<script>";
        stringsForMediumHoneycomb_4[9] = "function mDown(obj)";
        stringsForMediumHoneycomb_4[10] = "  {";
        stringsForMediumHoneycomb_4[11] = "   obj.style.backgroundColor='#1ec5e5';";
        stringsForMediumHoneycomb_4[12] = "   obj.innerHTML =";
        stringsForMediumHoneycomb_4[13] = "   'computer control is locked'";
        stringsForMediumHoneycomb_4[14] = "  }";
        stringsForMediumHoneycomb_4[15] = "function mUp(obj)";
        stringsForMediumHoneycomb_4[16] = "  {";
        stringsForMediumHoneycomb_4[17] = "   obj.style.backgroundColor='#D94A38';";
        stringsForMediumHoneycomb_4[18] = "   obj.innerHTML='access denied'";
        stringsForMediumHoneycomb_4[19] = "  }";
        stringsForMediumHoneycomb_4[20] = "</script>";
        stringsForMediumHoneycomb_4[21] = "  ";

        stringsForMediumHoneycomb_4[22] = "<Haker.command.startBeginer>";

        ////////////////////////////////

        //постороение auxiliarycountSizeCollectionMessageAnimationOnMediumHoneycomb_3
        for (int i = 0; i < countSizeCollectionMessageAnimationOnMediumHoneycomb_3; i++) {
            for (int j = 0; j <= 13; j++) {
                if (j == 4 || j == 7 || j == 10 || j == 13) {
                    stringsFor_3_MediumHoneycomb.append(' ');
                }

                if (j == 0 || j == 1 || j == 2 || j == 3) {
                    stringsFor_3_MediumHoneycomb.append(charArrayForAnimationMassageOnMediumHoneycomb_3[(int) (0 + (Math.random() * (charArrayForAnimationMassageOnMediumHoneycomb_3.length)))]);
                }
                if (j == 5 || j == 6 || j == 8 || j == 9 || j == 11 || j == 12) {
                    stringsFor_3_MediumHoneycomb.append(charArrayForAnimationMassageNumberOnMediumHoneycomb_3[(int) (0 + (Math.random() * (charArrayForAnimationMassageNumberOnMediumHoneycomb_3.length)))]);
                }
                auxiliaryCollectonMessageAnimationOnMediumHoneycomb_3.add(stringsFor_3_MediumHoneycomb);
        //        System.out.println(stringsFor_3_MediumHoneycomb.toString());
            }
        }


        for (int i = 1; i <= 28; i++) {
            progressBarBigCircleArray.add("gameResourse2/resourseImages/ImagesForScreenSaver/big circle/" + i + ".png");   //заполнение коллекции progressBarBigCircleArray картинками сот
        }

        for (int i = 1; i <= 26; i++) {
            progressBarSmallCircleArray.add("gameResourse2/resourseImages/ImagesForScreenSaver/small circle/" + i + ".png");   //заполнение коллекции progressBarBigCircleArray картинками сот
        }

        for (int i = 1; i <= 28; i++) {
            bigCircleExtinctionCollection.add("gameResourse2/resourseImages/ImagesForScreenSaver/big circle extinction/" + i + ".png");
        }

        for (int i = 1; i <= 26; i++) {
            smallCircleExtinctionCollection.add("gameResourse2/resourseImages/ImagesForScreenSaver/small circle extinction/" + i + ".png");
        }


        brickInstance = (ImageIO.read(new File("gameResourse2/resourseImages/ImagesForScreenSaver/brick/brick.png")));

        for (int i = 0; i <= 7; i++) {
            brickBasisArray.add("gameResourse2/resourseImages/ImagesForScreenSaver/brick2/" + i + ".png");
        }

        for (int i = 1; i <= 10; i++) {
            colorLightBulbRedArray.add("gameResourse2/resourseImages/ImagesForScreenSaver/light bulb/light bulb_red/" + i + ".png");
        }

        for (int i = 1; i <= 10; i++) {
            colorLightBulbYellowArray.add("gameResourse2/resourseImages/ImagesForScreenSaver/light bulb/light bulb_yellow/" + i + ".png");
        }

        for (int i = 1; i <= 10; i++) {
            colorLightBulbGreenArray.add("gameResourse2/resourseImages/ImagesForScreenSaver/light bulb/light bulb_green/" + i + ".png");
        }

        for (int i = 0; i < collectionBricksArray.length; i++) {
            collectionBricksArray[i] = new ArrayList<String>() {{
                add(String.valueOf(collectionBrick));
            }};
        }

        for (int i = 1; i <= 21; i++) {
            collectionForTransparencyHoneycomb_19.add("gameResourse2/resourseImages/ImagesForScreenSaver/transparencyHoneycomb_19/" + i + ".png");
        }

        for (int i = 1; i <= 21; i++) {
            collectionForTransparencyBackgroundHoneycomb.add("gameResourse2/resourseImages/ImagesForScreenSaver/transparencyBackgroundHoneycomb/" + i + ".png");
        }
    }


    Timer timerBigHoneycomb = new Timer(timerSpeeBigHoneycomb, new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            //код который нужно выполнить каждый интервал timerSpeed

            switch (cycleCountBigHoneycomb) {
                case 0:
                    bigHoneycomb_y = bigHoneycomb_y + 10;
                    if (bigHoneycomb_y == 100) {
                        cycleCountBigHoneycomb++;
                    }
                    break;
                case 1:                                    //условие для остановки таймера анимации timerBigHoneycomb
                    timerBigHoneycomb.stop();
                    timerFloatingHoneycomb.start();
                    break;

                case 2:
                    bigHoneycomb_y = bigHoneycomb_y - 8;
                    if (bigHoneycomb_y == 0) {
                        //            cycleCountBigHoneycomb++;
                    }
                    break;


                default:
                    System.out.println("что-то пошло не так!!!");
            }
        }


    });


    Timer timerFloatingHoneycomb = new Timer(timerSpeeBigHoneycomb, new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            //код который нужно выполнить каждый интервал timerSpeed

            switch (cycleFloatingHoneycomb) {
                case 0:
                    if (bigHoneycomb_x < coordinatesForFloatingBigHoneycomb[numberOfPositioningOld][0] && bigHoneycomb_y < coordinatesForFloatingBigHoneycomb[numberOfPositioningOld][1]) {
                        bigHoneycomb_x = bigHoneycomb_x + num;
                        bigHoneycomb_y = bigHoneycomb_y + num;
                    }
                    if (bigHoneycomb_x < coordinatesForFloatingBigHoneycomb[numberOfPositioningOld][0] && bigHoneycomb_y > coordinatesForFloatingBigHoneycomb[numberOfPositioningOld][1]) {
                        bigHoneycomb_x = bigHoneycomb_x + num;
                        bigHoneycomb_y = bigHoneycomb_y - num;
                    }
                    if (bigHoneycomb_x == coordinatesForFloatingBigHoneycomb[numberOfPositioningOld][0] && bigHoneycomb_y < coordinatesForFloatingBigHoneycomb[numberOfPositioningOld][1]) {
                        bigHoneycomb_y = bigHoneycomb_y + num;
                    }
                    if (bigHoneycomb_x == coordinatesForFloatingBigHoneycomb[numberOfPositioningOld][0] && bigHoneycomb_y > coordinatesForFloatingBigHoneycomb[numberOfPositioningOld][1]) {
                        bigHoneycomb_y = bigHoneycomb_y - num;
                    }
                    if (bigHoneycomb_x > coordinatesForFloatingBigHoneycomb[numberOfPositioningOld][0] && bigHoneycomb_y < coordinatesForFloatingBigHoneycomb[numberOfPositioningOld][1]) {
                        bigHoneycomb_x = bigHoneycomb_x - num;
                        bigHoneycomb_y = bigHoneycomb_y + num;
                    }
                    if (bigHoneycomb_x > coordinatesForFloatingBigHoneycomb[numberOfPositioningOld][0] && bigHoneycomb_y > coordinatesForFloatingBigHoneycomb[numberOfPositioningOld][1]) {
                        bigHoneycomb_x = bigHoneycomb_x - num;
                        bigHoneycomb_y = bigHoneycomb_y - num;
                    }
                    if (bigHoneycomb_x > coordinatesForFloatingBigHoneycomb[numberOfPositioningOld][0] && bigHoneycomb_y == coordinatesForFloatingBigHoneycomb[numberOfPositioningOld][1]) {
                        bigHoneycomb_x = bigHoneycomb_x - num;
                    }
                    if (bigHoneycomb_x < coordinatesForFloatingBigHoneycomb[numberOfPositioningOld][0] && bigHoneycomb_y == coordinatesForFloatingBigHoneycomb[numberOfPositioningOld][1]) {
                        bigHoneycomb_x = bigHoneycomb_x + num;
                    }


                    if (bigHoneycomb_x == coordinatesForFloatingBigHoneycomb[numberOfPositioningOld][0] && bigHoneycomb_y == coordinatesForFloatingBigHoneycomb[numberOfPositioningOld][1]) {
                        cycleFloatingHoneycomb++;
                    }
                    //    cycleFloatingHoneycomb++;

                    break;
                case 1:
                    randomPositioning();
                    cycleFloatingHoneycomb = 0;

                    break;
                case 2:                                    //условие для остановки таймера анимации timerFloatingHoneycomb
                    timerFloatingHoneycomb.stop();
                    break;
                default:
                    System.out.println("что-то пошло не так!!!");
            }
        }


    });

    Timer timerMediumHoneycomb = new Timer(timerSpeeBigHoneycomb, new ActionListener() {
        public void actionPerformed(ActionEvent e) {

            for (int i = 0; i < mediumHoneycombs.size(); i++) {

                switch (arrayCoordinatesMediumHoneycomb[i][0]) {
                    case 0:
                        if (arrayCoordinatesMediumHoneycomb[i][1] < arrayCoordinatesMediumHoneycomb[i][3] && arrayCoordinatesMediumHoneycomb[i][2] == arrayCoordinatesMediumHoneycomb[i][4]) {
                            if (arrayCoordinatesMediumHoneycomb[i][1] + switch0 < arrayCoordinatesMediumHoneycomb[i][3]) {
                                arrayCoordinatesMediumHoneycomb[i][1] = arrayCoordinatesMediumHoneycomb[i][1] + switch0;
                                break;
                            }
                            if (arrayCoordinatesMediumHoneycomb[i][1] + switch0 >= arrayCoordinatesMediumHoneycomb[i][3]) {
                                arrayCoordinatesMediumHoneycomb[i][1] = arrayCoordinatesMediumHoneycomb[i][3];
                                arrayCoordinatesMediumHoneycomb[i][0]++;
                                break;
                            }
                        }

                        if (arrayCoordinatesMediumHoneycomb[i][2] < arrayCoordinatesMediumHoneycomb[i][4] && arrayCoordinatesMediumHoneycomb[i][1] == arrayCoordinatesMediumHoneycomb[i][3]) {
                            if (arrayCoordinatesMediumHoneycomb[i][2] + switch0 < arrayCoordinatesMediumHoneycomb[i][4]) {
                                arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][2] + switch0;
                                break;
                            }
                            if (arrayCoordinatesMediumHoneycomb[i][2] + switch0 >= arrayCoordinatesMediumHoneycomb[i][4]) {
                                arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][4];
                                arrayCoordinatesMediumHoneycomb[i][0]++;
                                break;
                            }
                        }

                        if (arrayCoordinatesMediumHoneycomb[i][2] > arrayCoordinatesMediumHoneycomb[i][4] && arrayCoordinatesMediumHoneycomb[i][1] == arrayCoordinatesMediumHoneycomb[i][3]) {
                            if (arrayCoordinatesMediumHoneycomb[i][2] - switch0 > arrayCoordinatesMediumHoneycomb[i][4]) {
                                arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][2] - switch0;
                                break;
                            }
                            if (arrayCoordinatesMediumHoneycomb[i][2] - switch0 <= arrayCoordinatesMediumHoneycomb[i][4]) {
                                arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][4];
                                arrayCoordinatesMediumHoneycomb[i][0]++;
                                break;
                            }
                        }
                        break;

                    case 1:

                        if (arrayCoordinatesMediumHoneycomb[i][1] > arrayCoordinatesMediumHoneycomb[i][5] && arrayCoordinatesMediumHoneycomb[i][2] == arrayCoordinatesMediumHoneycomb[i][6]) {
                            if (arrayCoordinatesMediumHoneycomb[i][1] - switch1 > arrayCoordinatesMediumHoneycomb[i][5]) {
                                arrayCoordinatesMediumHoneycomb[i][1] = arrayCoordinatesMediumHoneycomb[i][1] - switch1;
                                break;
                            }
                            if (arrayCoordinatesMediumHoneycomb[i][1] - switch1 <= arrayCoordinatesMediumHoneycomb[i][5]) {
                                arrayCoordinatesMediumHoneycomb[i][1] = arrayCoordinatesMediumHoneycomb[i][5];
                                arrayCoordinatesMediumHoneycomb[i][0]++;
                                break;
                            }
                        }

                        if (arrayCoordinatesMediumHoneycomb[i][2] > arrayCoordinatesMediumHoneycomb[i][6] && arrayCoordinatesMediumHoneycomb[i][1] == arrayCoordinatesMediumHoneycomb[i][5]) {
                            if (arrayCoordinatesMediumHoneycomb[i][2] - switch1 > arrayCoordinatesMediumHoneycomb[i][6]) {
                                arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][2] - switch1;
                                break;
                            }
                            if (arrayCoordinatesMediumHoneycomb[i][2] - switch1 <= arrayCoordinatesMediumHoneycomb[i][6]) {
                                arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][6];
                                arrayCoordinatesMediumHoneycomb[i][0]++;
                                break;
                            }
                        }

                        if (arrayCoordinatesMediumHoneycomb[i][2] < arrayCoordinatesMediumHoneycomb[i][6] && arrayCoordinatesMediumHoneycomb[i][1] == arrayCoordinatesMediumHoneycomb[i][5]) {
                            if (arrayCoordinatesMediumHoneycomb[i][2] + switch1 < arrayCoordinatesMediumHoneycomb[i][6]) {
                                arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][2] + switch1;
                                break;
                            }
                            if (arrayCoordinatesMediumHoneycomb[i][2] + switch1 >= arrayCoordinatesMediumHoneycomb[i][6]) {
                                arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][6];
                                arrayCoordinatesMediumHoneycomb[i][0]++;
                                break;
                            }
                        }
                        break;

                    case 2:

                        if (arrayCoordinatesMediumHoneycomb[i][1] < arrayCoordinatesMediumHoneycomb[i][7] && arrayCoordinatesMediumHoneycomb[i][2] > arrayCoordinatesMediumHoneycomb[i][8]) {
                            if (arrayCoordinatesMediumHoneycomb[i][2] > arrayCoordinatesMediumHoneycomb[i][8]) {
                                if (arrayCoordinatesMediumHoneycomb[i][2] - switch2 > arrayCoordinatesMediumHoneycomb[i][8]) {
                                    arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][2] - switch2;
                                }
                                if (arrayCoordinatesMediumHoneycomb[i][2] - switch2 <= arrayCoordinatesMediumHoneycomb[i][8]) {
                                    arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][8];
                                    break;
                                }
                            }
                            break;
                        }

                        if (arrayCoordinatesMediumHoneycomb[i][1] < arrayCoordinatesMediumHoneycomb[i][7] && arrayCoordinatesMediumHoneycomb[i][2] == arrayCoordinatesMediumHoneycomb[i][8]) {
                            if (arrayCoordinatesMediumHoneycomb[i][1] < arrayCoordinatesMediumHoneycomb[i][7]) {
                                if (arrayCoordinatesMediumHoneycomb[i][1] + switch2 < arrayCoordinatesMediumHoneycomb[i][7]) {
                                    arrayCoordinatesMediumHoneycomb[i][1] = arrayCoordinatesMediumHoneycomb[i][1] + switch2;
                                }
                                if (arrayCoordinatesMediumHoneycomb[i][1] + switch2 >= arrayCoordinatesMediumHoneycomb[i][7]) {
                                    arrayCoordinatesMediumHoneycomb[i][1] = arrayCoordinatesMediumHoneycomb[i][7];
                                }
                            }
                            break;
                        }

                        if (arrayCoordinatesMediumHoneycomb[i][1] < arrayCoordinatesMediumHoneycomb[i][7] && arrayCoordinatesMediumHoneycomb[i][2] < arrayCoordinatesMediumHoneycomb[i][8]) {
                            if (arrayCoordinatesMediumHoneycomb[i][1] < arrayCoordinatesMediumHoneycomb[i][7]) {
                                if (arrayCoordinatesMediumHoneycomb[i][1] + switch2 < arrayCoordinatesMediumHoneycomb[i][7]) {
                                    arrayCoordinatesMediumHoneycomb[i][1] = arrayCoordinatesMediumHoneycomb[i][1] + switch2;
                                }
                                if (arrayCoordinatesMediumHoneycomb[i][1] + switch2 >= arrayCoordinatesMediumHoneycomb[i][7]) {
                                    arrayCoordinatesMediumHoneycomb[i][1] = arrayCoordinatesMediumHoneycomb[i][7];
                                }
                            }
                            break;
                        }

                        if (arrayCoordinatesMediumHoneycomb[i][1] == arrayCoordinatesMediumHoneycomb[i][7] && arrayCoordinatesMediumHoneycomb[i][2] < arrayCoordinatesMediumHoneycomb[i][8]) {
                            if (arrayCoordinatesMediumHoneycomb[i][2] < arrayCoordinatesMediumHoneycomb[i][8]) {
                                if (arrayCoordinatesMediumHoneycomb[i][2] + switch2 < arrayCoordinatesMediumHoneycomb[i][8]) {
                                    arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][2] + switch2;
                                }
                                if (arrayCoordinatesMediumHoneycomb[i][2] + switch2 >= arrayCoordinatesMediumHoneycomb[i][8]) {
                                    arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][8];
                                }
                            }
                            break;
                        }

                        if (arrayCoordinatesMediumHoneycomb[i][1] > arrayCoordinatesMediumHoneycomb[i][7] && arrayCoordinatesMediumHoneycomb[i][2] > arrayCoordinatesMediumHoneycomb[i][8]) {
                            if (arrayCoordinatesMediumHoneycomb[i][1] > arrayCoordinatesMediumHoneycomb[i][7]) {
                                if (arrayCoordinatesMediumHoneycomb[i][1] - switch2 > arrayCoordinatesMediumHoneycomb[i][7]) {
                                    arrayCoordinatesMediumHoneycomb[i][1] = arrayCoordinatesMediumHoneycomb[i][1] - switch2;
                                }
                                if (arrayCoordinatesMediumHoneycomb[i][1] - switch2 <= arrayCoordinatesMediumHoneycomb[i][7]) {
                                    arrayCoordinatesMediumHoneycomb[i][1] = arrayCoordinatesMediumHoneycomb[i][7];
                                }
                            }
                            break;
                        }

                        if (arrayCoordinatesMediumHoneycomb[i][1] == arrayCoordinatesMediumHoneycomb[i][7] && arrayCoordinatesMediumHoneycomb[i][2] > arrayCoordinatesMediumHoneycomb[i][8]) {
                            if (arrayCoordinatesMediumHoneycomb[i][2] > arrayCoordinatesMediumHoneycomb[i][8]) {
                                if (arrayCoordinatesMediumHoneycomb[i][2] - switch2 > arrayCoordinatesMediumHoneycomb[i][8]) {
                                    arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][2] - switch2;
                                }
                                if (arrayCoordinatesMediumHoneycomb[i][2] - switch2 <= arrayCoordinatesMediumHoneycomb[i][8]) {
                                    arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][8];
                                }
                            }
                            break;
                        }


                        if (arrayCoordinatesMediumHoneycomb[i][1] == arrayCoordinatesMediumHoneycomb[i][7] && arrayCoordinatesMediumHoneycomb[i][2] == arrayCoordinatesMediumHoneycomb[i][8]) {
                            arrayCoordinatesMediumHoneycomb[i][0]++;
                            break;
                        }
                        break;

                    case 3:

                        if (indexStringsFromCharArrayForStringOnBigHoneycomb == 3 || indexStringsFromCharArrayForStringOnBigHoneycomb == 80) {

                            showOnMessageAnimationOnMediumHoneycomb_1 = true;
                        }

                        if (temporaryStopperOnBigHoneycomb == true) {
                            if (arrayCoordinatesMediumHoneycomb[0][0] >= 3 && arrayCoordinatesMediumHoneycomb[1][0] >= 3 && arrayCoordinatesMediumHoneycomb[2][0] >= 3) {
                                if (arrayCoordinatesMediumHoneycomb[i][1] == arrayCoordinatesMediumHoneycomb[i][9] && arrayCoordinatesMediumHoneycomb[i][2] < arrayCoordinatesMediumHoneycomb[i][10]) {
                                    if (arrayCoordinatesMediumHoneycomb[i][2] < arrayCoordinatesMediumHoneycomb[i][10]) {
                                        if (arrayCoordinatesMediumHoneycomb[i][2] + switch0 < arrayCoordinatesMediumHoneycomb[i][10]) {
                                            arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][2] + switch0;
                                        }
                                        if (arrayCoordinatesMediumHoneycomb[i][2] + switch0 >= arrayCoordinatesMediumHoneycomb[i][10]) {
                                            arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][10];
                                        }
                                    }
                                    break;
                                }
                                if (arrayCoordinatesMediumHoneycomb[i][1] == arrayCoordinatesMediumHoneycomb[i][9] && arrayCoordinatesMediumHoneycomb[i][2] > arrayCoordinatesMediumHoneycomb[i][10]) {
                                    if (arrayCoordinatesMediumHoneycomb[i][2] > arrayCoordinatesMediumHoneycomb[i][10]) {
                                        if (arrayCoordinatesMediumHoneycomb[i][2] - switch0 > arrayCoordinatesMediumHoneycomb[i][10]) {
                                            arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][2] - switch0;
                                        }
                                        if (arrayCoordinatesMediumHoneycomb[i][2] - switch0 <= arrayCoordinatesMediumHoneycomb[i][10]) {
                                            arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][10];
                                        }
                                    }
                                    break;
                                }


                                if (arrayCoordinatesMediumHoneycomb[i][1] < arrayCoordinatesMediumHoneycomb[i][9] && arrayCoordinatesMediumHoneycomb[i][2] == arrayCoordinatesMediumHoneycomb[i][10]) {

                                    if (arrayCoordinatesMediumHoneycomb[i][1] < arrayCoordinatesMediumHoneycomb[i][9]) {
                                        if (arrayCoordinatesMediumHoneycomb[i][1] + switch0 < arrayCoordinatesMediumHoneycomb[i][9]) {
                                            arrayCoordinatesMediumHoneycomb[i][1] = arrayCoordinatesMediumHoneycomb[i][1] + switch0;
                                        }
                                        if (arrayCoordinatesMediumHoneycomb[i][1] + switch0 >= arrayCoordinatesMediumHoneycomb[i][9]) {
                                            arrayCoordinatesMediumHoneycomb[i][1] = arrayCoordinatesMediumHoneycomb[i][9];
                                        }
                                    }
                                    break;
                                }
                            }

                            if (arrayCoordinatesMediumHoneycomb[i][1] == arrayCoordinatesMediumHoneycomb[i][9] && arrayCoordinatesMediumHoneycomb[i][2] == arrayCoordinatesMediumHoneycomb[i][10]) {
                                arrayCoordinatesMediumHoneycomb[i][0]++;
                                break;
                            }
                        }
                        break;

                    case 4:
                        if (arrayCoordinatesMediumHoneycomb[i][1] == arrayCoordinatesMediumHoneycomb[i][11] && arrayCoordinatesMediumHoneycomb[i][2] > arrayCoordinatesMediumHoneycomb[i][12]) {
                            if (arrayCoordinatesMediumHoneycomb[i][2] > arrayCoordinatesMediumHoneycomb[i][12]) {
                                if (arrayCoordinatesMediumHoneycomb[i][2] - switch1 > arrayCoordinatesMediumHoneycomb[i][12]) {
                                    arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][2] - switch1;
                                }
                                if (arrayCoordinatesMediumHoneycomb[i][2] - switch1 <= arrayCoordinatesMediumHoneycomb[i][12]) {
                                    arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][12];
                                }
                            }
                            break;
                        }
                        if (arrayCoordinatesMediumHoneycomb[i][1] == arrayCoordinatesMediumHoneycomb[i][11] && arrayCoordinatesMediumHoneycomb[i][2] < arrayCoordinatesMediumHoneycomb[i][12]) {
                            if (arrayCoordinatesMediumHoneycomb[i][2] < arrayCoordinatesMediumHoneycomb[i][12]) {
                                if (arrayCoordinatesMediumHoneycomb[i][2] + switch1 < arrayCoordinatesMediumHoneycomb[i][12]) {
                                    arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][2] + switch1;
                                }
                                if (arrayCoordinatesMediumHoneycomb[i][2] + switch1 >= arrayCoordinatesMediumHoneycomb[i][12]) {
                                    arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][12];
                                }
                            }
                            break;
                        }


                        if (arrayCoordinatesMediumHoneycomb[i][1] > arrayCoordinatesMediumHoneycomb[i][11] && arrayCoordinatesMediumHoneycomb[i][2] == arrayCoordinatesMediumHoneycomb[i][12]) {

                            if (arrayCoordinatesMediumHoneycomb[i][1] > arrayCoordinatesMediumHoneycomb[i][11]) {
                                if (arrayCoordinatesMediumHoneycomb[i][1] - switch1 > arrayCoordinatesMediumHoneycomb[i][11]) {
                                    arrayCoordinatesMediumHoneycomb[i][1] = arrayCoordinatesMediumHoneycomb[i][1] - switch1;
                                }
                                if (arrayCoordinatesMediumHoneycomb[i][1] - switch1 <= arrayCoordinatesMediumHoneycomb[i][11]) {
                                    arrayCoordinatesMediumHoneycomb[i][1] = arrayCoordinatesMediumHoneycomb[i][11];
                                }
                            }
                            break;
                        }

                        if (arrayCoordinatesMediumHoneycomb[i][1] == arrayCoordinatesMediumHoneycomb[i][11] && arrayCoordinatesMediumHoneycomb[i][2] == arrayCoordinatesMediumHoneycomb[i][12]) {
                            arrayCoordinatesMediumHoneycomb[i][0]++;
                            break;
                        }
                        break;

                    case 5:

                        if (arrayCoordinatesMediumHoneycomb[i][1] < arrayCoordinatesMediumHoneycomb[i][13] && arrayCoordinatesMediumHoneycomb[i][2] > arrayCoordinatesMediumHoneycomb[i][14]) {
                            if (arrayCoordinatesMediumHoneycomb[i][2] > arrayCoordinatesMediumHoneycomb[i][14]) {
                                if (arrayCoordinatesMediumHoneycomb[i][2] - switch2 > arrayCoordinatesMediumHoneycomb[i][14]) {
                                    arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][2] - switch2;
                                }
                                if (arrayCoordinatesMediumHoneycomb[i][2] - switch2 <= arrayCoordinatesMediumHoneycomb[i][14]) {
                                    arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][14];
                                }
                            }
                            break;
                        }

                        if (arrayCoordinatesMediumHoneycomb[i][1] < arrayCoordinatesMediumHoneycomb[i][13] && arrayCoordinatesMediumHoneycomb[i][2] == arrayCoordinatesMediumHoneycomb[i][14]) {
                            if (arrayCoordinatesMediumHoneycomb[i][1] < arrayCoordinatesMediumHoneycomb[i][13]) {
                                if (arrayCoordinatesMediumHoneycomb[i][1] + switch2 < arrayCoordinatesMediumHoneycomb[i][13]) {
                                    arrayCoordinatesMediumHoneycomb[i][1] = arrayCoordinatesMediumHoneycomb[i][1] + switch2;
                                    //            break;
                                }
                                if (arrayCoordinatesMediumHoneycomb[i][1] + switch2 >= arrayCoordinatesMediumHoneycomb[i][13]) {
                                    arrayCoordinatesMediumHoneycomb[i][1] = arrayCoordinatesMediumHoneycomb[i][13];
                                }
                            }
                            break;
                        }

                        if (arrayCoordinatesMediumHoneycomb[i][1] < arrayCoordinatesMediumHoneycomb[i][13] && arrayCoordinatesMediumHoneycomb[i][2] < arrayCoordinatesMediumHoneycomb[i][14]) {
                            if (arrayCoordinatesMediumHoneycomb[i][1] < arrayCoordinatesMediumHoneycomb[i][13]) {
                                if (arrayCoordinatesMediumHoneycomb[i][1] + switch2 < arrayCoordinatesMediumHoneycomb[i][13]) {
                                    arrayCoordinatesMediumHoneycomb[i][1] = arrayCoordinatesMediumHoneycomb[i][1] + switch2;
                                }
                                if (arrayCoordinatesMediumHoneycomb[i][1] + switch2 >= arrayCoordinatesMediumHoneycomb[i][13]) {
                                    arrayCoordinatesMediumHoneycomb[i][1] = arrayCoordinatesMediumHoneycomb[i][13];
                                }
                            }
                            break;
                        }

                        if (arrayCoordinatesMediumHoneycomb[i][1] == arrayCoordinatesMediumHoneycomb[i][13] && arrayCoordinatesMediumHoneycomb[i][2] < arrayCoordinatesMediumHoneycomb[i][14]) {
                            if (arrayCoordinatesMediumHoneycomb[i][2] < arrayCoordinatesMediumHoneycomb[i][14]) {
                                if (arrayCoordinatesMediumHoneycomb[i][2] + switch2 < arrayCoordinatesMediumHoneycomb[i][14]) {
                                    arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][2] + switch2;
                                }
                                if (arrayCoordinatesMediumHoneycomb[i][2] + switch2 >= arrayCoordinatesMediumHoneycomb[i][14]) {
                                    arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][14];
                                }
                            }
                            break;
                        }

                        if (arrayCoordinatesMediumHoneycomb[i][1] > arrayCoordinatesMediumHoneycomb[i][13] && arrayCoordinatesMediumHoneycomb[i][2] > arrayCoordinatesMediumHoneycomb[i][14]) {
                            if (arrayCoordinatesMediumHoneycomb[i][1] > arrayCoordinatesMediumHoneycomb[i][13]) {
                                if (arrayCoordinatesMediumHoneycomb[i][1] - switch2 > arrayCoordinatesMediumHoneycomb[i][13]) {
                                    arrayCoordinatesMediumHoneycomb[i][1] = arrayCoordinatesMediumHoneycomb[i][1] - switch2;
                                }
                                if (arrayCoordinatesMediumHoneycomb[i][1] - switch2 <= arrayCoordinatesMediumHoneycomb[i][13]) {
                                    arrayCoordinatesMediumHoneycomb[i][1] = arrayCoordinatesMediumHoneycomb[i][13];
                                }
                            }
                            break;
                        }

                        if (arrayCoordinatesMediumHoneycomb[i][1] == arrayCoordinatesMediumHoneycomb[i][13] && arrayCoordinatesMediumHoneycomb[i][2] > arrayCoordinatesMediumHoneycomb[i][14]) {
                            if (arrayCoordinatesMediumHoneycomb[i][2] > arrayCoordinatesMediumHoneycomb[i][14]) {
                                if (arrayCoordinatesMediumHoneycomb[i][2] - switch2 > arrayCoordinatesMediumHoneycomb[i][14]) {
                                    arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][2] - switch2;
                                }
                                if (arrayCoordinatesMediumHoneycomb[i][2] - switch2 <= arrayCoordinatesMediumHoneycomb[i][14]) {
                                    arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][14];
                                }
                            }
                            break;
                        }


                        if (arrayCoordinatesMediumHoneycomb[i][1] == arrayCoordinatesMediumHoneycomb[i][13] && arrayCoordinatesMediumHoneycomb[i][2] == arrayCoordinatesMediumHoneycomb[i][14]) {
                            arrayCoordinatesMediumHoneycomb[i][0]++;
                            break;
                        }
                        break;

                    case 6:

                        if (temporaryStopperOnBigHoneycomb == true) {
                            if (arrayCoordinatesMediumHoneycomb[0][0] >= 6 && arrayCoordinatesMediumHoneycomb[1][0] >= 6 && arrayCoordinatesMediumHoneycomb[2][0] >= 6) {
                                if (arrayCoordinatesMediumHoneycomb[i][1] == arrayCoordinatesMediumHoneycomb[i][15] && arrayCoordinatesMediumHoneycomb[i][2] < arrayCoordinatesMediumHoneycomb[i][16]) {
                                    if (arrayCoordinatesMediumHoneycomb[i][2] < arrayCoordinatesMediumHoneycomb[i][16]) {
                                        if (arrayCoordinatesMediumHoneycomb[i][2] + switch0 < arrayCoordinatesMediumHoneycomb[i][16]) {
                                            arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][2] + switch0;
                                        }
                                        if (arrayCoordinatesMediumHoneycomb[i][2] + switch0 >= arrayCoordinatesMediumHoneycomb[i][16]) {
                                            arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][16];
                                        }
                                    }
                                    break;
                                }
                                if (arrayCoordinatesMediumHoneycomb[i][1] == arrayCoordinatesMediumHoneycomb[i][15] && arrayCoordinatesMediumHoneycomb[i][2] > arrayCoordinatesMediumHoneycomb[i][16]) {
                                    if (arrayCoordinatesMediumHoneycomb[i][2] > arrayCoordinatesMediumHoneycomb[i][16]) {
                                        if (arrayCoordinatesMediumHoneycomb[i][2] - switch0 > arrayCoordinatesMediumHoneycomb[i][16]) {
                                            arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][2] - switch0;
                                        }
                                        if (arrayCoordinatesMediumHoneycomb[i][2] - switch0 <= arrayCoordinatesMediumHoneycomb[i][16]) {
                                            arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][16];
                                        }
                                    }
                                    break;
                                }


                                if (arrayCoordinatesMediumHoneycomb[i][1] < arrayCoordinatesMediumHoneycomb[i][15] && arrayCoordinatesMediumHoneycomb[i][2] == arrayCoordinatesMediumHoneycomb[i][16]) {

                                    if (arrayCoordinatesMediumHoneycomb[i][1] < arrayCoordinatesMediumHoneycomb[i][15]) {
                                        if (arrayCoordinatesMediumHoneycomb[i][1] + switch0 < arrayCoordinatesMediumHoneycomb[i][15]) {
                                            arrayCoordinatesMediumHoneycomb[i][1] = arrayCoordinatesMediumHoneycomb[i][1] + switch0;
                                        }
                                        if (arrayCoordinatesMediumHoneycomb[i][1] + switch0 >= arrayCoordinatesMediumHoneycomb[i][15]) {
                                            arrayCoordinatesMediumHoneycomb[i][1] = arrayCoordinatesMediumHoneycomb[i][15];
                                        }
                                    }
                                    break;
                                }
                            }

                            if (arrayCoordinatesMediumHoneycomb[i][1] == arrayCoordinatesMediumHoneycomb[i][15] && arrayCoordinatesMediumHoneycomb[i][2] == arrayCoordinatesMediumHoneycomb[i][16]) {
                                arrayCoordinatesMediumHoneycomb[i][0]++;
                                break;
                            }
                        }
                        break;

                    case 7:
                        if (arrayCoordinatesMediumHoneycomb[i][1] > arrayCoordinatesMediumHoneycomb[i][17] && arrayCoordinatesMediumHoneycomb[i][2] == arrayCoordinatesMediumHoneycomb[i][18]) {
                            if (arrayCoordinatesMediumHoneycomb[i][1] - switch1 > arrayCoordinatesMediumHoneycomb[i][17]) {
                                arrayCoordinatesMediumHoneycomb[i][1] = arrayCoordinatesMediumHoneycomb[i][1] - switch1;
                                break;
                            }
                            if (arrayCoordinatesMediumHoneycomb[i][1] - switch1 <= arrayCoordinatesMediumHoneycomb[i][17]) {
                                arrayCoordinatesMediumHoneycomb[i][1] = arrayCoordinatesMediumHoneycomb[i][17];
                                arrayCoordinatesMediumHoneycomb[i][0]++;
                                break;
                            }
                        }

                        if (arrayCoordinatesMediumHoneycomb[i][2] > arrayCoordinatesMediumHoneycomb[i][18] && arrayCoordinatesMediumHoneycomb[i][1] == arrayCoordinatesMediumHoneycomb[i][17]) {
                            if (arrayCoordinatesMediumHoneycomb[i][2] - switch1 > arrayCoordinatesMediumHoneycomb[i][18]) {
                                arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][2] - switch1;
                                break;
                            }
                            if (arrayCoordinatesMediumHoneycomb[i][2] - switch1 <= arrayCoordinatesMediumHoneycomb[i][18]) {
                                arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][18];
                                arrayCoordinatesMediumHoneycomb[i][0]++;
                                break;
                            }
                        }

                        if (arrayCoordinatesMediumHoneycomb[i][2] < arrayCoordinatesMediumHoneycomb[i][18] && arrayCoordinatesMediumHoneycomb[i][1] == arrayCoordinatesMediumHoneycomb[i][17]) {
                            if (arrayCoordinatesMediumHoneycomb[i][2] + switch1 < arrayCoordinatesMediumHoneycomb[i][18]) {
                                arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][2] + switch1;
                                break;
                            }
                            if (arrayCoordinatesMediumHoneycomb[i][2] + switch1 >= arrayCoordinatesMediumHoneycomb[i][18]) {
                                arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][18];
                                arrayCoordinatesMediumHoneycomb[i][0]++;
                                break;
                            }
                        }
                        break;

                    case 8:

                        if (arrayCoordinatesMediumHoneycomb[i][1] < arrayCoordinatesMediumHoneycomb[i][19] && arrayCoordinatesMediumHoneycomb[i][2] > arrayCoordinatesMediumHoneycomb[i][20]) {
                            if (arrayCoordinatesMediumHoneycomb[i][2] > arrayCoordinatesMediumHoneycomb[i][20]) {
                                if (arrayCoordinatesMediumHoneycomb[i][2] - switch2 > arrayCoordinatesMediumHoneycomb[i][20]) {
                                    arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][2] - switch2;
                                }
                                if (arrayCoordinatesMediumHoneycomb[i][2] - switch2 <= arrayCoordinatesMediumHoneycomb[i][20]) {
                                    arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][20];
                                }
                            }
                            break;
                        }

                        if (arrayCoordinatesMediumHoneycomb[i][1] < arrayCoordinatesMediumHoneycomb[i][19] && arrayCoordinatesMediumHoneycomb[i][2] == arrayCoordinatesMediumHoneycomb[i][20]) {
                            if (arrayCoordinatesMediumHoneycomb[i][1] < arrayCoordinatesMediumHoneycomb[i][19]) {
                                if (arrayCoordinatesMediumHoneycomb[i][1] + switch2 < arrayCoordinatesMediumHoneycomb[i][19]) {
                                    arrayCoordinatesMediumHoneycomb[i][1] = arrayCoordinatesMediumHoneycomb[i][1] + switch2;
                                }
                                if (arrayCoordinatesMediumHoneycomb[i][1] + switch2 >= arrayCoordinatesMediumHoneycomb[i][19]) {
                                    arrayCoordinatesMediumHoneycomb[i][1] = arrayCoordinatesMediumHoneycomb[i][19];
                                }
                            }
                            break;
                        }

                        if (arrayCoordinatesMediumHoneycomb[i][1] < arrayCoordinatesMediumHoneycomb[i][19] && arrayCoordinatesMediumHoneycomb[i][2] < arrayCoordinatesMediumHoneycomb[i][20]) {
                            if (arrayCoordinatesMediumHoneycomb[i][1] < arrayCoordinatesMediumHoneycomb[i][19]) {
                                if (arrayCoordinatesMediumHoneycomb[i][1] + switch2 < arrayCoordinatesMediumHoneycomb[i][19]) {
                                    arrayCoordinatesMediumHoneycomb[i][1] = arrayCoordinatesMediumHoneycomb[i][1] + switch2;
                                }
                                if (arrayCoordinatesMediumHoneycomb[i][1] + switch2 >= arrayCoordinatesMediumHoneycomb[i][19]) {
                                    arrayCoordinatesMediumHoneycomb[i][1] = arrayCoordinatesMediumHoneycomb[i][19];
                                }
                            }
                            break;
                        }

                        if (arrayCoordinatesMediumHoneycomb[i][1] == arrayCoordinatesMediumHoneycomb[i][19] && arrayCoordinatesMediumHoneycomb[i][2] < arrayCoordinatesMediumHoneycomb[i][20]) {
                            if (arrayCoordinatesMediumHoneycomb[i][2] < arrayCoordinatesMediumHoneycomb[i][20]) {
                                if (arrayCoordinatesMediumHoneycomb[i][2] + switch2 < arrayCoordinatesMediumHoneycomb[i][20]) {
                                    arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][2] + switch2;
                                }
                                if (arrayCoordinatesMediumHoneycomb[i][2] + switch2 >= arrayCoordinatesMediumHoneycomb[i][20]) {
                                    arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][20];
                                }
                            }
                            break;
                        }

                        if (arrayCoordinatesMediumHoneycomb[i][1] > arrayCoordinatesMediumHoneycomb[i][19] && arrayCoordinatesMediumHoneycomb[i][2] > arrayCoordinatesMediumHoneycomb[i][20]) {
                            if (arrayCoordinatesMediumHoneycomb[i][1] > arrayCoordinatesMediumHoneycomb[i][19]) {
                                if (arrayCoordinatesMediumHoneycomb[i][1] - switch2 > arrayCoordinatesMediumHoneycomb[i][19]) {
                                    arrayCoordinatesMediumHoneycomb[i][1] = arrayCoordinatesMediumHoneycomb[i][1] - switch2;
                                }
                                if (arrayCoordinatesMediumHoneycomb[i][1] - switch2 <= arrayCoordinatesMediumHoneycomb[i][19]) {
                                    arrayCoordinatesMediumHoneycomb[i][1] = arrayCoordinatesMediumHoneycomb[i][19];
                                }
                            }
                            break;
                        }

                        if (arrayCoordinatesMediumHoneycomb[i][1] == arrayCoordinatesMediumHoneycomb[i][19] && arrayCoordinatesMediumHoneycomb[i][2] > arrayCoordinatesMediumHoneycomb[i][20]) {
                            if (arrayCoordinatesMediumHoneycomb[i][2] > arrayCoordinatesMediumHoneycomb[i][20]) {
                                if (arrayCoordinatesMediumHoneycomb[i][2] - switch2 > arrayCoordinatesMediumHoneycomb[i][20]) {
                                    arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][2] - switch2;
                                }
                                if (arrayCoordinatesMediumHoneycomb[i][2] - switch2 <= arrayCoordinatesMediumHoneycomb[i][20]) {
                                    arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][20];
                                }
                            }
                            break;
                        }


                        if (arrayCoordinatesMediumHoneycomb[i][1] == arrayCoordinatesMediumHoneycomb[i][19] && arrayCoordinatesMediumHoneycomb[i][2] == arrayCoordinatesMediumHoneycomb[i][20]) {
                            arrayCoordinatesMediumHoneycomb[i][0]++;
                            break;
                        }
                        break;

                    case 9:

                        if (indexStringsFromCharArrayForStringOnBigHoneycomb == 20 || indexStringsFromCharArrayForStringOnBigHoneycomb == 45 || indexStringsFromCharArrayForStringOnBigHoneycomb == 71) {

                            showOnMessageAnimationOnMediumHoneycomb_1 = true;
                        }

                        if (temporaryStopperOnBigHoneycomb == true) {
                            if (arrayCoordinatesMediumHoneycomb[0][0] >= 9 && arrayCoordinatesMediumHoneycomb[1][0] >= 9 && arrayCoordinatesMediumHoneycomb[2][0] >= 9) {
                                if (arrayCoordinatesMediumHoneycomb[i][1] < arrayCoordinatesMediumHoneycomb[i][21] && arrayCoordinatesMediumHoneycomb[i][2] == arrayCoordinatesMediumHoneycomb[i][22]) {
                                    if (arrayCoordinatesMediumHoneycomb[i][1] + switch0 < arrayCoordinatesMediumHoneycomb[i][21]) {
                                        arrayCoordinatesMediumHoneycomb[i][1] = arrayCoordinatesMediumHoneycomb[i][1] + switch0;
                                        break;
                                    }
                                    if (arrayCoordinatesMediumHoneycomb[i][1] + switch0 >= arrayCoordinatesMediumHoneycomb[i][21]) {
                                        arrayCoordinatesMediumHoneycomb[i][1] = arrayCoordinatesMediumHoneycomb[i][21];
                                        arrayCoordinatesMediumHoneycomb[i][0]++;
                                        break;
                                    }
                                }

                                if (arrayCoordinatesMediumHoneycomb[i][2] < arrayCoordinatesMediumHoneycomb[i][22] && arrayCoordinatesMediumHoneycomb[i][1] == arrayCoordinatesMediumHoneycomb[i][21]) {
                                    if (arrayCoordinatesMediumHoneycomb[i][2] + switch0 < arrayCoordinatesMediumHoneycomb[i][22]) {
                                        arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][2] + switch0;
                                        break;
                                    }
                                    if (arrayCoordinatesMediumHoneycomb[i][2] + switch0 >= arrayCoordinatesMediumHoneycomb[i][22]) {
                                        arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][22];
                                        arrayCoordinatesMediumHoneycomb[i][0]++;
                                        break;
                                    }
                                }


                                if (arrayCoordinatesMediumHoneycomb[i][2] > arrayCoordinatesMediumHoneycomb[i][22] && arrayCoordinatesMediumHoneycomb[i][1] == arrayCoordinatesMediumHoneycomb[i][21]) {
                                    if (arrayCoordinatesMediumHoneycomb[i][2] - switch0 > arrayCoordinatesMediumHoneycomb[i][22]) {
                                        arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][2] - switch0;
                                        break;
                                    }
                                    if (arrayCoordinatesMediumHoneycomb[i][2] - switch0 <= arrayCoordinatesMediumHoneycomb[i][22]) {
                                        arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][22];
                                        arrayCoordinatesMediumHoneycomb[i][0]++;
                                        break;
                                    }
                                }
                            }
                        }
                        break;

                    case 10:

                        if (finishAnimationForMediumHoneycomb == true) {


                            if (arrayCoordinatesMediumHoneycomb[i][1] > arrayCoordinatesMediumHoneycomb[i][25] && arrayCoordinatesMediumHoneycomb[i][2] == arrayCoordinatesMediumHoneycomb[i][26]) {
                                if (arrayCoordinatesMediumHoneycomb[i][1] - switch0 > arrayCoordinatesMediumHoneycomb[i][25]) {
                                    arrayCoordinatesMediumHoneycomb[i][1] = arrayCoordinatesMediumHoneycomb[i][1] - switch0;
                                    break;
                                }
                            }

                            if (arrayCoordinatesMediumHoneycomb[i][2] > arrayCoordinatesMediumHoneycomb[i][26] && arrayCoordinatesMediumHoneycomb[i][1] == arrayCoordinatesMediumHoneycomb[i][25]) {
                                if (arrayCoordinatesMediumHoneycomb[i][2] - switch0 > arrayCoordinatesMediumHoneycomb[i][26]) {
                                    arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][2] - switch0;
                                    break;
                                }
                            }

                            if (arrayCoordinatesMediumHoneycomb[i][2] < arrayCoordinatesMediumHoneycomb[i][26] && arrayCoordinatesMediumHoneycomb[i][1] == arrayCoordinatesMediumHoneycomb[i][25]) {
                                if (arrayCoordinatesMediumHoneycomb[i][2] + switch0 < arrayCoordinatesMediumHoneycomb[i][26]) {
                                    arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][2] + switch0;
                                    break;
                                }
                            }
                            break;
                        }


                        if (arrayCoordinatesMediumHoneycomb[i][1] > arrayCoordinatesMediumHoneycomb[i][23] && arrayCoordinatesMediumHoneycomb[i][2] == arrayCoordinatesMediumHoneycomb[i][24]) {
                            if (arrayCoordinatesMediumHoneycomb[i][1] - switch1 > arrayCoordinatesMediumHoneycomb[i][23]) {
                                arrayCoordinatesMediumHoneycomb[i][1] = arrayCoordinatesMediumHoneycomb[i][1] - switch1;
                                break;
                            }
                            if (arrayCoordinatesMediumHoneycomb[i][1] - switch1 <= arrayCoordinatesMediumHoneycomb[i][23]) {
                                arrayCoordinatesMediumHoneycomb[i][1] = arrayCoordinatesMediumHoneycomb[i][23];
                                arrayCoordinatesMediumHoneycomb[i][0] = 2;
                                break;
                            }
                        }

                        if (arrayCoordinatesMediumHoneycomb[i][2] > arrayCoordinatesMediumHoneycomb[i][24] && arrayCoordinatesMediumHoneycomb[i][1] == arrayCoordinatesMediumHoneycomb[i][23]) {
                            if (arrayCoordinatesMediumHoneycomb[i][2] - switch1 > arrayCoordinatesMediumHoneycomb[i][24]) {
                                arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][2] - switch1;
                                break;
                            }
                            if (arrayCoordinatesMediumHoneycomb[i][2] - switch1 <= arrayCoordinatesMediumHoneycomb[i][24]) {
                                arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][24];
                                arrayCoordinatesMediumHoneycomb[i][0] = 2;
                                break;
                            }
                        }

                        if (arrayCoordinatesMediumHoneycomb[i][2] < arrayCoordinatesMediumHoneycomb[i][24] && arrayCoordinatesMediumHoneycomb[i][1] == arrayCoordinatesMediumHoneycomb[i][23]) {
                            if (arrayCoordinatesMediumHoneycomb[i][2] + switch1 < arrayCoordinatesMediumHoneycomb[i][24]) {
                                arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][2] + switch1;
                                break;
                            }
                            if (arrayCoordinatesMediumHoneycomb[i][2] + switch1 >= arrayCoordinatesMediumHoneycomb[i][24]) {
                                arrayCoordinatesMediumHoneycomb[i][2] = arrayCoordinatesMediumHoneycomb[i][24];
                                arrayCoordinatesMediumHoneycomb[i][0] = 2;
                                break;
                            }
                        }
                        break;

                    case 11:                                    //условие для остановки таймера анимации timerMediumHoneycomb
                        timerMediumHoneycomb.stop();
                        break;
                    default:
                        System.out.println("что-то пошло не так!!!");
                }
            }
        }
    });

    //functions

    public void update() {
        comparison_time();
        if (showONanimationBigHoneycomb == true) {
            timerBigHoneycomb.start();   //запуск таймера анимации timerBigHoneycomb
            timerMediumHoneycomb.start();  //запуск таймера анимации timerMediumHoneycomb
        }
        if (showOnMessageAnimationOnBigHoneycomb == true) {

            compilationShowOnMessageAnimationOnBigHoneycomb();
        }

        if (showOnMessageAnimationOnMediumHoneycomb_3 == true) {
            compilationShowOnMessageAnimationOnMediumHoneycomb_2();

        }
    }

    ///////////////////////////////////////////////////


    //сборка коллекции для демонстрации сообщений на BigHoneycomb
    public void compilationShowOnMessageAnimationOnBigHoneycomb() {


        if (showOffMessageAnimationOnBigHoneycomb == true && showFinishMessageAnimationOnBigHoneycomb == true) {


            if (indexStringsFromCharArrayForStringOnBigHoneycomb == 3) {

                positionMediumHoneycomb = 1;
            }

            if (indexStringsFromCharArrayForStringOnBigHoneycomb == 20 || indexStringsFromCharArrayForStringOnBigHoneycomb == 45 || indexStringsFromCharArrayForStringOnBigHoneycomb == 71) {

                positionMediumHoneycomb = 3;
            }


            //проверка связаная с запуском анимации прогрессбаров на MediumHoneycomb (можно сделать стоперы по индексам строк)
            //дойдя до определенного места (строки),включается стопер анимации сообщений и включается анимация прогрессбаров

            if (indexStringsFromCharArrayForStringOnBigHoneycomb == 3 || indexStringsFromCharArrayForStringOnBigHoneycomb == 20 || indexStringsFromCharArrayForStringOnBigHoneycomb == 45 || indexStringsFromCharArrayForStringOnBigHoneycomb == 71) {
                temporaryStopperOnBigHoneycomb = false;

                startTimeForMediumHoneycomb = System.currentTimeMillis();
                comparison_time3();

            }


            if (temporaryStopperOnBigHoneycomb == true) {

                if (countIndexCharArrayForStringOnBigHoneycomb == 0) {
                    stringBuilderMessageAnimationOnBigHoneycomb = new StringBuilder();                 //обнуляем stringBuilder
                    indexCollectonMessageAnimationOnBigHoneycomb++;

                    if (collectonMessageAnimationOnBigHoneycomb.size() == numberOfRowsPerBigHoneycomb) {
                        collectonMessageAnimationOnBigHoneycomb.remove(0);
                        indexCollectonMessageAnimationOnBigHoneycomb = numberOfRowsPerBigHoneycomb - 1;
                    }

                    collectonMessageAnimationOnBigHoneycomb.add(stringBuilderMessageAnimationOnBigHoneycomb);    //присоединяем stringBuilder в коллекцию стрингбилдеров
                    charsArrayForStringOnBigHoneycomb = stringsForBigHoneycomb[indexStringsFromCharArrayForStringOnBigHoneycomb].toCharArray();
                }

                a = 0;
                symbolFromCharsArrayForStringOnBigHoneycomb = charsArrayForStringOnBigHoneycomb[countIndexCharArrayForStringOnBigHoneycomb];
                countIndexCharArrayForStringOnBigHoneycomb++;   //счетчик индексов в массиве char[] charsArrayForStringOnBigHoneycomb

                if (countIndexCharArrayForStringOnBigHoneycomb == charsArrayForStringOnBigHoneycomb.length) {
                    indexStringsFromCharArrayForStringOnBigHoneycomb++;                                // индекс строки из массива строк
                    if (indexStringsFromCharArrayForStringOnBigHoneycomb >= stringsForBigHoneycomb.length) {
                        showFinishMessageAnimationOnBigHoneycomb = false;
                    }
                    countIndexCharArrayForStringOnBigHoneycomb = 0;
                }

                collectonMessageAnimationOnBigHoneycomb.get(indexCollectonMessageAnimationOnBigHoneycomb).append(symbolFromCharsArrayForStringOnBigHoneycomb);   //добавление символа из char[] распарсеной строки в stringBuilderMessageAnimationOnBigHoneycomb, находящегося в коллекции collectonMessageAnimationOnBigHoneycomb

            }
        }
    }


    //рандомное определение положения BigHoneycomb,для передвижения в следующее положение

    public void randomPositioning() {
        boolean resolution = false;

        do {
            numberOfPositioningNew = (int) (0 + (Math.random() * 4));
            if (numberOfPositioningNew != numberOfPositioningOld) {
                numberOfPositioningOld = numberOfPositioningNew;
                resolution = true;
            }
        } while (resolution == false);
    }


    //определение времени
    public void comparison_time() {
        if (System.currentTimeMillis() > startTimeShowAnimationBigHoneycomb) {               //проверка,если время,startTime = System.currentTimeMillis(); больше startTimeShowAnimationBigHoneycomb,то поменять false  на true (т.е. разрешить анимацию BigHoneycomb)
            showONanimationBigHoneycomb = true;
        }
    }

    //определение времени2
    public void comparison_time2() {
        if (System.currentTimeMillis() > startTimeShowForMessageAnimation) {               //проверка,если время,startTimeForMessageAnimation = System.currentTimeMillis(); больше startTimeShowForMessageAnimation,то поменять false  на true  (т.е. разрешить анимацию сообщений на BigHoneycomb)
            showOnMessageAnimationOnBigHoneycomb = true;
        }
    }

    //определение времени3 (для MiniHoneycomb)
    public void comparison_time3() {
        numberForComparison_time3 = 35;

        if (startTimeForMediumHoneycomb > startTimeShowAnimationMediumHoneycomb) {               //проверка,если время,startTimeForMessageAnimation = System.currentTimeMillis(); больше startTimeShowForMessageAnimation,то поменять false  на true  (т.е. разрешить анимацию сообщений на BigHoneycomb)
            showAnimationOnMediumHoneycomb_1_andGeneralOnMediumHoneycomb = true;

            startTimeShowAnimationMediumHoneycomb = startTimeShowAnimationMediumHoneycomb + 25 * 1000;    //15-число,регулирующее интервал времени (промежутки),между анимацией сообщений на BigHoneycomb

        }
    }


    //создание эффекта мигания лампочки готовности на mediumHoneycomb
    public void appropriationColorLightBulbRedInstance(int a) {

        dataForLightBulbsOnMediumHoneycombsArray[a][2]++;

        if (dataForLightBulbsOnMediumHoneycombsArray[a][2] == 3) {
            dataForLightBulbsOnMediumHoneycombsArray[a][2] = 0;
            dataForLightBulbsOnMediumHoneycombsArray[a][1]++;


            if (dataForLightBulbsOnMediumHoneycombsArray[a][0] == 1) {
                LightBulbs[a] = colorLightBulbRedArray.get(dataForLightBulbsOnMediumHoneycombsArray[a][1]);

            }
            if (dataForLightBulbsOnMediumHoneycombsArray[a][0] == 2) {
                LightBulbs[a] = colorLightBulbYellowArray.get(dataForLightBulbsOnMediumHoneycombsArray[a][1]);

            }
            if (dataForLightBulbsOnMediumHoneycombsArray[a][0] == 3) {
                LightBulbs[a] = colorLightBulbGreenArray.get(dataForLightBulbsOnMediumHoneycombsArray[a][1]);

            }

            if (dataForLightBulbsOnMediumHoneycombsArray[a][1] == 9) {
                dataForLightBulbsOnMediumHoneycombsArray[a][1] = -1;
            }
        }
    }

    //процесс исчезновения progressBarBigCircleInstance картинки из массива progressBarBigCircleArray
    public void extinctionProgressBarBigCircleInstance() {
        auxiliaryCountBigCircleExtinctionInstance++;
        if (auxiliaryCountBigCircleExtinctionInstance == 2) {
            auxiliaryCountBigCircleExtinctionInstance = 0;
            countForBigCircleExtinctionInstance++;
            if (countForBigCircleExtinctionInstance >= 28) {
                countForBigCircleExtinctionInstance = 12;
            }
        }

        auxiliaryCountSmallCircleExtinctionInstance++;
        if (auxiliaryCountSmallCircleExtinctionInstance == 1) {
            auxiliaryCountSmallCircleExtinctionInstance = 0;
            countForSmallCircleExtinctionInstance++;
            if (countForSmallCircleExtinctionInstance >= 26) {
                countForSmallCircleExtinctionInstance = 10;
            }
        }
        progressBarBigCircleInstance = bigCircleExtinctionCollection.get(countForBigCircleExtinctionInstance);  //присвоение преременной progressBarBigCircleInstance картинки из коллекции progressBarBigCircleArray с индексом "і"
        progressBarSmallCircleInstance = smallCircleExtinctionCollection.get(countForSmallCircleExtinctionInstance);
    }


    public void appropriationProgressBarBigCircleInstance() {
        auxiliaryCountForProgressBarBigCircleInstance++;
        if (auxiliaryCountForProgressBarBigCircleInstance == 2) {
            auxiliaryCountForProgressBarBigCircleInstance = 0;
            countForProgressBarBigCircleInstance++;
            if (countForProgressBarBigCircleInstance >= 28) {
                countForProgressBarBigCircleInstance = 12;
            }
        }

        auxiliaryCountForProgressBarSmallCircleInstance++;
        if (auxiliaryCountForProgressBarSmallCircleInstance == 1) {
            auxiliaryCountForProgressBarSmallCircleInstance = 0;
            countForProgressBarSmallCircleInstance++;
            if (countForProgressBarSmallCircleInstance >= 26) {
                countForProgressBarSmallCircleInstance = 10;
            }
        }
        progressBarBigCircleInstance = progressBarBigCircleArray.get(countForProgressBarBigCircleInstance);  //присвоение преременной progressBarBigCircleInstance картинки из коллекции progressBarBigCircleArray с индексом "і"
        progressBarSmallCircleInstance = progressBarSmallCircleArray.get(countForProgressBarSmallCircleInstance);
    }


    //присвоение значения для стринговой переменной ProressBarPercentNumberForCircle
    public void appropriationProressBarPercentNumberForCircle() {
        if (proressBarPercentNumberForCircle <= 99 || proressBarPercentNumberForCircle >= 1) {
            dataForLightBulbsOnMediumHoneycombsArray[0][0] = 2;
        }

        auxiliaryCountProressBarPercentNumberForCircle++;
        if (auxiliaryCountProressBarPercentNumberForCircle == 2) {
            proressBarPercentNumberForCircle = proressBarPercentNumberForCircle + 2;   //шаг добавления к числу proressBarPercentNumberForCircle
            auxiliaryCountProressBarPercentNumberForCircle = 0;
        }
        if (proressBarPercentNumberForCircle >= 100) {
            proressBarPercentNumberForCircle = 100;


            //с этого места происходит регулировка анимации MediumHoneycomb_2 и MediumHoneycomb_3

            showOnMessageAnimationOnMediumHoneycomb_2 = true;  //разрешение на анимацию на(в) MediumHoneycomb №2
            showOnMessageAnimationOnMediumHoneycomb_3 = true;   //разрешение на анимацию на(в) MediumHoneycomb №3

            showOnMessageAnimationOnMediumHoneycomb_3_afterAnimation = false;

            dataForLightBulbsOnMediumHoneycombsArray[1][0] = 2;   //цвет лампочкм на MediumHoneycomb_2 (желтый)
            dataForLightBulbsOnMediumHoneycombsArray[2][0] = 2;     //цвет лампочкм на MediumHoneycomb_3 (желтый)

            dataForLightBulbsOnMediumHoneycombsArray[0][0] = 3;


            animationResolutionForBrick_1 = true;
        }
    }


    //присвоение brickBasisInstance картинки из массива brickBasisArray
    public void appropriationBrickBasisInstance_plus() {

        if (showOnMessageAnimationOnMediumHoneycomb_plus == true) {

            auxiliaryCountForBrickBasisInstance++;
            if (auxiliaryCountForBrickBasisInstance == 7) {
                auxiliaryCountForBrickBasisInstance = 0;
                countForBrickBasisInstance++;
                if (countForBrickBasisInstance >= 7) {
                    countForBrickBasisInstance = 7;

                    animationResolutionForBrick_1 = true;
                    animationResolutionForBrick_2 = true;
                    animationResolutionForBrick_3 = false;

                    showOnMessageAnimationOnMediumHoneycomb_equalizer = true;
                    showOnMessageAnimationOnMediumHoneycomb_plus = false;
                }
            }
            brickBasisInstance = brickBasisArray.get(countForBrickBasisInstance);
        }
    }


    public void appropriationBrickBasisInstance_minus() {
        if (showOnMessageAnimationOnMediumHoneycomb_minus == true) {

            auxiliaryCountForBrickBasisInstance++;
            if (auxiliaryCountForBrickBasisInstance == 7) {    //число(10),обозначает скорость минусования элементов в brickBasisArray
                auxiliaryCountForBrickBasisInstance = 0;
                countForBrickBasisInstance--;
                if (countForBrickBasisInstance <= 0) {
                    countForBrickBasisInstance = 0;
                    //    animationResolutionForBrick_1 = false;   //разрешение на анимацию рандомного построения аквалайзера (но после этой части кода анимация не должна воспроизводиться)

                    permissionToContinueAnimationOnBigHoneycomb = true;   //разрешить (продолжить) анимацию сообщений на BigHoneycomb

                    if (brickBasisInstance == brickBasisArray.get(0)) {

                        continuedAnimationOnBigHoneycomb();

                        showOnMessageAnimationOnMediumHoneycomb_minus = false;
                        animationResolutionForBrick_3 = false;

                    }
                }
            }
            brickBasisInstance = brickBasisArray.get(countForBrickBasisInstance);
        }
    }


    //проверка на пустоту brickArray
    public void checkForEmptinessBrickArray() {


        for (int i = 0; i < collectionBricksArray.length; i++) {
            if (brickArray[i][4] == 0 && brickArray[i][3] == 0) {

                showOnMessageAnimationOnMediumHoneycomb_minus = true;

                showOnMessageAnimationOnMediumHoneycomb_equalizer = false;
                showOnMessageAnimationOnMediumHoneycomb_equalizer_2 = false;

                animationResolutionForBrick_2 = false;
                animationResolutionForBrick_3 = true;

            }
            if (brickArray[i][4] != 0 && brickArray[i][3] != 0) {

                showOnMessageAnimationOnMediumHoneycomb_minus = false;

                showOnMessageAnimationOnMediumHoneycomb_equalizer = false;
                showOnMessageAnimationOnMediumHoneycomb_equalizer_2 = true;

                animationResolutionForBrick_2 = true;
                animationResolutionForBrick_3 = false;

                break;
            }
        }
    }


    //происходит проверка и построение collectionBricks

    public void compositionCollectionBrick_plus() {

        if (showOnMessageAnimationOnMediumHoneycomb_equalizer == true) {

            int numberOfBricks = 0;         //количество кирпичей
            int resultNumberOfBricks = 0;

            //       for (int i = 0; i < brickArray.length; i++) {
            for (int i = 0; i < collectionBricksArray.length; i++) {

                if (brickArray[i][3] == brickArray[i][4]) {
                    brickArray[i][3] = (int) (0 + (Math.random() * numberMathRandomForCompositionCollectionBrick));
                }

                if (brickArray[i][3] > brickArray[i][4]) {    //проверка на соответствие между числами brickArray[i][3] и brickArray[i][4]
                    //  brickArray[i][4]++;
                    brickArray[i][4] = brickArray[i][4] + 2;

                    if (brickArray[i][4] % 3 == 0) {             //может ли число brickArray[i][4] делиться на 3 без остатка
                        numberOfBricks = brickArray[i][4] / 3;              //присвоение numberOfBricks клоичества кирпичей помещающихся в brickArray[i][4]

                        if (numberOfBricks > collectionBricksArray[i].size()) {       //сравнение numberOfBricks и collectionBricks.get(i).size(), и если numberOfBricks больше collectionBricks.get(i).size() то добавляем ...
                            resultNumberOfBricks = numberOfBricks - collectionBricksArray[i].size();

                            for (int j = 0; j < resultNumberOfBricks; j++) {
                                collectionBricksArray[i].add(String.valueOf(brickInstance));
                            }
                        }
                    }
                }

                if (brickArray[i][3] < brickArray[i][4]) {

                    brickArray[i][4] = brickArray[i][4] - 1;

                    if (brickArray[i][4] % 3 == 0) {             //может ли число brickArray[i][4] делиться на 3 без остатка
                        numberOfBricks = brickArray[i][4] / 3;              //присвоение numberOfBricks клоичества кирпичей помещающихся в brickArray[i][4]

                        if (numberOfBricks < collectionBricksArray[i].size()) {       //сравнение numberOfBricks и collectionBricks.get(i).size(), и если collectionBricksArray[i].size() больше numberOfBricks то удаляем ...
                            resultNumberOfBricks = collectionBricksArray[i].size() - numberOfBricks;

                            for (int j = 0; j < resultNumberOfBricks; j++) {
                                collectionBricksArray[i].remove(collectionBricksArray[i].size() - 1);

                            }
                        }
                    }
                }
            }
        }
    }

    public void compositionCollectionBrick_minus() {
        if (showOnMessageAnimationOnMediumHoneycomb_equalizer_2 == true) {    //если showOnMessageAnimationOnMediumHoneycomb_2_afterAnimation == true то проводим очищение коллекции collectionBricksArray (полное очищение)

            int numberOfBricks = 0;         //количество кирпичей
            int resultNumberOfBricks = 0;

            for (int i = 0; i < collectionBricksArray.length; i++) {


                if (brickArray[i][3] == brickArray[i][4]) {
                    brickArray[i][3] = 0;
                }

                if (brickArray[i][3] > brickArray[i][4]) {    //проверка на соответствие между числами brickArray[i][3] и brickArray[i][4]
                    brickArray[i][4] = brickArray[i][4] + 1;

                    if (brickArray[i][4] % 3 == 0) {             //может ли число brickArray[i][4] делиться на 3 без остатка
                        numberOfBricks = brickArray[i][4] / 3;              //присвоение numberOfBricks клоичества кирпичей помещающихся в brickArray[i][4]

                        if (numberOfBricks > collectionBricksArray[i].size()) {       //сравнение numberOfBricks и collectionBricks.get(i).size(), и если numberOfBricks больше collectionBricks.get(i).size() то добавляем ...
                            resultNumberOfBricks = numberOfBricks - collectionBricksArray[i].size();

                            for (int j = 0; j < resultNumberOfBricks; j++) {
                                collectionBricksArray[i].add(String.valueOf(brickInstance));
                            }
                        }
                    }
                }

                if (brickArray[i][3] < brickArray[i][4]) {
                    brickArray[i][4] = brickArray[i][4] - 1;

                    if (brickArray[i][4] % 3 == 0) {             //может ли число brickArray[i][4] делиться на 3 без остатка
                        numberOfBricks = brickArray[i][4] / 3;              //присвоение numberOfBricks клоичества кирпичей помещающихся в brickArray[i][4]

                        if (numberOfBricks < collectionBricksArray[i].size()) {       //сравнение numberOfBricks и collectionBricks.get(i).size(), и если collectionBricksArray[i].size() больше numberOfBricks то удаляем ...
                            resultNumberOfBricks = collectionBricksArray[i].size() - numberOfBricks;

                            for (int j = 0; j < resultNumberOfBricks; j++) {
                                collectionBricksArray[i].remove(collectionBricksArray[i].size() - 1);
                            }
                        }
                    }
                }
                checkForEmptinessBrickArray();
            }
        }
    }


    //    //сборка коллекции для демонстрации сообщений на MediumHoneycomb №3
    public void compilationShowOnMessageAnimationOnMediumHoneycomb_2() {
        if (showOnMessageAnimationOnMediumHoneycomb_3_afterAnimation == false) {

            if (choiceScenarioTextFromStringsForMediumHoneycomb == true) {       //выбор сценария текста из сценариев stringsForMediumHoneycomb
                //    numberScenarioFromStringsForMediumHoneycomb++;

                //    numberScenarioFromStringsForMediumHoneycomb = (int) (0 + (Math.random() * (stringsForMediumHoneycomb.length)));
                numberSecondCellForStringsForMediumHoneycomb = stringsForMediumHoneycomb[numberScenarioFromStringsForMediumHoneycomb].length;

                //    stringsForMediumHoneycomb[numberScenarioFromStringsForMediumHoneycomb][numberSecondCellForStringsForMediumHoneycomb];

                choiceScenarioTextFromStringsForMediumHoneycomb = false;
            }

            if (permissionToAddAnItem_1 == true && showOnMessageAnimationOnMediumHoneycomb_3 == true) {

                if (countIndexCharArrayForMediumHoneycomb == 0) {
                    auxiliaryStringBuilderMessageAnimationOnMediumHoneycomb_3 = new StringBuilder();                 //обнуляем stringBuilder
                    indexCollectonMessageAnimationForMediumHoneycomb++;

                    if (collectonMessageAnimationOnMediumHoneycomb_3.size() == numberOfRowsPerMediumHoneycomb_3) {
                        collectonMessageAnimationOnMediumHoneycomb_3.remove(0);
                        indexCollectonMessageAnimationForMediumHoneycomb = numberOfRowsPerMediumHoneycomb_3 - 1;
                    }

                    collectonMessageAnimationOnMediumHoneycomb_3.add(auxiliaryStringBuilderMessageAnimationOnMediumHoneycomb_3);    //присоединяем stringBuilder в коллекцию стрингбилдеров

                    if (indexStringsForMediumHoneycomb == numberSecondCellForStringsForMediumHoneycomb) {
                        indexStringsForMediumHoneycomb = indexStringsForMediumHoneycomb - 1;
                    }


                    charsArrayForStringOnMediumHoneycomb = stringsForMediumHoneycomb[numberScenarioFromStringsForMediumHoneycomb][indexStringsForMediumHoneycomb].toCharArray();
                }

                symbolForMediumHoneycomb = charsArrayForStringOnMediumHoneycomb[countIndexCharArrayForMediumHoneycomb];
                countIndexCharArrayForMediumHoneycomb++;   //счетчик индексов в массиве char[] charsArrayForString

                if (countIndexCharArrayForMediumHoneycomb == charsArrayForStringOnMediumHoneycomb.length) {
                    indexStringsForMediumHoneycomb++;
                    if (indexStringsForMediumHoneycomb >= stringsForMediumHoneycomb[numberScenarioFromStringsForMediumHoneycomb].length) {
                        permissionToAddAnItem_1 = false;
                        permissionToAddAnItem_2 = true;
                        auxiliaryPermissionToAddAnItem = true;

                        choiceScenarioTextFromStringsForMediumHoneycomb = true;
                    }
                    countIndexCharArrayForMediumHoneycomb = 0;
                }

                collectonMessageAnimationOnMediumHoneycomb_3.get(indexCollectonMessageAnimationForMediumHoneycomb).append(symbolForMediumHoneycomb);   //добавление символа из char[] распарсеной строки в stringBuilderMessageAnimation, находящегося в коллекции collectonMessageAnimation
            }

            if (permissionToAddAnItem_2 == true) {
                if (collectonMessageAnimationOnMediumHoneycomb_3.size() >= numberOfRowsPerMediumHoneycomb_3) {
                    collectonMessageAnimationOnMediumHoneycomb_3.remove(0);

                    countNumberOfCyclesForMediumHoneycomb_3++;
                }

                if (collectonMessageAnimationOnMediumHoneycomb_3.size() == 0 || collectonMessageAnimationOnMediumHoneycomb_3.size() < numberOfRowsPerMediumHoneycomb_3) {

                    auxiliaryStringBuilderMessageAnimationOnMediumHoneycomb_3 = new StringBuilder();
                    collectonMessageAnimationOnMediumHoneycomb_3.add(auxiliaryStringBuilderMessageAnimationOnMediumHoneycomb_3);

                    permissionToAddAnItem_2 = false;
                    numberMathRandomForCompositionCollectionBrick = 70;

                }
            }


            if (permissionToAddAnItem_2 == false && auxiliaryPermissionToAddAnItem == true) {
                for (int i = 9; i < collectonMessageAnimationOnMediumHoneycomb_3.size(); i++) {
                    if (collectonMessageAnimationOnMediumHoneycomb_3.get(i).length() <= 40) {
                        collectonMessageAnimationOnMediumHoneycomb_3.get(i).append(' ');
                    }

                    if (collectonMessageAnimationOnMediumHoneycomb_3.get(i).length() == 41) {
                        collectonMessageAnimationOnMediumHoneycomb_3.get(i).append(' ');
                        permissionToAddAnItem_2 = true;
                    }

                    for (int j = 0; j < collectonMessageAnimationOnMediumHoneycomb_3.get(i).length(); j++) {

                        if (collectonMessageAnimationOnMediumHoneycomb_3.get(i).length() == 42) {
                            break;
                        }
                        if (j == 0 || j == 1 || j == 2 || j == 3) {
                            collectonMessageAnimationOnMediumHoneycomb_3.get(i).setCharAt(j, (charArrayForAnimationMassageOnMediumHoneycomb_3[(int) (0 + (Math.random() * (charArrayForAnimationMassageOnMediumHoneycomb_3.length)))]));
                        }

                        if (j == 6 || j == 7 || j == 10 || j == 11 || j == 14 || j == 15 || j == 18 || j == 19 || j == 22 || j == 23 || j == 26 || j == 27 || j == 30 || j == 31 || j == 34 || j == 35 || j == 38 || j == 39) {
                            collectonMessageAnimationOnMediumHoneycomb_3.get(i).setCharAt(j, (charArrayForAnimationMassageNumberOnMediumHoneycomb_3[(int) (0 + (Math.random() * (charArrayForAnimationMassageNumberOnMediumHoneycomb_3.length)))]));
                        }

                        if (j == 4 || j == 5 || j == 8 || j == 9 || j == 12 || j == 13 || j == 16 || j == 17 || j == 20 || j == 21 || j == 24 || j == 25 || j == 28 || j == 29 || j == 32 || j == 33 || j == 36 || j == 37) {
                            collectonMessageAnimationOnMediumHoneycomb_3.get(i).setCharAt(j, ' ');
                        }
                    }
                }
            }

            if (numberOfCyclesForMediumHoneycomb_3 <= countNumberOfCyclesForMediumHoneycomb_3) {

                showOnMessageAnimationOnMediumHoneycomb_3_afterAnimation_2 = true;
            }
        }

        if (showOnMessageAnimationOnMediumHoneycomb_3_afterAnimation_2 == true) {
            if (collectonMessageAnimationOnMediumHoneycomb_3.size() > 0) {
                collectonMessageAnimationOnMediumHoneycomb_3.remove(0);

            }

            //урезание рандомного числа для построения аквалайзера (для улучшения визуального эффекта)
            if (collectonMessageAnimationOnMediumHoneycomb_3.size() == 9) {
                numberMathRandomForCompositionCollectionBrick = 20;

            }

            if (collectonMessageAnimationOnMediumHoneycomb_3.size() == 0) {

                dataForLightBulbsOnMediumHoneycombsArray[2][0] = 3;     //цвет лампочкм на MediumHoneycomb_3 (зеленый)

                showOnMessageAnimationOnMediumHoneycomb_equalizer = false;
                showOnMessageAnimationOnMediumHoneycomb_equalizer_2 = true;

                dataForLightBulbsOnMediumHoneycombsArray[1][0] = 3;     //цвет лампочкм на MediumHoneycomb_2 (зеленый)
            }
        }
    }


    public void continuedAnimationOnBigHoneycomb() {
        temporaryStopperOnBigHoneycomb = true;

        showFinishMessageAnimationOnBigHoneycomb = true;

        for (int i = 0; i < dataForLightBulbsOnMediumHoneycombsArray.length; i++) {

            dataForLightBulbsOnMediumHoneycombsArray[i][0] = 1;    //цвет лампочкм на MediumHoneycomb_i (красный)
            appropriationColorLightBulbRedInstance(i);
        }


        countNumberOfCyclesForMediumHoneycomb_3 = 0;
        showOnMessageAnimationOnMediumHoneycomb_3_afterAnimation = true;


        showAnimationOnMediumHoneycomb_1_andGeneralOnMediumHoneycomb = false;

        indexStringsFromCharArrayForStringOnBigHoneycomb++;
        if (indexStringsFromCharArrayForStringOnBigHoneycomb > stringsForBigHoneycomb.length - 1) {
            indexStringsFromCharArrayForStringOnBigHoneycomb = stringsForBigHoneycomb.length - 1;
        }

        proressBarPercentNumberForCircle = 0;      //обнуление показателя  proressBarPercentNumberForCircle

        showOnMessageAnimationOnMediumHoneycomb_1 = false;

        for (int i = 0; i < brickArray[i].length; i++) {
            brickArray[i][3] = 0;
            brickArray[i][4] = 0;
        }

        countForBrickBasisInstance = 0;

        showOnMessageAnimationOnMediumHoneycomb_2 = false;

        drawingExecutionForLightBulb1 = false;

        showOnMessageAnimationOnMediumHoneycomb_2_afterAnimation_2 = false;
        animationResolutionForBrick_1 = false;
        animationResolutionForBrick_2 = false;
        animationResolutionForBrick_3 = false;

        countForProgressBarBigCircleInstance = 0;
        auxiliaryCountForProgressBarBigCircleInstance = 0;
        countForProgressBarSmallCircleInstance = 1;
        auxiliaryCountForProgressBarSmallCircleInstance = 0;


        countForSmallCircleExtinctionInstance = 0;
        countForBigCircleExtinctionInstance = 0;

        choiceScenarioTextFromStringsForMediumHoneycomb = true;
        permissionToAddAnItem_1 = true;
        permissionToAddAnItem_2 = false;    //разрешение на добавление эллемента
        auxiliaryPermissionToAddAnItem = false;

        indexCollectonMessageAnimationForMediumHoneycomb = -1;

        indexStringsForMediumHoneycomb = 0;

        showOnMessageAnimationOnMediumHoneycomb_3_afterAnimation_2 = false;

        numberScenarioFromStringsForMediumHoneycomb++;


        showOnMessageAnimationOnMediumHoneycomb_plus = true;
        showOnMessageAnimationOnMediumHoneycomb_equalizer = false;
        showOnMessageAnimationOnMediumHoneycomb_equalizer_2 = false;
        showOnMessageAnimationOnMediumHoneycomb_minus = false;

        numberMathRandomForCompositionCollectionBrick = 101;

        countCycleForBigAndMediumHoneycomb++;

        if (countCycleForBigAndMediumHoneycomb == 4) {

            finishAnimationForMediumHoneycomb = true;
            cycleCountBigHoneycomb = 2;
            timerBigHoneycomb.start();
            timerFloatingHoneycomb.stop();

            animationForTransparencyHoneycomb_19 = true;

//            for (int i = 0; i < arrayCoordinatesMediumHoneycomb.length; i++) {
//                System.out.println("arrayCoordinatesMediumHoneycomb[" + i + "] [0] =" + arrayCoordinatesMediumHoneycomb[i][0]);
//            }
        }
    }


    //для анимации прозрачности Honeycomb_19
    public void animationTransparencyHoneycomb_19() {
        animationDelayForTransparencyHoneycomb_19++;

        if (animationDelayForTransparencyHoneycomb_19 == 8) {
            animationDelayForTransparencyHoneycomb_19 = 0;

            if (countForAnimationTransparencyHoneycomb_19 < 20) {
                countForAnimationTransparencyHoneycomb_19++;

                if (countForAnimationTransparencyHoneycomb_19 == 20) {
                    animationForTransparencyBackgroundHoneycomb = true;
                }
            }
//            if(countForAnimationTransparencyHoneycomb_19 >= 21){
//                break;
//            }
        }
        honeycomb_19_Instance = collectionForTransparencyHoneycomb_19.get(countForAnimationTransparencyHoneycomb_19);
    }


    //для анимации прозрачности (убираем края ячеек сот) BackgroundHoneycomb
    public void animationTransparencyBackgroundHoneycomb() {
        animationDelayForBackgroundHoneycomb++;

        if (animationDelayForBackgroundHoneycomb == 7) {
            animationDelayForBackgroundHoneycomb = 0;

            if (countForAnimationBackgroundHoneycomb < 20) {
                countForAnimationBackgroundHoneycomb++;
            }
        }
        backgroundHoneycombInstance = collectionForTransparencyBackgroundHoneycomb.get(countForAnimationBackgroundHoneycomb);
    }


    public void draw(Graphics2D g) {

        if (animationForTransparencyHoneycomb_19 == true) {
            animationTransparencyHoneycomb_19();

            g.drawImage(new ImageIcon(honeycomb_19_Instance).getImage(), coordinatesHoneycomb_19_x, coordinatesHoneycomb_19_y, null);
        }

        /*
            private String backgroundHoneycombInstance;   //экземпляр для картинки из коллекции collectionForTransparencyHoneycomb_19

    private int backgroundHoneycomb_x = 1;
    private int backgroundHoneycomb_y = 1;

    private int animationDelayForBackgroundHoneycomb = 0;
    private int countForAnimationBackgroundHoneycomb = 0;

    private boolean animationForTransparencyBackgroundHoneycomb = false;
         */

//        if (animationForTransparencyBackgroundHoneycomb == true) {
//            animationTransparencyBackgroundHoneycomb();
//
//            g.drawImage(new ImageIcon(backgroundHoneycombInstance).getImage(), backgroundHoneycomb_x, backgroundHoneycomb_y, null);
//
//        }


        comparison_time();
        if (showONanimationBigHoneycomb == true) {
            g.drawImage(bigHoneycomb, bigHoneycomb_x, bigHoneycomb_y, null);

            for (int i = 0; i < mediumHoneycombs.size(); i++) {

                mediumHoneycombInstance = mediumHoneycombs.get(i);  //присвоение преременной honeycombInstance картинки из коллекции honeycomb2 с индексом "і"
                g.drawImage(new ImageIcon(mediumHoneycombInstance).getImage(), arrayCoordinatesMediumHoneycomb[i][1], arrayCoordinatesMediumHoneycomb[i][2], null);

                appropriationColorLightBulbRedInstance(i);
                g.drawImage(new ImageIcon(LightBulbs[i]).getImage(), arrayCoordinatesMediumHoneycomb[i][1] + dataForLightBulbsOnMediumHoneycombsArray[i][3], arrayCoordinatesMediumHoneycomb[i][2] + dataForLightBulbsOnMediumHoneycombsArray[i][4], null);

            }
        }

        Color color1 = new Color(0, 150, 255);                   //создание цвета
        g.setColor(color1);                                               //присоединение выбраного цвета к кисти

        Font myFont = new Font(null, Font.BOLD, 28);           //установка шрифта и размера шрифта для анимации сообщений на BigHoneycomb
        g.setFont(myFont);

        comparison_time2();
        if (showOnMessageAnimationOnBigHoneycomb == true) {
            int coeff = 30;

            for (int i = 0; i < collectonMessageAnimationOnBigHoneycomb.size(); i++) {

                g.drawString(String.valueOf(collectonMessageAnimationOnBigHoneycomb.get(i)), bigHoneycomb_x + 80, bigHoneycomb_y + 250 + (i * coeff));                //     g.drawString(String.valueOf(collectonMessageAnimationOnBigHoneycomb.get(i)), showMessageAnimation_x, showMessageAnimation_y - (i * coeff));
            }
        }

        if (showAnimationOnMediumHoneycomb_1_andGeneralOnMediumHoneycomb == true) {

            switch (positionMediumHoneycomb) {
                case 0:
                    System.out.println("Это сообщение никогда не должно выскакивать!!!");
                    break;
                case 1:
                    coordinatesProgressBarBigCircle_x = 400;
                    coordinatesProgressBarBigCircle_y = 200;

                    coordinatesProgressBarSmallCircle_x = 400;
                    coordinatesProgressBarSmallCircle_y = 200;

                    coordinatesProressBarPercentNumberForCircle_x = 450;
                    coordinatesProressBarPercentNumberForCircle_y = 285;


                    coordinatesBrickInstance_x = 530;
                    coordinatesBrickInstance_y = 805;

                    coordinatesBrickBasisInstance_x = 530;
                    coordinatesBrickBasisInstance_y = 810;


                    coordinatesForAnimatiomOnMediumHoneycomb_3_x = 21;
                    coordinatesForAnimatiomOnMediumHoneycomb_3_y = 325;


                    break;
                case 2:
                    coordinatesProgressBarBigCircle_x = 550;
                    coordinatesProgressBarBigCircle_y = 650;

                    coordinatesProgressBarSmallCircle_x = 550;
                    coordinatesProgressBarSmallCircle_y = 650;

                    coordinatesProressBarPercentNumberForCircle_x = 600;
                    coordinatesProressBarPercentNumberForCircle_y = 735;


                    coordinatesBrickInstance_x = 133;
                    coordinatesBrickInstance_y = 720;

                    coordinatesBrickBasisInstance_x = 133;
                    coordinatesBrickBasisInstance_y = 725;


                    coordinatesForAnimatiomOnMediumHoneycomb_3_x = 263;
                    coordinatesForAnimatiomOnMediumHoneycomb_3_y = -35;
                    break;
                case 3:
                    coordinatesProgressBarBigCircle_x = 155;
                    coordinatesProgressBarBigCircle_y = 560;

                    coordinatesProgressBarSmallCircle_x = 155;
                    coordinatesProgressBarSmallCircle_y = 560;


                    coordinatesProressBarPercentNumberForCircle_x = 205;
                    coordinatesProressBarPercentNumberForCircle_y = 645;


                    coordinatesBrickInstance_x = 373;
                    coordinatesBrickInstance_y = 362;

                    coordinatesBrickBasisInstance_x = 373;
                    coordinatesBrickBasisInstance_y = 367;


                    coordinatesForAnimatiomOnMediumHoneycomb_3_x = 418;
                    coordinatesForAnimatiomOnMediumHoneycomb_3_y = 418;
                    break;
                default:
                    System.out.println("что-то пошло не так!!!");
            }


            for (int i = 0; i < mediumHoneycombs.size(); i++) {

                mediumHoneycombInstance = mediumHoneycombs.get(i);  //присвоение преременной honeycombInstance картинки из коллекции honeycomb2 с индексом "і"
                g.drawImage(new ImageIcon(mediumHoneycombInstance).getImage(), arrayCoordinatesMediumHoneycomb[i][1], arrayCoordinatesMediumHoneycomb[i][2], null);

                appropriationColorLightBulbRedInstance(i);
                g.drawImage(new ImageIcon(LightBulbs[i]).getImage(), arrayCoordinatesMediumHoneycomb[i][1] + dataForLightBulbsOnMediumHoneycombsArray[i][3], arrayCoordinatesMediumHoneycomb[i][2] + dataForLightBulbsOnMediumHoneycombsArray[i][4], null);
            }

            if (showOnMessageAnimationOnMediumHoneycomb_1 == true) {

                if (drawingExecutionForLightBulb1 == false) {
                    appropriationProgressBarBigCircleInstance();
                }
                if (drawingExecutionForLightBulb1 == true) {
                    extinctionProgressBarBigCircleInstance();
                }

                g.drawImage(new ImageIcon(progressBarBigCircleInstance).getImage(), coordinatesProgressBarBigCircle_x, coordinatesProgressBarBigCircle_y, null);
                g.drawImage(new ImageIcon(progressBarSmallCircleInstance).getImage(), coordinatesProgressBarSmallCircle_x, coordinatesProgressBarSmallCircle_y, null);

                appropriationProressBarPercentNumberForCircle();

                Color color2 = new Color(213, 216, 216);                   //создание цвета
                g.setColor(color2);                                               //присоединение выбраного цвета к кисти

                Font myFont2 = new Font(null, Font.ROMAN_BASELINE, 25);           //установка шрифта и размера шрифта для анимации сообщений на BigHoneycomb
                g.setFont(myFont2);

                if (proressBarPercentNumberForCircle <= 9) {
                    coordinatesProressBarPercentNumberForCircle_x = coordinatesProressBarPercentNumberForCircle_x + 7;
                }
                if (proressBarPercentNumberForCircle == 100) {
                    coordinatesProressBarPercentNumberForCircle_x = coordinatesProressBarPercentNumberForCircle_x - 7;
                    drawingExecutionForLightBulb1 = true;

                    showOnMessageAnimationOnMediumHoneycomb_3 = true;
                }
                g.drawString(proressBarPercentNumberForCircle + "%", coordinatesProressBarPercentNumberForCircle_x, coordinatesProressBarPercentNumberForCircle_y);

            }


            //brickInstance

            if (showOnMessageAnimationOnMediumHoneycomb_2 == true) {

                if (animationResolutionForBrick_1 == true) {
                    appropriationBrickBasisInstance_plus();

                    g.drawImage(new ImageIcon(brickBasisInstance).getImage(), coordinatesBrickBasisInstance_x, coordinatesBrickBasisInstance_y, null);

                }

                if (animationResolutionForBrick_2 == true && countForBrickBasisInstance == 7) {

                    compositionCollectionBrick_plus();
                    compositionCollectionBrick_minus();


                    for (int i = 0; i < collectionBricksArray.length; i++) {
                        for (int j = 0; j < collectionBricksArray[i].size(); j++) {
                            g.drawImage(new ImageIcon(brickInstance).getImage(), coordinatesBrickInstance_x + (i * 33), coordinatesBrickInstance_y - (j * 5), null);
                        }
                    }
                }

                if (countForBrickBasisInstance >= 0 && animationResolutionForBrick_3 == true) {

                    appropriationBrickBasisInstance_minus();
                    g.drawImage(new ImageIcon(brickBasisInstance).getImage(), coordinatesBrickBasisInstance_x, coordinatesBrickBasisInstance_y, null);

                }
            }

            //    Color color2 = new Color(213, 216, 216);                   //создание цвета
//            Color color2 = new Color(213, 216, 216);                   //создание цвета
//            g.setColor(color2);                                               //присоединение выбраного цвета к кисти
//
//            Font myFont3 = new Font(null, Font.ROMAN_BASELINE, 15);           //установка шрифта и размера шрифта для анимации сообщений на BigHoneycomb
//            g.setFont(myFont3);


            if (showOnMessageAnimationOnMediumHoneycomb_3 == true) {
                int coeff = 16;

                Color color2 = new Color(213, 216, 216);                   //создание цвета
                g.setColor(color2);                                               //присоединение выбраного цвета к кисти

                Font myFont3 = new Font(null, Font.ROMAN_BASELINE, 15);           //установка шрифта и размера шрифта для анимации сообщений на BigHoneycomb
                g.setFont(myFont3);

                for (int i = 0; i < collectonMessageAnimationOnMediumHoneycomb_3.size(); i++) {

                    g.drawString(String.valueOf(collectonMessageAnimationOnMediumHoneycomb_3.get(i)), coordinatesForAnimatiomOnMediumHoneycomb_3_x + 80, coordinatesForAnimatiomOnMediumHoneycomb_3_y + 250 + (i * coeff));                //     g.drawString(String.valueOf(collectonMessageAnimationOnBigHoneycomb.get(i)), showMessageAnimation_x, showMessageAnimation_y - (i * coeff));
                }
            }
        }

        if (animationForTransparencyBackgroundHoneycomb == true) {
            animationTransparencyBackgroundHoneycomb();

            g.drawImage(new ImageIcon(backgroundHoneycombInstance).getImage(), backgroundHoneycomb_x, backgroundHoneycomb_y, null);

        }


    }
}



